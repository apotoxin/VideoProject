/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     FORWARD = 258,
     SEND = 259,
     DROP = 260,
     EXIT = 261,
     RETURN = 262,
     LOG_TOK = 263,
     ERROR = 264,
     ROUTE = 265,
     ROUTE_FAILURE = 266,
     ROUTE_ONREPLY = 267,
     ROUTE_BRANCH = 268,
     ROUTE_ERROR = 269,
     ROUTE_LOCAL = 270,
     ROUTE_STARTUP = 271,
     ROUTE_TIMER = 272,
     ROUTE_EVENT = 273,
     SET_HOST = 274,
     SET_HOSTPORT = 275,
     PREFIX = 276,
     STRIP = 277,
     STRIP_TAIL = 278,
     APPEND_BRANCH = 279,
     REMOVE_BRANCH = 280,
     PV_PRINTF = 281,
     SET_USER = 282,
     SET_USERPASS = 283,
     SET_PORT = 284,
     SET_URI = 285,
     REVERT_URI = 286,
     SET_DSTURI = 287,
     RESET_DSTURI = 288,
     ISDSTURISET = 289,
     FORCE_RPORT = 290,
     FORCE_LOCAL_RPORT = 291,
     FORCE_TCP_ALIAS = 292,
     IF = 293,
     ELSE = 294,
     SWITCH = 295,
     CASE = 296,
     DEFAULT = 297,
     SBREAK = 298,
     WHILE = 299,
     SET_ADV_ADDRESS = 300,
     SET_ADV_PORT = 301,
     FORCE_SEND_SOCKET = 302,
     SERIALIZE_BRANCHES = 303,
     NEXT_BRANCHES = 304,
     USE_BLACKLIST = 305,
     UNUSE_BLACKLIST = 306,
     MAX_LEN = 307,
     SETDEBUG = 308,
     SETFLAG = 309,
     RESETFLAG = 310,
     ISFLAGSET = 311,
     SETBFLAG = 312,
     RESETBFLAG = 313,
     ISBFLAGSET = 314,
     SETSFLAG = 315,
     RESETSFLAG = 316,
     ISSFLAGSET = 317,
     METHOD = 318,
     URI = 319,
     FROM_URI = 320,
     TO_URI = 321,
     SRCIP = 322,
     SRCPORT = 323,
     DSTIP = 324,
     DSTPORT = 325,
     PROTO = 326,
     AF = 327,
     MYSELF = 328,
     MSGLEN = 329,
     UDP = 330,
     TCP = 331,
     TLS = 332,
     SCTP = 333,
     NULLV = 334,
     CACHE_STORE = 335,
     CACHE_FETCH = 336,
     CACHE_COUNTER_FETCH = 337,
     CACHE_REMOVE = 338,
     CACHE_ADD = 339,
     CACHE_SUB = 340,
     CACHE_RAW_QUERY = 341,
     XDBG = 342,
     XLOG = 343,
     XLOG_BUF_SIZE = 344,
     XLOG_FORCE_COLOR = 345,
     RAISE_EVENT = 346,
     SUBSCRIBE_EVENT = 347,
     CONSTRUCT_URI = 348,
     GET_TIMESTAMP = 349,
     SCRIPT_TRACE = 350,
     DEBUG = 351,
     FORK = 352,
     LOGSTDERROR = 353,
     LOGFACILITY = 354,
     LOGNAME = 355,
     AVP_ALIASES = 356,
     LISTEN = 357,
     ALIAS = 358,
     AUTO_ALIASES = 359,
     DNS = 360,
     REV_DNS = 361,
     DNS_TRY_IPV6 = 362,
     DNS_RETR_TIME = 363,
     DNS_RETR_NO = 364,
     DNS_SERVERS_NO = 365,
     DNS_USE_SEARCH = 366,
     MAX_WHILE_LOOPS = 367,
     PORT = 368,
     CHILDREN = 369,
     CHECK_VIA = 370,
     MEMLOG = 371,
     MEMDUMP = 372,
     EXECMSGTHRESHOLD = 373,
     EXECDNSTHRESHOLD = 374,
     TCPTHRESHOLD = 375,
     EVENT_SHM_THRESHOLD = 376,
     EVENT_PKG_THRESHOLD = 377,
     QUERYBUFFERSIZE = 378,
     QUERYFLUSHTIME = 379,
     SIP_WARNING = 380,
     SOCK_MODE = 381,
     SOCK_USER = 382,
     SOCK_GROUP = 383,
     UNIX_SOCK = 384,
     UNIX_SOCK_CHILDREN = 385,
     UNIX_TX_TIMEOUT = 386,
     SERVER_SIGNATURE = 387,
     SERVER_HEADER = 388,
     USER_AGENT_HEADER = 389,
     LOADMODULE = 390,
     MPATH = 391,
     MODPARAM = 392,
     MAXBUFFER = 393,
     USER = 394,
     GROUP = 395,
     CHROOT = 396,
     WDIR = 397,
     MHOMED = 398,
     DISABLE_TCP = 399,
     TCP_ACCEPT_ALIASES = 400,
     TCP_CHILDREN = 401,
     TCP_CONNECT_TIMEOUT = 402,
     TCP_SEND_TIMEOUT = 403,
     TCP_CON_LIFETIME = 404,
     TCP_LISTEN_BACKLOG = 405,
     TCP_POLL_METHOD = 406,
     TCP_MAX_CONNECTIONS = 407,
     TCP_OPT_CRLF_PINGPONG = 408,
     TCP_NO_NEW_CONN_BFLAG = 409,
     TCP_KEEPALIVE = 410,
     TCP_KEEPCOUNT = 411,
     TCP_KEEPIDLE = 412,
     TCP_KEEPINTERVAL = 413,
     DISABLE_TLS = 414,
     TLSLOG = 415,
     TLS_PORT_NO = 416,
     TLS_METHOD = 417,
     TLS_HANDSHAKE_TIMEOUT = 418,
     TLS_SEND_TIMEOUT = 419,
     TLS_SERVER_DOMAIN = 420,
     TLS_CLIENT_DOMAIN = 421,
     TLS_CLIENT_DOMAIN_AVP = 422,
     SSLv23 = 423,
     SSLv2 = 424,
     SSLv3 = 425,
     TLSv1 = 426,
     TLS_VERIFY_CLIENT = 427,
     TLS_VERIFY_SERVER = 428,
     TLS_REQUIRE_CLIENT_CERTIFICATE = 429,
     TLS_CERTIFICATE = 430,
     TLS_PRIVATE_KEY = 431,
     TLS_CA_LIST = 432,
     TLS_CIPHERS_LIST = 433,
     ADVERTISED_ADDRESS = 434,
     ADVERTISED_PORT = 435,
     DISABLE_CORE = 436,
     OPEN_FD_LIMIT = 437,
     MCAST_LOOPBACK = 438,
     MCAST_TTL = 439,
     TOS = 440,
     DISABLE_DNS_FAILOVER = 441,
     DISABLE_DNS_BLACKLIST = 442,
     DST_BLACKLIST = 443,
     DISABLE_STATELESS_FWD = 444,
     DB_VERSION_TABLE = 445,
     DB_DEFAULT_URL = 446,
     DISABLE_503_TRANSLATION = 447,
     EQUAL = 448,
     EQUAL_T = 449,
     GT = 450,
     LT = 451,
     GTE = 452,
     LTE = 453,
     DIFF = 454,
     MATCH = 455,
     NOTMATCH = 456,
     COLONEQ = 457,
     PLUSEQ = 458,
     MINUSEQ = 459,
     SLASHEQ = 460,
     MULTEQ = 461,
     MODULOEQ = 462,
     BANDEQ = 463,
     BOREQ = 464,
     BXOREQ = 465,
     AND = 466,
     OR = 467,
     BRSHIFT = 468,
     BLSHIFT = 469,
     BXOR = 470,
     BAND = 471,
     BOR = 472,
     MODULO = 473,
     MULT = 474,
     SLASH = 475,
     MINUS = 476,
     PLUS = 477,
     BNOT = 478,
     NOT = 479,
     NUMBER = 480,
     ZERO = 481,
     ID = 482,
     STRING = 483,
     SCRIPTVAR = 484,
     IPV6ADDR = 485,
     COMMA = 486,
     SEMICOLON = 487,
     RPAREN = 488,
     LPAREN = 489,
     LBRACE = 490,
     RBRACE = 491,
     LBRACK = 492,
     RBRACK = 493,
     AS = 494,
     USE_CHILDREN = 495,
     DOT = 496,
     CR = 497,
     COLON = 498,
     ANY = 499,
     SCRIPTVARERR = 500
   };
#endif
/* Tokens.  */
#define FORWARD 258
#define SEND 259
#define DROP 260
#define EXIT 261
#define RETURN 262
#define LOG_TOK 263
#define ERROR 264
#define ROUTE 265
#define ROUTE_FAILURE 266
#define ROUTE_ONREPLY 267
#define ROUTE_BRANCH 268
#define ROUTE_ERROR 269
#define ROUTE_LOCAL 270
#define ROUTE_STARTUP 271
#define ROUTE_TIMER 272
#define ROUTE_EVENT 273
#define SET_HOST 274
#define SET_HOSTPORT 275
#define PREFIX 276
#define STRIP 277
#define STRIP_TAIL 278
#define APPEND_BRANCH 279
#define REMOVE_BRANCH 280
#define PV_PRINTF 281
#define SET_USER 282
#define SET_USERPASS 283
#define SET_PORT 284
#define SET_URI 285
#define REVERT_URI 286
#define SET_DSTURI 287
#define RESET_DSTURI 288
#define ISDSTURISET 289
#define FORCE_RPORT 290
#define FORCE_LOCAL_RPORT 291
#define FORCE_TCP_ALIAS 292
#define IF 293
#define ELSE 294
#define SWITCH 295
#define CASE 296
#define DEFAULT 297
#define SBREAK 298
#define WHILE 299
#define SET_ADV_ADDRESS 300
#define SET_ADV_PORT 301
#define FORCE_SEND_SOCKET 302
#define SERIALIZE_BRANCHES 303
#define NEXT_BRANCHES 304
#define USE_BLACKLIST 305
#define UNUSE_BLACKLIST 306
#define MAX_LEN 307
#define SETDEBUG 308
#define SETFLAG 309
#define RESETFLAG 310
#define ISFLAGSET 311
#define SETBFLAG 312
#define RESETBFLAG 313
#define ISBFLAGSET 314
#define SETSFLAG 315
#define RESETSFLAG 316
#define ISSFLAGSET 317
#define METHOD 318
#define URI 319
#define FROM_URI 320
#define TO_URI 321
#define SRCIP 322
#define SRCPORT 323
#define DSTIP 324
#define DSTPORT 325
#define PROTO 326
#define AF 327
#define MYSELF 328
#define MSGLEN 329
#define UDP 330
#define TCP 331
#define TLS 332
#define SCTP 333
#define NULLV 334
#define CACHE_STORE 335
#define CACHE_FETCH 336
#define CACHE_COUNTER_FETCH 337
#define CACHE_REMOVE 338
#define CACHE_ADD 339
#define CACHE_SUB 340
#define CACHE_RAW_QUERY 341
#define XDBG 342
#define XLOG 343
#define XLOG_BUF_SIZE 344
#define XLOG_FORCE_COLOR 345
#define RAISE_EVENT 346
#define SUBSCRIBE_EVENT 347
#define CONSTRUCT_URI 348
#define GET_TIMESTAMP 349
#define SCRIPT_TRACE 350
#define DEBUG 351
#define FORK 352
#define LOGSTDERROR 353
#define LOGFACILITY 354
#define LOGNAME 355
#define AVP_ALIASES 356
#define LISTEN 357
#define ALIAS 358
#define AUTO_ALIASES 359
#define DNS 360
#define REV_DNS 361
#define DNS_TRY_IPV6 362
#define DNS_RETR_TIME 363
#define DNS_RETR_NO 364
#define DNS_SERVERS_NO 365
#define DNS_USE_SEARCH 366
#define MAX_WHILE_LOOPS 367
#define PORT 368
#define CHILDREN 369
#define CHECK_VIA 370
#define MEMLOG 371
#define MEMDUMP 372
#define EXECMSGTHRESHOLD 373
#define EXECDNSTHRESHOLD 374
#define TCPTHRESHOLD 375
#define EVENT_SHM_THRESHOLD 376
#define EVENT_PKG_THRESHOLD 377
#define QUERYBUFFERSIZE 378
#define QUERYFLUSHTIME 379
#define SIP_WARNING 380
#define SOCK_MODE 381
#define SOCK_USER 382
#define SOCK_GROUP 383
#define UNIX_SOCK 384
#define UNIX_SOCK_CHILDREN 385
#define UNIX_TX_TIMEOUT 386
#define SERVER_SIGNATURE 387
#define SERVER_HEADER 388
#define USER_AGENT_HEADER 389
#define LOADMODULE 390
#define MPATH 391
#define MODPARAM 392
#define MAXBUFFER 393
#define USER 394
#define GROUP 395
#define CHROOT 396
#define WDIR 397
#define MHOMED 398
#define DISABLE_TCP 399
#define TCP_ACCEPT_ALIASES 400
#define TCP_CHILDREN 401
#define TCP_CONNECT_TIMEOUT 402
#define TCP_SEND_TIMEOUT 403
#define TCP_CON_LIFETIME 404
#define TCP_LISTEN_BACKLOG 405
#define TCP_POLL_METHOD 406
#define TCP_MAX_CONNECTIONS 407
#define TCP_OPT_CRLF_PINGPONG 408
#define TCP_NO_NEW_CONN_BFLAG 409
#define TCP_KEEPALIVE 410
#define TCP_KEEPCOUNT 411
#define TCP_KEEPIDLE 412
#define TCP_KEEPINTERVAL 413
#define DISABLE_TLS 414
#define TLSLOG 415
#define TLS_PORT_NO 416
#define TLS_METHOD 417
#define TLS_HANDSHAKE_TIMEOUT 418
#define TLS_SEND_TIMEOUT 419
#define TLS_SERVER_DOMAIN 420
#define TLS_CLIENT_DOMAIN 421
#define TLS_CLIENT_DOMAIN_AVP 422
#define SSLv23 423
#define SSLv2 424
#define SSLv3 425
#define TLSv1 426
#define TLS_VERIFY_CLIENT 427
#define TLS_VERIFY_SERVER 428
#define TLS_REQUIRE_CLIENT_CERTIFICATE 429
#define TLS_CERTIFICATE 430
#define TLS_PRIVATE_KEY 431
#define TLS_CA_LIST 432
#define TLS_CIPHERS_LIST 433
#define ADVERTISED_ADDRESS 434
#define ADVERTISED_PORT 435
#define DISABLE_CORE 436
#define OPEN_FD_LIMIT 437
#define MCAST_LOOPBACK 438
#define MCAST_TTL 439
#define TOS 440
#define DISABLE_DNS_FAILOVER 441
#define DISABLE_DNS_BLACKLIST 442
#define DST_BLACKLIST 443
#define DISABLE_STATELESS_FWD 444
#define DB_VERSION_TABLE 445
#define DB_DEFAULT_URL 446
#define DISABLE_503_TRANSLATION 447
#define EQUAL 448
#define EQUAL_T 449
#define GT 450
#define LT 451
#define GTE 452
#define LTE 453
#define DIFF 454
#define MATCH 455
#define NOTMATCH 456
#define COLONEQ 457
#define PLUSEQ 458
#define MINUSEQ 459
#define SLASHEQ 460
#define MULTEQ 461
#define MODULOEQ 462
#define BANDEQ 463
#define BOREQ 464
#define BXOREQ 465
#define AND 466
#define OR 467
#define BRSHIFT 468
#define BLSHIFT 469
#define BXOR 470
#define BAND 471
#define BOR 472
#define MODULO 473
#define MULT 474
#define SLASH 475
#define MINUS 476
#define PLUS 477
#define BNOT 478
#define NOT 479
#define NUMBER 480
#define ZERO 481
#define ID 482
#define STRING 483
#define SCRIPTVAR 484
#define IPV6ADDR 485
#define COMMA 486
#define SEMICOLON 487
#define RPAREN 488
#define LPAREN 489
#define LBRACE 490
#define RBRACE 491
#define LBRACK 492
#define RBRACK 493
#define AS 494
#define USE_CHILDREN 495
#define DOT 496
#define CR 497
#define COLON 498
#define ANY 499
#define SCRIPTVARERR 500




/* Copy the first part of user declarations.  */
#line 77 "cfg.y"


#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <string.h>
#include <errno.h>
#include "route_struct.h"
#include "globals.h"
#include "route.h"
#include "dprint.h"
#include "sr_module.h"
#include "modparam.h"
#include "ip_addr.h"
#include "resolve.h"
#include "socket_info.h"
#include "name_alias.h"
#include "ut.h"
#include "dset.h"
#include "pvar.h"
#include "blacklists.h"
#include "xlog.h"
#include "tcp_server.h"
#include "tcp_conn.h"
#include "db/db_insertq.h"


#include "config.h"
#ifdef USE_TLS
#include "tls/tls_config.h"
#include "tls/tls_domain.h"
#endif

#ifdef DEBUG_DMALLOC
#include <dmalloc.h>
#endif

/* hack to avoid alloca usage in the generated C file (needed for compiler
 with no built in alloca, like icc*/
#undef _ALLOCA_H


extern int yylex();
static void yyerror(char* s);
static void yyerrorf(char* fmt, ...);
static char* tmp;
static int i_tmp;
static void* cmd_tmp;
static struct socket_id* lst_tmp;
static int rt;  /* Type of route block for find_export */
static str* str_tmp;
static str s_tmp;
static str tstr;
static struct ip_addr* ip_tmp;
static pv_spec_t *spec;
static pv_elem_t *pvmodel;
static struct bl_rule *bl_head = 0;
static struct bl_rule *bl_tail = 0;
static struct stat statf;

action_elem_t elems[MAX_ACTION_ELEMS];
static action_elem_t route_elems[MAX_ACTION_ELEMS];
action_elem_t *a_tmp;

static inline void warn(char* s);
static struct socket_id* mk_listen_id(char*, int, int);
static struct socket_id* set_listen_id_adv(struct socket_id *, char *, int);

static char *mpath=NULL;
static char mpath_buf[256];
static int  mpath_len = 0;

extern int line;

#define mk_action0(_res, _type, _p1_type, _p2_type, _p1, _p2) \
	do { \
		_res = mk_action(_type, 0, 0, line); \
	} while(0)
#define mk_action1(_res, _type, _p1_type, _p1) \
	do { \
		elems[0].type = _p1_type; \
		elems[0].u.data = _p1; \
		_res = mk_action(_type, 1, elems, line); \
	} while(0)
#define	mk_action2(_res, _type, _p1_type, _p2_type, _p1, _p2) \
	do { \
		elems[0].type = _p1_type; \
		elems[0].u.data = _p1; \
		elems[1].type = _p2_type; \
		elems[1].u.data = _p2; \
		_res = mk_action(_type, 2, elems, line); \
	} while(0)
#define mk_action3(_res, _type, _p1_type, _p2_type, _p3_type, _p1, _p2, _p3) \
	do { \
		elems[0].type = _p1_type; \
		elems[0].u.data = _p1; \
		elems[1].type = _p2_type; \
		elems[1].u.data = _p2; \
		elems[2].type = _p3_type; \
		elems[2].u.data = _p3; \
		_res = mk_action(_type, 3, elems, line); \
	} while(0)



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 189 "cfg.y"
{
	long intval;
	unsigned long uval;
	char* strval;
	struct expr* expr;
	struct action* action;
	struct net* ipnet;
	struct ip_addr* ipaddr;
	struct socket_id* sockid;
	struct _pv_spec *specval;
}
/* Line 187 of yacc.c.  */
#line 710 "cfg.tab.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 723 "cfg.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  207
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   5296

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  246
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  78
/* YYNRULES -- Number of rules.  */
#define YYNRULES  643
/* YYNRULES -- Number of states.  */
#define YYNSTATES  1333

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   500

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   200,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
     215,   216,   217,   218,   219,   220,   221,   222,   223,   224,
     225,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,   237,   238,   239,   240,   241,   242,   243,   244,
     245
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     8,    10,    13,    15,    17,    18,
      21,    22,    25,    26,    29,    30,    33,    34,    37,    38,
      41,    42,    45,    46,    49,    50,    53,    55,    57,    59,
      61,    63,    65,    67,    69,    71,    73,    75,    77,    80,
      83,    85,    89,    93,    99,   103,   105,   108,   110,   114,
     118,   124,   130,   138,   140,   143,   153,   164,   168,   170,
     173,   177,   181,   185,   189,   193,   197,   201,   205,   209,
     213,   217,   221,   225,   229,   233,   237,   241,   244,   248,
     251,   255,   258,   262,   265,   269,   272,   276,   280,   284,
     288,   292,   296,   300,   304,   308,   312,   316,   320,   324,
     328,   332,   336,   340,   344,   348,   352,   356,   360,   364,
     368,   372,   376,   380,   384,   388,   392,   396,   400,   404,
     408,   412,   416,   420,   424,   428,   432,   436,   440,   444,
     448,   452,   456,   460,   464,   468,   472,   476,   480,   484,
     488,   492,   496,   500,   504,   508,   512,   516,   520,   524,
     528,   532,   536,   540,   544,   548,   552,   556,   560,   564,
     568,   572,   576,   580,   584,   588,   592,   596,   600,   604,
     608,   612,   616,   620,   624,   628,   632,   636,   640,   644,
     648,   652,   656,   660,   664,   668,   672,   676,   680,   684,
     688,   692,   696,   700,   702,   704,   708,   712,   716,   720,
     724,   728,   732,   736,   740,   744,   748,   752,   756,   760,
     764,   768,   772,   776,   780,   784,   788,   792,   796,   800,
     804,   808,   812,   816,   820,   824,   828,   832,   836,   840,
     843,   847,   850,   858,   862,   866,   870,   874,   878,   882,
     886,   889,   892,   895,   904,   913,   916,   918,   920,   928,
     930,   932,   936,   937,   948,   949,   960,   961,   970,   972,
     975,   977,   980,   984,   988,   992,   996,  1000,  1004,  1008,
    1012,  1016,  1020,  1024,  1028,  1032,  1036,  1040,  1044,  1048,
    1052,  1056,  1060,  1064,  1068,  1072,  1076,  1080,  1084,  1088,
    1092,  1096,  1100,  1104,  1108,  1110,  1112,  1114,  1119,  1127,
    1130,  1138,  1141,  1146,  1154,  1157,  1165,  1168,  1173,  1176,
    1181,  1184,  1189,  1192,  1202,  1205,  1213,  1216,  1220,  1224,
    1227,  1231,  1235,  1237,  1239,  1241,  1243,  1245,  1247,  1249,
    1251,  1253,  1255,  1257,  1259,  1261,  1263,  1265,  1267,  1269,
    1271,  1273,  1275,  1277,  1279,  1281,  1285,  1289,  1293,  1297,
    1301,  1305,  1309,  1313,  1316,  1320,  1324,  1328,  1332,  1336,
    1340,  1344,  1348,  1352,  1355,  1359,  1363,  1366,  1370,  1374,
    1377,  1381,  1385,  1388,  1392,  1396,  1399,  1403,  1407,  1411,
    1414,  1418,  1422,  1426,  1429,  1433,  1437,  1441,  1444,  1448,
    1452,  1456,  1460,  1463,  1467,  1471,  1473,  1477,  1479,  1481,
    1483,  1487,  1491,  1493,  1495,  1497,  1499,  1501,  1503,  1505,
    1507,  1509,  1511,  1513,  1515,  1517,  1519,  1521,  1523,  1527,
    1531,  1535,  1539,  1543,  1547,  1551,  1555,  1559,  1563,  1566,
    1570,  1574,  1578,  1582,  1584,  1586,  1588,  1592,  1595,  1597,
    1601,  1604,  1607,  1609,  1612,  1615,  1617,  1619,  1621,  1624,
    1626,  1629,  1633,  1639,  1643,  1651,  1654,  1656,  1659,  1661,
    1668,  1674,  1679,  1683,  1690,  1696,  1701,  1705,  1709,  1712,
    1714,  1718,  1720,  1724,  1726,  1728,  1730,  1734,  1738,  1742,
    1747,  1751,  1754,  1759,  1764,  1771,  1774,  1779,  1783,  1785,
    1789,  1791,  1796,  1801,  1805,  1807,  1812,  1819,  1822,  1827,
    1832,  1836,  1839,  1844,  1849,  1852,  1857,  1862,  1865,  1870,
    1875,  1878,  1883,  1888,  1891,  1896,  1901,  1904,  1909,  1914,
    1917,  1924,  1931,  1936,  1941,  1944,  1951,  1958,  1963,  1968,
    1971,  1978,  1985,  1990,  1995,  1998,  2005,  2008,  2013,  2018,
    2025,  2028,  2033,  2038,  2041,  2046,  2051,  2054,  2059,  2064,
    2067,  2072,  2077,  2080,  2085,  2092,  2097,  2101,  2103,  2108,
    2113,  2120,  2127,  2132,  2135,  2140,  2145,  2148,  2153,  2158,
    2161,  2166,  2171,  2174,  2179,  2184,  2187,  2192,  2196,  2198,
    2203,  2206,  2211,  2215,  2217,  2221,  2223,  2227,  2229,  2233,
    2235,  2240,  2244,  2246,  2251,  2256,  2261,  2264,  2269,  2274,
    2277,  2282,  2287,  2290,  2295,  2300,  2303,  2307,  2312,  2315,
    2320,  2325,  2328,  2333,  2338,  2341,  2350,  2361,  2372,  2379,
    2388,  2397,  2408,  2419,  2430,  2441,  2450,  2457,  2461,  2466,
    2471,  2474,  2479,  2484,  2491,  2496,  2503,  2512,  2519,  2528,
    2543,  2550,  2554,  2561
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     247,     0,    -1,   248,    -1,   248,   249,    -1,   249,    -1,
     248,     1,    -1,   269,    -1,   270,    -1,    -1,   250,   285,
      -1,    -1,   251,   286,    -1,    -1,   252,   287,    -1,    -1,
     253,   288,    -1,    -1,   254,   289,    -1,    -1,   255,   290,
      -1,    -1,   256,   291,    -1,    -1,   257,   292,    -1,    -1,
     258,   293,    -1,   242,    -1,   271,    -1,   228,    -1,   306,
      -1,    75,    -1,    76,    -1,    77,    -1,    78,    -1,   244,
      -1,   225,    -1,   244,    -1,   225,    -1,   222,   225,    -1,
     221,   225,    -1,   259,    -1,   259,   243,   261,    -1,   260,
     243,   259,    -1,   260,   243,   259,   243,   261,    -1,   259,
     243,     1,    -1,   263,    -1,   263,   264,    -1,   263,    -1,
     263,   240,   225,    -1,   263,   239,   259,    -1,   263,   239,
     259,   240,   225,    -1,   263,   239,   259,   243,   261,    -1,
     263,   239,   259,   243,   261,   240,   225,    -1,   265,    -1,
     265,   266,    -1,   234,   260,   231,   304,   231,   261,   231,
     228,   233,    -1,   224,   234,   260,   231,   304,   231,   261,
     231,   228,   233,    -1,   268,   231,   267,    -1,   267,    -1,
     268,     1,    -1,    96,   193,   262,    -1,    96,   193,     1,
      -1,    97,   193,   225,    -1,    97,   193,     1,    -1,    98,
     193,   225,    -1,    98,   193,     1,    -1,    99,   193,   227,
      -1,    99,   193,     1,    -1,   100,   193,   228,    -1,   100,
     193,     1,    -1,   101,   193,   228,    -1,   101,   193,     1,
      -1,   105,   193,   225,    -1,   105,   193,     1,    -1,   106,
     193,   225,    -1,   106,   193,     1,    -1,   107,   193,   225,
      -1,   107,     1,    -1,   108,   193,   225,    -1,   108,     1,
      -1,   109,   193,   225,    -1,   109,     1,    -1,   110,   193,
     225,    -1,   110,     1,    -1,   111,   193,   225,    -1,   111,
       1,    -1,   113,   193,   225,    -1,   113,   193,     1,    -1,
     112,   193,   225,    -1,   112,   193,     1,    -1,   138,   193,
     225,    -1,   138,   193,     1,    -1,   114,   193,   225,    -1,
     114,   193,     1,    -1,   115,   193,   225,    -1,   115,   193,
       1,    -1,   116,   193,   225,    -1,   116,   193,     1,    -1,
     117,   193,   225,    -1,   117,   193,     1,    -1,   118,   193,
     225,    -1,   118,   193,     1,    -1,   119,   193,   225,    -1,
     119,   193,     1,    -1,   120,   193,   225,    -1,   120,   193,
       1,    -1,   121,   193,   225,    -1,   121,   193,     1,    -1,
     122,   193,   225,    -1,   122,   193,     1,    -1,   123,   193,
     225,    -1,   123,   193,     1,    -1,   124,   193,   225,    -1,
     124,   193,     1,    -1,   125,   193,   225,    -1,   125,   193,
       1,    -1,   139,   193,   228,    -1,   139,   193,   227,    -1,
     139,   193,     1,    -1,   140,   193,   228,    -1,   140,   193,
     227,    -1,   140,   193,     1,    -1,   141,   193,   228,    -1,
     141,   193,   227,    -1,   141,   193,     1,    -1,   142,   193,
     228,    -1,   142,   193,   227,    -1,   142,   193,     1,    -1,
     143,   193,   225,    -1,   143,   193,     1,    -1,   144,   193,
     225,    -1,   144,   193,     1,    -1,   145,   193,   225,    -1,
     145,   193,     1,    -1,   146,   193,   225,    -1,   146,   193,
       1,    -1,   147,   193,   225,    -1,   147,   193,     1,    -1,
     148,   193,   225,    -1,   148,   193,     1,    -1,   149,   193,
     225,    -1,   149,   193,     1,    -1,   150,   193,   225,    -1,
     150,   193,     1,    -1,   151,   193,   227,    -1,   151,   193,
     228,    -1,   151,   193,     1,    -1,   152,   193,   225,    -1,
     152,   193,     1,    -1,   153,   193,   225,    -1,   153,   193,
       1,    -1,   154,   193,   225,    -1,   154,   193,   227,    -1,
     154,   193,     1,    -1,   155,   193,   225,    -1,   155,   193,
       1,    -1,   156,   193,   225,    -1,   156,   193,     1,    -1,
     157,   193,   225,    -1,   157,   193,     1,    -1,   158,   193,
     225,    -1,   158,   193,     1,    -1,   159,   193,   225,    -1,
     159,   193,     1,    -1,   160,   193,   225,    -1,   160,   193,
       1,    -1,   161,   193,   225,    -1,   161,   193,     1,    -1,
     162,   193,   168,    -1,   162,   193,   169,    -1,   162,   193,
     170,    -1,   162,   193,   171,    -1,   162,   193,     1,    -1,
     172,   193,   225,    -1,   172,   193,     1,    -1,   173,   193,
     225,    -1,   173,   193,     1,    -1,   174,   193,   225,    -1,
     174,   193,     1,    -1,   175,   193,   228,    -1,   175,   193,
       1,    -1,   176,   193,   228,    -1,   176,   193,     1,    -1,
     177,   193,   228,    -1,   177,   193,     1,    -1,   178,   193,
     228,    -1,   178,   193,     1,    -1,   163,   193,   225,    -1,
     163,   193,     1,    -1,   164,   193,   225,    -1,   164,   193,
       1,    -1,   167,   193,   228,    -1,   167,   193,     1,    -1,
     275,    -1,   277,    -1,   132,   193,   225,    -1,   132,   193,
       1,    -1,   133,   193,   228,    -1,   133,   193,     1,    -1,
     134,   193,   228,    -1,   134,   193,     1,    -1,    89,   193,
     225,    -1,    90,   193,   225,    -1,    89,   193,     1,    -1,
      90,   193,     1,    -1,   102,   193,   266,    -1,   102,   193,
       1,    -1,   103,   193,   264,    -1,   103,   193,     1,    -1,
     104,   193,   225,    -1,   104,   193,     1,    -1,   179,   193,
     259,    -1,   179,   193,     1,    -1,   180,   193,   225,    -1,
     180,   193,     1,    -1,   181,   193,   225,    -1,   181,   193,
       1,    -1,   182,   193,   225,    -1,   182,   193,     1,    -1,
     183,   193,   225,    -1,   183,   193,     1,    -1,   184,   193,
     225,    -1,   184,   193,     1,    -1,   185,   193,   225,    -1,
     185,   193,   227,    -1,   185,   193,     1,    -1,   136,   193,
     228,    -1,   136,   193,     1,    -1,   186,   193,   225,    -1,
     186,     1,    -1,   187,   193,   225,    -1,   187,     1,    -1,
     188,   193,   227,   243,   235,   268,   236,    -1,   189,   193,
     225,    -1,   190,   193,   228,    -1,   190,   193,     1,    -1,
     191,   193,   228,    -1,   191,   193,     1,    -1,   192,   193,
     225,    -1,   192,   193,     1,    -1,     1,   193,    -1,   135,
     228,    -1,   135,     1,    -1,   137,   234,   228,   231,   228,
     231,   228,   233,    -1,   137,   234,   228,   231,   228,   231,
     262,   233,    -1,   137,     1,    -1,   272,    -1,   274,    -1,
     225,   241,   225,   241,   225,   241,   225,    -1,   230,    -1,
     273,    -1,   237,   273,   238,    -1,    -1,   165,   237,   271,
     243,   261,   238,   276,   235,   280,   236,    -1,    -1,   166,
     237,   271,   243,   261,   238,   278,   235,   281,   236,    -1,
      -1,   166,   237,   228,   238,   279,   235,   281,   236,    -1,
     282,    -1,   280,   282,    -1,   283,    -1,   281,   283,    -1,
     162,   193,   168,    -1,   162,   193,   169,    -1,   162,   193,
     170,    -1,   162,   193,   171,    -1,   162,   193,     1,    -1,
     175,   193,   228,    -1,   175,   193,     1,    -1,   176,   193,
     228,    -1,   176,   193,     1,    -1,   177,   193,   228,    -1,
     177,   193,     1,    -1,   178,   193,   228,    -1,   178,   193,
       1,    -1,   172,   193,   225,    -1,   172,   193,     1,    -1,
     174,   193,   225,    -1,   174,   193,     1,    -1,   162,   193,
     168,    -1,   162,   193,   169,    -1,   162,   193,   170,    -1,
     162,   193,   171,    -1,   162,   193,     1,    -1,   175,   193,
     228,    -1,   175,   193,     1,    -1,   176,   193,   228,    -1,
     176,   193,     1,    -1,   177,   193,   228,    -1,   177,   193,
       1,    -1,   178,   193,   228,    -1,   178,   193,     1,    -1,
     173,   193,   225,    -1,   173,   193,     1,    -1,   227,    -1,
     225,    -1,   228,    -1,    10,   235,   312,   236,    -1,    10,
     237,   284,   238,   235,   312,   236,    -1,    10,     1,    -1,
      11,   237,   284,   238,   235,   312,   236,    -1,    11,     1,
      -1,    12,   235,   312,   236,    -1,    12,   237,   284,   238,
     235,   312,   236,    -1,    12,     1,    -1,    13,   237,   284,
     238,   235,   312,   236,    -1,    13,     1,    -1,    14,   235,
     312,   236,    -1,    14,     1,    -1,    15,   235,   312,   236,
      -1,    15,     1,    -1,    16,   235,   312,   236,    -1,    16,
       1,    -1,    17,   237,   284,   231,   225,   238,   235,   312,
     236,    -1,    17,     1,    -1,    18,   237,   284,   238,   235,
     312,   236,    -1,    18,     1,    -1,   294,   211,   294,    -1,
     294,   212,   294,    -1,   224,   294,    -1,   234,   294,   233,
      -1,   237,   308,   238,    -1,   302,    -1,   194,    -1,   199,
      -1,   195,    -1,   196,    -1,   197,    -1,   198,    -1,   200,
      -1,   201,    -1,   295,    -1,   296,    -1,   295,    -1,   296,
      -1,   297,    -1,    64,    -1,    65,    -1,    66,    -1,   229,
      -1,   245,    -1,   303,    -1,   310,    -1,   262,    -1,   301,
      -1,   300,   299,   306,    -1,    69,   295,   304,    -1,    69,
     299,   306,    -1,    67,   295,   304,    -1,    67,   299,   306,
      -1,    63,   299,   228,    -1,    63,   299,   227,    -1,    63,
     299,     1,    -1,    63,     1,    -1,   301,   299,   301,    -1,
     301,   299,   228,    -1,   301,   299,   227,    -1,   301,   298,
     262,    -1,   301,   295,    73,    -1,   301,   295,    79,    -1,
     300,   299,   228,    -1,   300,   295,    73,    -1,   300,   299,
       1,    -1,   300,     1,    -1,    68,   298,   225,    -1,    68,
     298,     1,    -1,    68,     1,    -1,    70,   298,   225,    -1,
      70,   298,     1,    -1,    70,     1,    -1,    71,   298,   260,
      -1,    71,   298,     1,    -1,    71,     1,    -1,    72,   298,
     225,    -1,    72,   298,     1,    -1,    72,     1,    -1,    74,
     298,   225,    -1,    74,   298,    52,    -1,    74,   298,     1,
      -1,    74,     1,    -1,    67,   299,   228,    -1,    67,   295,
      73,    -1,    67,   299,     1,    -1,    67,     1,    -1,    69,
     299,   228,    -1,    69,   295,    73,    -1,    69,   299,     1,
      -1,    69,     1,    -1,    73,   295,   300,    -1,    73,   295,
      67,    -1,    73,   295,    69,    -1,    73,   295,     1,    -1,
      73,     1,    -1,   271,   220,   271,    -1,   271,   220,   225,
      -1,   271,    -1,   271,   220,     1,    -1,   241,    -1,   221,
      -1,   227,    -1,   306,   305,   227,    -1,   306,   241,     1,
      -1,   193,    -1,   202,    -1,   203,    -1,   204,    -1,   205,
      -1,   206,    -1,   207,    -1,   208,    -1,   209,    -1,   210,
      -1,   262,    -1,   228,    -1,   227,    -1,   301,    -1,   303,
      -1,   323,    -1,   308,   222,   308,    -1,   308,   221,   308,
      -1,   308,   219,   308,    -1,   308,   220,   308,    -1,   308,
     218,   308,    -1,   308,   216,   308,    -1,   308,   217,   308,
      -1,   308,   215,   308,    -1,   308,   214,   308,    -1,   308,
     213,   308,    -1,   223,   308,    -1,   234,   308,   233,    -1,
     301,   307,   308,    -1,   301,   193,    79,    -1,   301,   202,
      79,    -1,   323,    -1,   314,    -1,   309,    -1,   235,   312,
     236,    -1,   235,   236,    -1,   313,    -1,   235,   312,   236,
      -1,   235,   236,    -1,   312,   313,    -1,   313,    -1,   312,
       1,    -1,   323,   232,    -1,   314,    -1,   315,    -1,   316,
      -1,   309,   232,    -1,   232,    -1,   323,     1,    -1,    38,
     294,   311,    -1,    38,   294,   311,    39,   311,    -1,    44,
     294,   311,    -1,    40,   234,   301,   233,   235,   317,   236,
      -1,   318,   320,    -1,   318,    -1,   318,   319,    -1,   319,
      -1,    41,   262,   243,   312,    43,   232,    -1,    41,   262,
     243,    43,   232,    -1,    41,   262,   243,   312,    -1,    41,
     262,   243,    -1,    41,   228,   243,   312,    43,   232,    -1,
      41,   228,   243,    43,   232,    -1,    41,   228,   243,   312,
      -1,    41,   228,   243,    -1,    42,   243,   312,    -1,    42,
     243,    -1,   228,    -1,   321,   231,   228,    -1,   225,    -1,
     321,   231,   225,    -1,   228,    -1,   225,    -1,   301,    -1,
     322,   231,   228,    -1,   322,   231,   225,    -1,   322,   231,
     301,    -1,     3,   234,   228,   233,    -1,     3,   234,   233,
      -1,     3,     1,    -1,     3,   234,     1,   233,    -1,     4,
     234,   228,   233,    -1,     4,   234,   228,   231,   228,   233,
      -1,     4,     1,    -1,     4,   234,     1,   233,    -1,     5,
     234,   233,    -1,     5,    -1,     6,   234,   233,    -1,     6,
      -1,     7,   234,   262,   233,    -1,     7,   234,   301,   233,
      -1,     7,   234,   233,    -1,     7,    -1,     8,   234,   228,
     233,    -1,     8,   234,   262,   231,   228,   233,    -1,     8,
       1,    -1,     8,   234,     1,   233,    -1,    53,   234,   262,
     233,    -1,    53,   234,   233,    -1,    53,     1,    -1,    54,
     234,   225,   233,    -1,    54,   234,   227,   233,    -1,    54,
       1,    -1,    55,   234,   225,   233,    -1,    55,   234,   227,
     233,    -1,    55,     1,    -1,    56,   234,   225,   233,    -1,
      56,   234,   227,   233,    -1,    56,     1,    -1,    60,   234,
     225,   233,    -1,    60,   234,   227,   233,    -1,    60,     1,
      -1,    61,   234,   225,   233,    -1,    61,   234,   227,   233,
      -1,    61,     1,    -1,    62,   234,   225,   233,    -1,    62,
     234,   227,   233,    -1,    62,     1,    -1,    57,   234,   225,
     231,   225,   233,    -1,    57,   234,   225,   231,   227,   233,
      -1,    57,   234,   225,   233,    -1,    57,   234,   227,   233,
      -1,    57,     1,    -1,    58,   234,   225,   231,   225,   233,
      -1,    58,   234,   225,   231,   227,   233,    -1,    58,   234,
     225,   233,    -1,    58,   234,   227,   233,    -1,    58,     1,
      -1,    59,   234,   225,   231,   225,   233,    -1,    59,   234,
     225,   231,   227,   233,    -1,    59,   234,   225,   233,    -1,
      59,   234,   227,   233,    -1,    59,     1,    -1,     9,   234,
     228,   231,   228,   233,    -1,     9,     1,    -1,     9,   234,
       1,   233,    -1,    10,   234,   284,   233,    -1,    10,   234,
     284,   231,   322,   233,    -1,    10,     1,    -1,    10,   234,
       1,   233,    -1,    19,   234,   228,   233,    -1,    19,     1,
      -1,    19,   234,     1,   233,    -1,    21,   234,   228,   233,
      -1,    21,     1,    -1,    21,   234,     1,   233,    -1,    23,
     234,   225,   233,    -1,    23,     1,    -1,    23,   234,     1,
     233,    -1,    22,   234,   225,   233,    -1,    22,     1,    -1,
      22,   234,     1,   233,    -1,    24,   234,   228,   231,   228,
     233,    -1,    24,   234,   228,   233,    -1,    24,   234,   233,
      -1,    24,    -1,    25,   234,   225,   233,    -1,    25,   234,
     301,   233,    -1,    26,   234,   228,   231,   228,   233,    -1,
      26,   234,   301,   231,   228,   233,    -1,    20,   234,   228,
     233,    -1,    20,     1,    -1,    20,   234,     1,   233,    -1,
      29,   234,   228,   233,    -1,    29,     1,    -1,    29,   234,
       1,   233,    -1,    27,   234,   228,   233,    -1,    27,     1,
      -1,    27,   234,     1,   233,    -1,    28,   234,   228,   233,
      -1,    28,     1,    -1,    28,   234,     1,   233,    -1,    30,
     234,   228,   233,    -1,    30,     1,    -1,    30,   234,     1,
     233,    -1,    31,   234,   233,    -1,    31,    -1,    32,   234,
     228,   233,    -1,    32,     1,    -1,    32,   234,     1,   233,
      -1,    33,   234,   233,    -1,    33,    -1,    34,   234,   233,
      -1,    34,    -1,    35,   234,   233,    -1,    35,    -1,    36,
     234,   233,    -1,    36,    -1,    37,   234,   225,   233,    -1,
      37,   234,   233,    -1,    37,    -1,    37,   234,     1,   233,
      -1,    45,   234,   259,   233,    -1,    45,   234,     1,   233,
      -1,    45,     1,    -1,    46,   234,   225,   233,    -1,    46,
     234,     1,   233,    -1,    46,     1,    -1,    47,   234,   263,
     233,    -1,    47,   234,     1,   233,    -1,    47,     1,    -1,
      48,   234,   225,   233,    -1,    48,   234,     1,   233,    -1,
      48,     1,    -1,    49,   234,   233,    -1,    49,   234,     1,
     233,    -1,    49,     1,    -1,    50,   234,   228,   233,    -1,
      50,   234,     1,   233,    -1,    50,     1,    -1,    51,   234,
     228,   233,    -1,    51,   234,     1,   233,    -1,    51,     1,
      -1,    80,   234,   228,   231,   228,   231,   228,   233,    -1,
      80,   234,   228,   231,   228,   231,   228,   231,   225,   233,
      -1,    80,   234,   228,   231,   228,   231,   228,   231,   301,
     233,    -1,    83,   234,   228,   231,   228,   233,    -1,    81,
     234,   228,   231,   228,   231,   301,   233,    -1,    82,   234,
     228,   231,   228,   231,   301,   233,    -1,    84,   234,   228,
     231,   228,   231,   225,   231,   225,   233,    -1,    84,   234,
     228,   231,   228,   231,   301,   231,   225,   233,    -1,    85,
     234,   228,   231,   228,   231,   225,   231,   225,   233,    -1,
      85,   234,   228,   231,   228,   231,   301,   231,   225,   233,
      -1,    86,   234,   228,   231,   228,   231,   228,   233,    -1,
      86,   234,   228,   231,   228,   233,    -1,   227,   234,   233,
      -1,   227,   234,   321,   233,    -1,   227,   234,     1,   233,
      -1,   227,     1,    -1,    87,   234,   228,   233,    -1,    88,
     234,   228,   233,    -1,    88,   234,   228,   231,   228,   233,
      -1,    91,   234,   228,   233,    -1,    91,   234,   228,   231,
     301,   233,    -1,    91,   234,   228,   231,   301,   231,   301,
     233,    -1,    92,   234,   228,   231,   228,   233,    -1,    92,
     234,   228,   231,   228,   231,   225,   233,    -1,    93,   234,
     228,   231,   228,   231,   228,   231,   228,   231,   228,   231,
     301,   233,    -1,    94,   234,   301,   231,   301,   233,    -1,
      95,   234,   233,    -1,    95,   234,   225,   231,   228,   233,
      -1,    95,   234,   225,   231,   228,   231,   228,   233,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   481,   481,   484,   485,   486,   489,   490,   491,   491,
     492,   492,   493,   493,   494,   494,   495,   495,   496,   496,
     497,   497,   498,   498,   499,   499,   501,   504,   517,   524,
     537,   538,   539,   547,   554,   557,   558,   561,   562,   563,
     567,   568,   569,   570,   571,   574,   575,   579,   580,   581,
     582,   583,   584,   587,   588,   592,   599,   609,   610,   611,
     615,   622,   623,   624,   625,   626,   627,   633,   634,   635,
     636,   639,   640,   641,   642,   643,   644,   645,   646,   647,
     648,   649,   650,   651,   652,   653,   654,   655,   656,   657,
     658,   659,   660,   661,   662,   663,   664,   665,   666,   667,
     668,   669,   670,   671,   672,   673,   674,   687,   688,   697,
     698,   699,   700,   701,   702,   703,   704,   705,   706,   707,
     708,   709,   710,   711,   712,   713,   714,   715,   716,   717,
     718,   725,   726,   733,   734,   741,   742,   749,   750,   757,
     758,   765,   766,   773,   774,   788,   802,   803,   810,   811,
     818,   819,   830,   840,   841,   848,   849,   860,   861,   872,
     873,   884,   885,   892,   893,   900,   901,   908,   909,   919,
     929,   939,   949,   958,   966,   967,   975,   976,   983,   984,
     994,   995,  1005,  1006,  1016,  1017,  1027,  1028,  1035,  1036,
    1043,  1044,  1055,  1056,  1057,  1058,  1059,  1060,  1063,  1064,
    1067,  1068,  1069,  1070,  1071,  1073,  1089,  1092,  1097,  1099,
    1100,  1101,  1107,  1109,  1121,  1123,  1126,  1127,  1130,  1131,
    1138,  1139,  1146,  1147,  1151,  1178,  1179,  1187,  1188,  1191,
    1192,  1195,  1196,  1206,  1209,  1210,  1211,  1212,  1213,  1214,
    1217,  1220,  1259,  1260,  1266,  1272,  1276,  1277,  1280,  1314,
    1334,  1335,  1338,  1338,  1349,  1349,  1360,  1360,  1371,  1372,
    1375,  1376,  1379,  1386,  1393,  1400,  1407,  1408,  1415,  1417,
    1424,  1426,  1433,  1434,  1441,  1442,  1449,  1450,  1457,  1461,
    1468,  1475,  1482,  1489,  1491,  1498,  1500,  1507,  1509,  1516,
    1517,  1524,  1525,  1532,  1535,  1538,  1545,  1550,  1558,  1573,
    1576,  1582,  1585,  1593,  1599,  1602,  1608,  1611,  1619,  1622,
    1630,  1633,  1641,  1644,  1656,  1659,  1665,  1670,  1671,  1672,
    1673,  1674,  1675,  1678,  1679,  1682,  1683,  1684,  1685,  1687,
    1688,  1691,  1692,  1695,  1696,  1697,  1700,  1701,  1702,  1705,
    1719,  1724,  1725,  1726,  1728,  1731,  1733,  1735,  1737,  1739,
    1743,  1745,  1747,  1748,  1751,  1754,  1757,  1760,  1763,  1766,
    1769,  1771,  1773,  1774,  1777,  1779,  1780,  1781,  1783,  1784,
    1785,  1787,  1790,  1791,  1793,  1794,  1795,  1797,  1799,  1800,
    1801,  1815,  1817,  1819,  1821,  1835,  1837,  1839,  1841,  1843,
    1845,  1847,  1849,  1854,  1855,  1866,  1867,  1874,  1875,  1878,
    1879,  1891,  1895,  1896,  1897,  1898,  1899,  1900,  1901,  1902,
    1903,  1904,  1908,  1909,  1910,  1911,  1912,  1913,  1914,  1917,
    1920,  1923,  1926,  1929,  1932,  1935,  1938,  1941,  1944,  1947,
    1950,  1963,  1976,  1998,  1999,  2000,  2001,  2002,  2005,  2006,
    2007,  2010,  2011,  2012,  2015,  2016,  2017,  2018,  2019,  2020,
    2021,  2024,  2032,  2042,  2050,  2059,  2060,  2062,  2063,  2066,
    2075,  2084,  2092,  2100,  2109,  2118,  2126,  2137,  2143,  2151,
    2156,  2165,  2169,  2175,  2180,  2185,  2190,  2200,  2210,  2222,
    2228,  2235,  2236,  2239,  2245,  2251,  2252,  2254,  2255,  2256,
    2257,  2258,  2264,  2270,  2276,  2282,  2285,  2291,  2292,  2294,
    2296,  2297,  2298,  2300,  2302,  2303,  2305,  2307,  2308,  2310,
    2312,  2313,  2315,  2317,  2318,  2320,  2322,  2323,  2325,  2327,
    2328,  2332,  2336,  2339,  2342,  2343,  2347,  2351,  2355,  2359,
    2360,  2364,  2368,  2372,  2376,  2377,  2383,  2384,  2386,  2393,
    2411,  2412,  2414,  2416,  2417,  2420,  2422,  2423,  2425,  2427,
    2428,  2431,  2433,  2434,  2436,  2444,  2446,  2448,  2450,  2452,
    2455,  2478,  2493,  2495,  2496,  2498,  2500,  2501,  2503,  2505,
    2506,  2508,  2510,  2511,  2513,  2515,  2516,  2518,  2519,  2520,
    2522,  2523,  2525,  2527,  2528,  2529,  2530,  2532,  2533,  2535,
    2537,  2545,  2552,  2559,  2562,  2566,  2568,  2569,  2585,  2587,
    2588,  2592,  2595,  2596,  2600,  2603,  2604,  2607,  2610,  2611,
    2615,  2618,  2619,  2623,  2626,  2627,  2636,  2648,  2661,  2668,
    2677,  2686,  2697,  2708,  2719,  2730,  2739,  2746,  2763,  2780,
    2782,  2784,  2786,  2788,  2790,  2792,  2794,  2796,  2798,  2800,
    2814,  2820,  2822,  2830
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "FORWARD", "SEND", "DROP", "EXIT",
  "RETURN", "LOG_TOK", "ERROR", "ROUTE", "ROUTE_FAILURE", "ROUTE_ONREPLY",
  "ROUTE_BRANCH", "ROUTE_ERROR", "ROUTE_LOCAL", "ROUTE_STARTUP",
  "ROUTE_TIMER", "ROUTE_EVENT", "SET_HOST", "SET_HOSTPORT", "PREFIX",
  "STRIP", "STRIP_TAIL", "APPEND_BRANCH", "REMOVE_BRANCH", "PV_PRINTF",
  "SET_USER", "SET_USERPASS", "SET_PORT", "SET_URI", "REVERT_URI",
  "SET_DSTURI", "RESET_DSTURI", "ISDSTURISET", "FORCE_RPORT",
  "FORCE_LOCAL_RPORT", "FORCE_TCP_ALIAS", "IF", "ELSE", "SWITCH", "CASE",
  "DEFAULT", "SBREAK", "WHILE", "SET_ADV_ADDRESS", "SET_ADV_PORT",
  "FORCE_SEND_SOCKET", "SERIALIZE_BRANCHES", "NEXT_BRANCHES",
  "USE_BLACKLIST", "UNUSE_BLACKLIST", "MAX_LEN", "SETDEBUG", "SETFLAG",
  "RESETFLAG", "ISFLAGSET", "SETBFLAG", "RESETBFLAG", "ISBFLAGSET",
  "SETSFLAG", "RESETSFLAG", "ISSFLAGSET", "METHOD", "URI", "FROM_URI",
  "TO_URI", "SRCIP", "SRCPORT", "DSTIP", "DSTPORT", "PROTO", "AF",
  "MYSELF", "MSGLEN", "UDP", "TCP", "TLS", "SCTP", "NULLV", "CACHE_STORE",
  "CACHE_FETCH", "CACHE_COUNTER_FETCH", "CACHE_REMOVE", "CACHE_ADD",
  "CACHE_SUB", "CACHE_RAW_QUERY", "XDBG", "XLOG", "XLOG_BUF_SIZE",
  "XLOG_FORCE_COLOR", "RAISE_EVENT", "SUBSCRIBE_EVENT", "CONSTRUCT_URI",
  "GET_TIMESTAMP", "SCRIPT_TRACE", "DEBUG", "FORK", "LOGSTDERROR",
  "LOGFACILITY", "LOGNAME", "AVP_ALIASES", "LISTEN", "ALIAS",
  "AUTO_ALIASES", "DNS", "REV_DNS", "DNS_TRY_IPV6", "DNS_RETR_TIME",
  "DNS_RETR_NO", "DNS_SERVERS_NO", "DNS_USE_SEARCH", "MAX_WHILE_LOOPS",
  "PORT", "CHILDREN", "CHECK_VIA", "MEMLOG", "MEMDUMP", "EXECMSGTHRESHOLD",
  "EXECDNSTHRESHOLD", "TCPTHRESHOLD", "EVENT_SHM_THRESHOLD",
  "EVENT_PKG_THRESHOLD", "QUERYBUFFERSIZE", "QUERYFLUSHTIME",
  "SIP_WARNING", "SOCK_MODE", "SOCK_USER", "SOCK_GROUP", "UNIX_SOCK",
  "UNIX_SOCK_CHILDREN", "UNIX_TX_TIMEOUT", "SERVER_SIGNATURE",
  "SERVER_HEADER", "USER_AGENT_HEADER", "LOADMODULE", "MPATH", "MODPARAM",
  "MAXBUFFER", "USER", "GROUP", "CHROOT", "WDIR", "MHOMED", "DISABLE_TCP",
  "TCP_ACCEPT_ALIASES", "TCP_CHILDREN", "TCP_CONNECT_TIMEOUT",
  "TCP_SEND_TIMEOUT", "TCP_CON_LIFETIME", "TCP_LISTEN_BACKLOG",
  "TCP_POLL_METHOD", "TCP_MAX_CONNECTIONS", "TCP_OPT_CRLF_PINGPONG",
  "TCP_NO_NEW_CONN_BFLAG", "TCP_KEEPALIVE", "TCP_KEEPCOUNT",
  "TCP_KEEPIDLE", "TCP_KEEPINTERVAL", "DISABLE_TLS", "TLSLOG",
  "TLS_PORT_NO", "TLS_METHOD", "TLS_HANDSHAKE_TIMEOUT", "TLS_SEND_TIMEOUT",
  "TLS_SERVER_DOMAIN", "TLS_CLIENT_DOMAIN", "TLS_CLIENT_DOMAIN_AVP",
  "SSLv23", "SSLv2", "SSLv3", "TLSv1", "TLS_VERIFY_CLIENT",
  "TLS_VERIFY_SERVER", "TLS_REQUIRE_CLIENT_CERTIFICATE", "TLS_CERTIFICATE",
  "TLS_PRIVATE_KEY", "TLS_CA_LIST", "TLS_CIPHERS_LIST",
  "ADVERTISED_ADDRESS", "ADVERTISED_PORT", "DISABLE_CORE", "OPEN_FD_LIMIT",
  "MCAST_LOOPBACK", "MCAST_TTL", "TOS", "DISABLE_DNS_FAILOVER",
  "DISABLE_DNS_BLACKLIST", "DST_BLACKLIST", "DISABLE_STATELESS_FWD",
  "DB_VERSION_TABLE", "DB_DEFAULT_URL", "DISABLE_503_TRANSLATION", "EQUAL",
  "EQUAL_T", "GT", "LT", "GTE", "LTE", "DIFF", "MATCH", "NOTMATCH",
  "COLONEQ", "PLUSEQ", "MINUSEQ", "SLASHEQ", "MULTEQ", "MODULOEQ",
  "BANDEQ", "BOREQ", "BXOREQ", "AND", "OR", "BRSHIFT", "BLSHIFT", "BXOR",
  "BAND", "BOR", "MODULO", "MULT", "SLASH", "MINUS", "PLUS", "BNOT", "NOT",
  "NUMBER", "ZERO", "ID", "STRING", "SCRIPTVAR", "IPV6ADDR", "COMMA",
  "SEMICOLON", "RPAREN", "LPAREN", "LBRACE", "RBRACE", "LBRACK", "RBRACK",
  "AS", "USE_CHILDREN", "DOT", "CR", "COLON", "ANY", "SCRIPTVARERR",
  "$accept", "cfg", "statements", "statement", "@1", "@2", "@3", "@4",
  "@5", "@6", "@7", "@8", "@9", "listen_id", "proto", "port", "snumber",
  "phostport", "id_lst", "listen_def", "listen_lst", "blst_elem",
  "blst_elem_list", "assign_stm", "module_stm", "ip", "ipv4", "ipv6addr",
  "ipv6", "tls_server_domain_stm", "@10", "tls_client_domain_stm", "@11",
  "@12", "tls_server_decls", "tls_client_decls", "tls_server_var",
  "tls_client_var", "route_name", "route_stm", "failure_route_stm",
  "onreply_route_stm", "branch_route_stm", "error_route_stm",
  "local_route_stm", "startup_route_stm", "timer_route_stm",
  "event_route_stm", "exp", "equalop", "compop", "matchop", "intop",
  "strop", "uri_type", "script_var", "exp_elem", "exp_cond", "ipnet",
  "host_sep", "host", "assignop", "assignexp", "assign_cmd", "exp_stm",
  "stm", "actions", "action", "if_cmd", "while_cmd", "switch_cmd",
  "switch_stm", "case_stms", "case_stm", "default_stm",
  "module_func_param", "route_param", "cmd", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417,   418,   419,   420,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   453,   454,
     455,   456,   457,   458,   459,   460,   461,   462,   463,   464,
     465,   466,   467,   468,   469,   470,   471,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     485,   486,   487,   488,   489,   490,   491,   492,   493,   494,
     495,   496,   497,   498,   499,   500
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   246,   247,   248,   248,   248,   249,   249,   250,   249,
     251,   249,   252,   249,   253,   249,   254,   249,   255,   249,
     256,   249,   257,   249,   258,   249,   249,   259,   259,   259,
     260,   260,   260,   260,   260,   261,   261,   262,   262,   262,
     263,   263,   263,   263,   263,   264,   264,   265,   265,   265,
     265,   265,   265,   266,   266,   267,   267,   268,   268,   268,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   269,   269,   269,   269,   269,   269,   269,   269,   269,
     269,   270,   270,   270,   270,   270,   271,   271,   272,   273,
     274,   274,   276,   275,   278,   277,   279,   277,   280,   280,
     281,   281,   282,   282,   282,   282,   282,   282,   282,   282,
     282,   282,   282,   282,   282,   282,   282,   282,   282,   283,
     283,   283,   283,   283,   283,   283,   283,   283,   283,   283,
     283,   283,   283,   283,   284,   284,   284,   285,   285,   285,
     286,   286,   287,   287,   287,   288,   288,   289,   289,   290,
     290,   291,   291,   292,   292,   293,   293,   294,   294,   294,
     294,   294,   294,   295,   295,   296,   296,   296,   296,   297,
     297,   298,   298,   299,   299,   299,   300,   300,   300,   301,
     301,   302,   302,   302,   302,   302,   302,   302,   302,   302,
     303,   303,   303,   303,   303,   303,   303,   303,   303,   303,
     303,   303,   303,   303,   303,   303,   303,   303,   303,   303,
     303,   303,   303,   303,   303,   303,   303,   303,   303,   303,
     303,   303,   303,   303,   303,   303,   303,   303,   303,   303,
     303,   303,   303,   304,   304,   304,   304,   305,   305,   306,
     306,   306,   307,   307,   307,   307,   307,   307,   307,   307,
     307,   307,   308,   308,   308,   308,   308,   308,   308,   308,
     308,   308,   308,   308,   308,   308,   308,   308,   308,   308,
     309,   309,   309,   310,   310,   310,   310,   310,   311,   311,
     311,   312,   312,   312,   313,   313,   313,   313,   313,   313,
     313,   314,   314,   315,   316,   317,   317,   318,   318,   319,
     319,   319,   319,   319,   319,   319,   319,   320,   320,   321,
     321,   321,   321,   322,   322,   322,   322,   322,   322,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     1,     2,     1,     1,     0,     2,
       0,     2,     0,     2,     0,     2,     0,     2,     0,     2,
       0,     2,     0,     2,     0,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     2,
       1,     3,     3,     5,     3,     1,     2,     1,     3,     3,
       5,     5,     7,     1,     2,     9,    10,     3,     1,     2,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     1,     1,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     2,
       3,     2,     7,     3,     3,     3,     3,     3,     3,     3,
       2,     2,     2,     8,     8,     2,     1,     1,     7,     1,
       1,     3,     0,    10,     0,    10,     0,     8,     1,     2,
       1,     2,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     1,     1,     1,     4,     7,     2,
       7,     2,     4,     7,     2,     7,     2,     4,     2,     4,
       2,     4,     2,     9,     2,     7,     2,     3,     3,     2,
       3,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     3,     3,     3,     3,
       3,     3,     3,     2,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     2,     3,     3,     2,     3,     3,     2,
       3,     3,     2,     3,     3,     2,     3,     3,     3,     2,
       3,     3,     3,     2,     3,     3,     3,     2,     3,     3,
       3,     3,     2,     3,     3,     1,     3,     1,     1,     1,
       3,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     2,     3,
       3,     3,     3,     1,     1,     1,     3,     2,     1,     3,
       2,     2,     1,     2,     2,     1,     1,     1,     2,     1,
       2,     3,     5,     3,     7,     2,     1,     2,     1,     6,
       5,     4,     3,     6,     5,     4,     3,     3,     2,     1,
       3,     1,     3,     1,     1,     1,     3,     3,     3,     4,
       3,     2,     4,     4,     6,     2,     4,     3,     1,     3,
       1,     4,     4,     3,     1,     4,     6,     2,     4,     4,
       3,     2,     4,     4,     2,     4,     4,     2,     4,     4,
       2,     4,     4,     2,     4,     4,     2,     4,     4,     2,
       6,     6,     4,     4,     2,     6,     6,     4,     4,     2,
       6,     6,     4,     4,     2,     6,     2,     4,     4,     6,
       2,     4,     4,     2,     4,     4,     2,     4,     4,     2,
       4,     4,     2,     4,     6,     4,     3,     1,     4,     4,
       6,     6,     4,     2,     4,     4,     2,     4,     4,     2,
       4,     4,     2,     4,     4,     2,     4,     3,     1,     4,
       2,     4,     3,     1,     3,     1,     3,     1,     3,     1,
       4,     3,     1,     4,     4,     4,     2,     4,     4,     2,
       4,     4,     2,     4,     4,     2,     3,     4,     2,     4,
       4,     2,     4,     4,     2,     8,    10,    10,     6,     8,
       8,    10,    10,    10,    10,     8,     6,     3,     4,     4,
       2,     4,     4,     6,     4,     6,     8,     6,     8,    14,
       6,     3,     6,     8
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    26,     0,     0,     4,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     6,     7,   193,   194,   240,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    77,     0,    79,     0,    81,     0,    83,     0,
      85,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   242,
     241,     0,   245,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   229,     0,
     231,     0,     0,     0,     0,     0,     0,     1,     5,     3,
       0,     9,     0,    11,     0,    13,     0,    15,     0,    17,
       0,    19,     0,    21,     0,    23,     0,    25,   203,   201,
     204,   202,    61,     0,     0,    37,    60,    63,    62,    65,
      64,    67,    66,    69,    68,    71,    70,   206,    30,    31,
      32,    33,     0,   399,    28,   249,     0,    34,    40,     0,
      47,    53,   205,    27,   246,   250,   247,    29,   208,    45,
     207,   210,   209,    73,    72,    75,    74,    76,    78,    80,
      82,    84,    89,    88,    87,    86,    93,    92,    95,    94,
      97,    96,    99,    98,   101,   100,   103,   102,   105,   104,
     107,   106,   109,   108,   111,   110,   113,   112,   115,   114,
     196,   195,   198,   197,   200,   199,   227,   226,     0,    91,
      90,   118,   117,   116,   121,   120,   119,   124,   123,   122,
     127,   126,   125,   129,   128,   131,   130,   133,   132,   135,
     134,   137,   136,   139,   138,   141,   140,   143,   142,   146,
     144,   145,   148,   147,   150,   149,   153,   151,   152,   155,
     154,   157,   156,   159,   158,   161,   160,   163,   162,   165,
     164,   167,   166,   172,   168,   169,   170,   171,   188,   187,
     190,   189,     0,     0,     0,   192,   191,   174,   173,   176,
     175,   178,   177,   180,   179,   182,   181,   184,   183,   186,
     185,   212,   211,   214,   213,   216,   215,   218,   217,   220,
     219,   222,   221,   225,   223,   224,   228,   230,     0,   233,
     235,   234,   237,   236,   239,   238,   299,     0,     0,   301,
       0,   304,     0,     0,   306,     0,   308,     0,   310,     0,
     312,     0,   314,     0,   316,     0,    39,    38,     0,     0,
       0,     0,     0,     0,    54,   398,     0,     0,    46,     0,
       0,   256,     0,     0,     0,     0,   488,   490,   494,     0,
       0,     0,     0,     0,     0,     0,     0,   557,     0,     0,
       0,     0,     0,     0,   578,     0,   583,   585,   587,   589,
     592,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   339,   449,   340,     0,
       0,     0,   442,   445,   446,   447,     0,   295,   294,   296,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   251,    44,    35,    36,    41,    42,    49,    48,   401,
     400,     0,     0,     0,     0,     0,   481,     0,   485,     0,
       0,     0,     0,   497,     0,   536,     0,   540,     0,   543,
       0,   563,     0,   546,     0,   552,     0,   549,     0,     0,
       0,     0,   569,     0,   572,     0,   566,     0,   575,     0,
       0,   580,     0,     0,     0,     0,     0,     0,     0,   336,
     337,   338,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   343,     0,     0,   344,   322,   341,
     435,   342,   434,   433,     0,     0,   596,     0,   599,     0,
     602,     0,   605,     0,   608,     0,   611,     0,   614,     0,
     501,     0,   504,     0,   507,     0,   510,     0,   524,     0,
     529,     0,   534,     0,   513,     0,   516,     0,   519,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   630,     0,   402,   403,   404,   405,
     406,   407,   408,   409,   410,   411,     0,   448,   443,   297,
     441,   450,   444,     0,     0,   302,     0,     0,   307,   309,
     311,     0,     0,     0,     0,     0,     0,     0,   252,     0,
     254,     0,     0,    58,     0,     0,     0,   480,     0,     0,
     487,   489,   493,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   556,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   577,     0,     0,   582,
     584,   586,   588,     0,     0,   591,   353,   323,   325,   326,
     327,   328,   324,   329,   330,   333,   334,   335,     0,   383,
     333,     0,   366,   331,   332,     0,   387,   333,     0,   369,
       0,   372,     0,   375,     0,   392,     0,   379,     0,   319,
       0,   437,     0,     0,     0,     0,     0,   413,     0,   412,
       0,   415,   416,     0,   417,     0,     0,     0,   451,   438,
     363,   333,     0,   333,   334,     0,     0,     0,   453,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   606,     0,
       0,     0,     0,   500,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   641,     0,   471,
     469,   627,     0,   431,   432,   430,     0,     0,     0,     0,
       0,     0,     0,    43,    50,    51,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   260,     0,     0,     0,
      59,     0,   232,   482,   479,   486,     0,   483,   491,   492,
     498,   495,     0,   537,     0,   541,     0,   538,   544,   542,
     564,   562,   547,   545,   553,   551,   550,   548,     0,   555,
     558,   559,     0,     0,   570,   568,   573,   571,   567,   565,
     576,   574,   581,   579,   593,   590,   352,   351,   350,   381,
     395,   348,   382,   380,   349,   365,   364,   385,   346,   386,
     384,   347,   368,   367,   371,   370,   374,   373,   391,   389,
     390,   388,   378,   377,   376,   320,   436,   333,     0,   333,
       0,   428,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   321,   317,   318,   440,     0,     0,
     361,   362,   360,   345,   358,   359,   357,   356,   355,   354,
       0,   595,   594,   598,   597,   601,   600,   604,   603,   607,
     610,   609,   613,   612,   499,   502,   503,   505,   506,   508,
     509,     0,   522,   523,     0,   527,   528,     0,   532,   533,
     511,   512,   514,   515,   517,   518,     0,     0,     0,     0,
       0,     0,     0,   631,     0,   632,     0,   634,     0,     0,
       0,     0,   629,     0,   628,     0,     0,     0,     0,     0,
       0,     0,     0,   243,   244,     0,     0,     0,     0,     0,
       0,     0,   257,   261,     0,     0,     0,    57,     0,     0,
       0,   474,   473,   475,     0,     0,     0,     0,     0,   429,
     427,   426,   425,   423,   424,   422,   420,   421,   419,   418,
     439,   452,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   472,   470,   298,   300,   303,   305,     0,   315,
     248,    52,     0,     0,     0,     0,     0,     0,     0,     0,
     258,   283,   279,   280,   281,   282,   293,   292,   285,   284,
     287,   286,   289,   288,   291,   290,     0,     0,     0,   484,
     496,   535,     0,   539,   554,   560,   561,   396,   394,   393,
       0,     0,   456,   458,   520,   521,   525,   526,   530,   531,
       0,     0,     0,   618,     0,     0,     0,   626,   633,     0,
     635,     0,   637,     0,   640,     0,   642,     0,     0,     0,
       0,     0,     0,     0,     0,   253,   259,   255,     0,     0,
     477,   476,   478,     0,     0,   454,     0,   457,   455,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   313,   266,   262,   263,   264,   265,   276,   275,   278,
     277,   268,   267,   270,   269,   272,   271,   274,   273,     0,
       0,   466,   462,   468,     0,   615,   619,   620,     0,     0,
       0,     0,   625,   636,   638,     0,   643,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   464,     0,   460,     0,   616,   617,   621,
     622,   623,   624,     0,     0,    55,   463,   459,     0,    56,
       0,     0,   639
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    92,    93,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   258,   259,   555,   819,   260,   270,   261,
     262,   723,   724,   104,   105,   263,   264,   265,   266,   106,
     908,   107,   917,   563,  1169,   915,  1170,   916,   540,   211,
     213,   215,   217,   219,   221,   223,   225,   227,   625,   793,
     786,   787,   835,   836,   820,   529,   628,   822,   971,   457,
     267,   696,   823,   530,   631,   828,   531,   532,   533,   534,
     535,  1201,  1202,  1203,  1248,   892,  1114,   536
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -898
static const yytype_int16 yypact[] =
{
    5054,  -132,  -128,   -95,   -88,   -22,    -5,    49,   144,   318,
     360,   389,   392,   401,   415,    51,    52,    55,    56,   580,
     434,   439,   463,   471,   523,   524,   541,   560,   561,   595,
     605,   606,   615,   629,   649,   654,   658,   153,   665,    23,
     678,   708,   709,   718,   729,   732,   756,   838,   858,   867,
     909,   910,   913,   920,   921,   941,   964,   987,   993,   995,
     996,  1010,  1012,  1013,  1014,  1035,  1048,   -12,     6,  1068,
    1070,  1085,  1086,  1093,  1102,  1103,  1104,  1105,  1106,  1107,
    1108,  1109,  1130,  1132,   582,   592,  1133,  1143,  1164,  1165,
    1166,  -898,   640,  3642,  -898,   613,   669,   697,   668,   719,
     743,   728,   794,   976,  -898,  -898,  -898,  -898,  -898,   129,
     134,   254,   145,   168,    32,   175,   191,    26,    39,   249,
     260,   305,  -898,     7,  -898,   587,  -898,   795,  -898,   857,
    -898,   901,   338,   378,   419,   423,   438,   477,   479,   480,
     481,   482,   485,   486,   487,   488,   493,   195,   199,  -898,
    -898,   200,  -898,   936,   494,   150,   179,   182,   184,   495,
     496,   497,   498,   500,   501,   507,   511,   186,   512,   513,
     239,   514,   515,   516,   517,   518,   530,   531,   335,   532,
     534,   620,   887,   201,   535,   536,   537,   202,   203,   204,
     205,    54,   538,   540,   553,   554,   555,   246,  -898,   942,
    -898,  1135,  1100,  1136,   206,   207,   556,  -898,  -132,  -898,
      62,  -898,    31,  -898,    63,  -898,    34,  -898,    37,  -898,
      70,  -898,    72,  -898,    48,  -898,    66,  -898,  -898,  -898,
    -898,  -898,  -898,  1137,  1138,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,   907,  -898,  -898,  -898,  1144,  -898,  1155,  1156,
     -61,   891,  -898,  -898,  -898,  -898,  -898,  -179,  -898,   891,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  1142,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  1157,  1163,  1159,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  1160,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  4904,   559,  -898,
     559,  -898,  4904,   559,  -898,   559,  -898,  4904,  -898,  4904,
    -898,  4904,  -898,   559,  -898,   559,  -898,  -898,  1179,  1167,
      21,   827,   827,  1181,  -898,  -898,   238,  1180,  -898,  1182,
    -184,  -898,  -184,  1173,    76,    77,  1175,  1177,  1178,    78,
      79,    80,    81,    82,    83,    84,    85,  1183,  1185,  1186,
      86,    88,    90,    91,  1188,    92,  1190,  1192,  1193,  1194,
    1195,  3832,  1196,  3832,    93,    94,    95,    96,    99,   109,
     110,   111,   112,   117,   128,   131,   132,   133,   139,   140,
     141,  1197,  1198,  1199,  1201,  1202,  1203,  1204,  1205,  1206,
    1207,  1208,  1209,  1210,  1211,   142,  -898,  -898,  -898,   968,
    1191,  1284,  -898,  -898,  -898,  -898,    89,  -898,  -898,  -898,
    1176,  1212,  1518,  1213,  1214,  1613,  1847,  1942,  1184,  1215,
    1172,  -898,  -898,  -898,  -898,  -898,  1216,   -83,  -898,  -898,
    -898,  1217,  1218,  1219,  1220,  -165,  -898,   167,  -898,   208,
    1222,  1224,   417,  -898,   180,  -898,   209,  -898,   169,  -898,
     210,  -898,   212,  -898,   213,  -898,   557,  -898,   564,   -51,
     355,   -55,  -898,   214,  -898,   215,  -898,   216,  -898,   217,
    1227,  -898,   218,  1228,  1229,  1230,  1231,   122,   476,  -898,
    -898,  -898,   489,   573,   499,   621,   630,   636,    42,   642,
    3832,  3832,  4173,  3925,  -898,  4080,   551,  1187,  -898,  -898,
    -898,  -898,  -898,  -898,  -175,  4080,  -898,    65,  -898,   565,
    -898,    50,  -898,   566,  -898,    29,  -898,   219,  -898,   220,
    -898,   393,  -898,   -41,  -898,   370,  -898,   403,  -898,   420,
    -898,   430,  -898,   539,  -898,   634,  -898,   673,  -898,   730,
    1221,  1237,  1238,  1239,  1240,  1241,  1242,  1243,  1244,  1245,
    1246,  1247,  -175,  -157,  -898,   107,  1367,  1368,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  3925,  -898,  -898,  -898,
    -898,  -898,  -898,  1248,  1249,  -898,  1250,  1251,  -898,  -898,
    -898,  1252,  1253,  1254,  -184,  1255,  -184,   805,  -898,   974,
    -898,  1256,   558,  -898,    73,  1258,  1259,  -898,  1260,   739,
    -898,  -898,  -898,  1261,  1262,  1263,  1264,  1267,  1266,  1269,
    1268,   740,  1270,  1271,  1272,  1273,  1274,  1275,  1276,  1277,
    1279,  1281,   790,  -898,  1282,  1285,  1286,  1299,  1298,  1300,
    1301,  1302,  1303,  1324,  1326,  1327,  -898,  1328,  1337,  -898,
    -898,  -898,  -898,  1348,  1349,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,   188,  -898,
     618,   190,  -898,  -898,  -898,   567,  -898,   619,   194,  -898,
     568,  -898,    44,  -898,   569,  -898,   808,  -898,   123,  -898,
     366,  -898,  2176,   489,   499,  3925,   859,  -898,  3925,  -898,
     551,  1059,  -898,   924,  -898,  3832,  3832,  4407,  1437,  -898,
    -898,  1405,   198,   797,   457,   702,   -80,  1350,  -898,  1351,
    1352,  1353,  1354,  1355,  1356,  1357,  1358,  1359,  -898,  1360,
    1361,  1362,  1363,  -898,  1364,  1374,  1375,  1382,  1391,  1392,
    1393,   801,  1394,   836,  1395,   889,  1396,  1397,  1398,  1419,
    1421,  1422,  1423,  1434,  1445,  1446,  1447,  1448,  1449,  1450,
    1451,   892,   896,  1452,  1454,  1455,  1456,  -898,  1457,  -898,
    -898,  -898,   899,  -898,  -898,  1134,  4904,  4904,  4904,  4904,
    1294,  4904,  1441,  -898,  -898,  1462,  1458,  1459,  1453,  1288,
    1289,  1296,  1309,  1496,  1510,   413,  -898,  1474,   558,  1479,
    -898,  -165,  -898,  -898,  -898,  -898,  1483,  -898,  -898,  -898,
    -898,  -898,  1484,  -898,  1485,  -898,   384,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  1486,  -898,
    -898,  -898,  1487,  1488,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    1497,  -898,  -898,  -898,  -179,  -898,  -898,  -898,  -898,  -898,
    -898,  -179,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  1414,   221,  1645,
     222,  -898,   715,   223,  3925,  3925,  3925,  3925,  3925,  3925,
    3925,  3925,  3925,  3925,  -898,  -898,  -898,  -898,  2271,  4500,
    -898,  -898,  -898,  -179,  -898,  -898,  -898,  -898,  -898,  -898,
    1489,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,   906,  -898,  -898,   928,  -898,  -898,   929,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  1491,  1492,  1493,  1494,
    1495,  1498,  1499,  -898,  1500,  -898,  -175,  -898,  1501,  1502,
    -175,  1503,  -898,   351,  -898,  2505,  2600,  2834,  2929,  1490,
    3163,  1507,  1508,  -898,  -898,  1090,   483,   570,   225,   226,
     227,   228,  -898,  -898,   974,  1504,   620,  -898,  1505,  1506,
    1509,  -898,  -898,  -898,   927,  1511,  1513,  1515,    71,  -898,
     447,   447,   447,   447,   447,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  1693,  1516,  1519,  1520,  1522,  1523,  1524,  1512,
    1527,  1528,  1529,  1530,  1533,   932,  1532,   935,   948,  1535,
    1534,   952,  -898,  -898,  -898,  -898,  -898,  -898,  4904,  -898,
    -898,  -898,  1543,  1544,  1547,  1548,  1558,  1567,  1575,   933,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,   923,   620,  1538,  -898,
    -898,  -898,   396,  -898,  -898,  -898,  -898,  -898,   907,  -898,
     862,  1536,   196,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    1542,  -175,  -175,  -898,   576,   799,  1545,  -898,  -898,  -175,
    -898,  1546,  -898,  1549,  -898,  1550,  -898,  3258,   490,   571,
     572,   229,   230,   232,   234,  -898,  -898,  -898,  1551,  -184,
    -898,  -898,  -898,  1531,  1537,  -898,  1540,  -898,  -898,   971,
    1552,  1553,  1556,  1557,  1559,  1560,  1561,  1562,  1563,  1566,
    1565,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -184,
    1568,  4656,  4749,  4904,   800,  -898,  -898,  -898,  1554,  1564,
    1576,  1577,  -898,  -898,  -898,  1572,  -898,  1573,  1578,  1571,
     955,  1579,  1189,  3492,  1574,  1580,  1581,  1582,  1583,  1584,
    1587,  1591,  1588,  -898,  1590,  -898,  1592,  -898,  -898,  -898,
    -898,  -898,  -898,  1595,  1593,  -898,  -898,  -898,  1589,  -898,
    -175,  1594,  -898
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -898,  -898,  -898,  1682,  -898,  -898,  -898,  -898,  -898,  -898,
    -898,  -898,  -898,  -178,  -215,  -456,  -111,  -107,  1539,  -898,
    1569,   855,  -898,  -898,  -898,  -180,  -898,  1525,  -898,  -898,
    -898,  -898,  -898,  -898,  -898,   680,   624,  -897,   623,  -898,
    -898,  -898,  -898,  -898,  -898,  -898,  -898,  -898,  -476,    -7,
    -569,  -898,   446,   -10,  -468,  -484,  -898,  -465,  -783,  -898,
    -660,  -898,  -621,  -457,  -898,  -620,  -429,  -526,  -454,  -898,
    -898,  -898,  -898,   590,  -898,  -898,  -898,  -462
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -468
static const yytype_int16 yytable[] =
{
     236,   382,   384,   542,   562,   700,   564,   627,   545,   627,
     546,   269,   547,   402,   978,   838,   700,   635,  1103,   700,
     700,   700,   552,   626,   152,   626,   629,   247,   629,   633,
     847,   633,   429,   241,   630,   434,   630,   632,   436,   632,
     268,   553,   455,   805,   794,   984,   794,   794,   794,   442,
     794,   843,   122,   124,   526,   401,   126,   128,   834,   721,
     554,   108,   456,   426,   431,   109,   839,   444,   886,   722,
     528,   438,  1197,   440,   920,   895,   887,   566,   568,   573,
     575,   577,   579,   581,   583,   585,   587,   592,   734,   594,
     701,   596,   598,   601,   636,   638,   640,   642,   110,   829,
     644,   248,   249,   250,   251,   111,   755,   757,   888,   829,
     646,   648,   650,   652,   248,   249,   250,   251,   654,   248,
     249,   250,   251,   773,   992,   248,   249,   250,   251,   656,
     228,   974,   658,   660,   662,   230,   627,   627,   981,   821,
     664,   666,   668,   684,   809,   810,   237,  1027,  1028,   526,
     837,   321,   626,   626,   149,   629,   629,   715,   633,   633,
     716,   824,   269,   630,   630,   528,   632,   632,   725,   239,
     740,   112,  1023,   756,   526,   993,   243,   752,   452,   453,
     324,   735,   753,   327,   855,   330,   856,   349,   113,   966,
     528,   972,   245,   812,  1001,   979,   312,  1002,   885,  1021,
     314,   316,   385,   393,   395,   397,   399,   420,   422,   728,
     738,   742,   821,   744,   746,   758,   760,   762,   764,   767,
     849,   851,   972,   979,  1021,   181,  1178,  1180,  1182,  1184,
    1271,  1273,   277,  1275,   824,  1277,   777,  1200,  1246,   559,
     356,   782,   114,   182,   123,   125,   553,   413,   127,   129,
     271,   252,   834,   253,   254,   232,   255,   153,   903,   242,
     905,   273,   848,   256,   252,   554,   253,   254,   430,   255,
     257,   435,   437,   556,   557,   252,   256,   253,   254,   252,
     255,   253,   254,   257,   255,   443,   700,   256,   257,  1103,
     252,   256,   253,   254,   257,   255,  1198,   427,   432,   428,
     433,   255,   256,   445,   921,   439,   275,   441,   256,   922,
     567,   569,   574,   576,   578,   580,   582,   584,   586,   588,
     593,   702,   595,  1188,   597,   599,   602,   637,   639,   641,
     643,   821,   889,   645,   821,   890,   373,   115,   991,   282,
     891,   627,   627,   647,   649,   651,   653,   774,   994,  1015,
    1016,   655,  1029,   824,   229,   775,   824,   626,   626,   231,
     629,   629,   657,   633,   633,   659,   661,   663,   630,   630,
     238,   632,   632,   665,   667,   669,   685,   322,   323,   284,
     624,   150,   624,  1120,  1121,  1122,  1123,  1124,  1125,  1126,
    1127,  1128,  1129,   240,   537,   726,   538,   539,  1018,  1131,
     727,   233,   234,   244,  1238,   235,   325,   326,   736,   328,
     329,   331,   332,   350,   351,   967,   968,   253,   973,   246,
     286,   253,   980,   313,   288,   253,  1022,   315,   317,   386,
     394,   396,   398,   400,   421,   423,   729,   739,   743,   290,
     745,   747,   759,   761,   763,   765,   768,   850,   852,   973,
     980,  1022,  1113,  1179,  1181,  1183,  1185,  1272,  1274,   840,
    1276,   733,  1278,   737,   357,  -397,   358,  1085,  1086,  1087,
    1088,   414,  1090,   415,   272,   233,   234,   776,   292,   235,
     294,   296,   298,   300,  1171,   274,   302,   304,   306,   308,
     789,  1262,   700,   829,   310,   319,   333,   335,   337,   339,
     796,   341,   343,   374,   375,   376,   377,   919,   345,   624,
     624,   116,   347,   352,   354,   359,   361,   363,   365,   367,
     821,   821,   821,   821,   821,   821,   821,   821,   821,   821,
     276,   369,   371,   378,   844,   380,   387,   389,   391,   403,
     854,   405,   824,   824,   824,   824,   824,   824,   824,   824,
     824,   824,   830,   117,   407,   409,   411,   424,   748,   700,
     700,   700,   700,   283,   700,   750,   841,   845,   975,   982,
     986,  1176,  1267,  1269,   792,   909,  1152,   825,   826,  1153,
     754,   130,   118,   198,   526,   119,   910,   985,   911,   912,
     913,   914,  1147,   200,   120,   857,  1150,   858,   788,   995,
     528,   785,   791,   285,   798,   790,   907,   797,   121,  1111,
     970,   806,  1112,   526,   233,   234,   832,   970,   235,   831,
     833,  1240,   799,   210,  1241,   526,   853,   132,   859,   528,
     860,   801,   133,   248,   249,   250,   251,   803,   233,   234,
     207,   528,   235,   807,   287,   861,   526,   862,   289,  1102,
     732,  1172,  1173,  1174,  1175,   863,   134,   864,  1263,  1264,
    1265,  1266,   528,   291,   135,  1009,  1010,  1011,  1012,  1013,
     777,   778,   779,   780,   781,   782,   783,   784,  -332,  -332,
     212,   216,  -332,   777,   778,   779,   780,   781,   782,   783,
     784,   969,   977,   777,   778,   779,   780,   781,   782,   783,
     784,   700,   293,  1105,   295,   297,   299,   301,  1242,   214,
     303,   305,   307,   309,   624,   624,   136,   137,   311,   320,
     334,   336,   338,   340,  1026,   342,   344,  1250,  1251,  1227,
    1253,  1255,   346,   218,   138,  1257,   348,   353,   355,   360,
     362,   364,   366,   368,   222,   777,   778,   779,   780,   781,
     782,   783,   784,   139,   140,   370,   372,   379,   220,   381,
     388,   390,   392,   404,   865,   406,   866,   777,   778,   779,
     780,   781,   782,   131,   700,   199,   700,   700,   408,   410,
     412,   425,   749,  1280,   537,   201,   538,   539,   141,   751,
     842,   846,   976,   983,   987,  1177,  1268,  1270,   142,   143,
    1305,  1252,   257,   998,  1000,   526,   997,   999,   144,   988,
    1003,   224,   278,   831,   833,   777,   778,   779,   780,   781,
     782,   528,   145,  1297,   777,   778,   779,   780,   781,   782,
     777,   778,   779,   780,   781,   782,   777,   778,   779,   780,
     781,   782,   146,   252,   252,   252,  1331,   147,   255,   255,
     255,   148,  1300,  1302,  1303,   256,   256,   256,   151,   867,
     684,   868,  -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,
    1024,   154,   609,   610,   611,   989,  1025,   990,  -414,  -414,
    -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,
    -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,   869,  -414,
     870,   155,   156,  -414,  -414,  -414,  -414,  -414,  -414,  -414,
    -414,   157,  -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,
    -414,  -414,   158,   233,   234,   159,   970,   235,  1004,  1005,
    1006,  1007,  1008,  1009,  1010,  1011,  1012,  1013,  1199,  -414,
    -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,  1119,   160,
    -414,  -414,  -414,  -414,  -414,   871,   698,   872,   464,   465,
     466,   467,   468,   469,   470,   471,   248,   249,   250,   251,
     926,   936,   927,   937,   472,   473,   474,   475,   476,   477,
     478,   479,   480,   481,   482,   483,   484,   485,   486,   487,
     488,   489,   490,   491,   226,   492,  -465,  -465,  1314,   493,
     494,   495,   496,   497,   498,   499,   500,   970,   501,   502,
     503,   504,   505,   506,   507,   508,   509,   510,  -331,  -331,
     279,   948,  -331,   949,  1254,  1304,   233,   234,   526,   526,
     235,   161,  1051,   906,  1052,   511,   512,   513,   514,   515,
     516,   517,   518,   519,   528,   528,   520,   521,   522,   523,
     524,   162,   252,   541,   253,   254,   543,   255,   544,   795,
     163,   800,   802,   804,   256,   808,   548,  1054,   549,  1055,
    -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,  -414,
    -414,  -414,   280,   233,   234,   909,  -414,   235,  -414,  1244,
    1243,  -414,  -414,   685,  -414,  1162,   910,  -414,   911,   912,
     913,   914,   164,   165,  -414,  1163,   166,  1164,  1165,  1166,
    1167,  1168,   252,   167,   168,   383,   252,   255,   253,   254,
    1057,   255,  1058,  1074,   256,  1075,   281,  1076,   256,  1077,
    1083,  1133,  1084,  1134,   169,   257,   909,  1004,  1005,  1006,
    1007,  1008,  1009,  1010,  1011,  1012,  1013,   910,   448,   911,
     912,   913,   914,  1135,  1137,  1136,  1138,   170,  1192,  1237,
    1193,   686,  1014,  1216,   318,  1217,  1219,   416,  1220,  1235,
     687,   688,   689,   690,   691,   692,   693,   694,   695,  1221,
     171,  1222,   525,  1225,   526,  1226,   172,   527,   173,   174,
     698,  -465,   464,   465,   466,   467,   468,   469,   470,   471,
     528,   741,  1284,   175,  1285,   176,   177,   178,   472,   473,
     474,   475,   476,   477,   478,   479,   480,   481,   482,   483,
     484,   485,   486,   487,   488,   489,   490,   491,   179,   492,
    -461,  -461,  1316,   493,   494,   495,   496,   497,   498,   499,
     500,   180,   501,   502,   503,   504,   505,   506,   507,   508,
     509,   510,  1162,   777,   778,   779,   780,   781,   782,   783,
     784,   183,  1163,   184,  1164,  1165,  1166,  1167,  1168,   511,
     512,   513,   514,   515,   516,   517,   518,   519,   185,   186,
     520,   521,   522,   523,   524,   698,   187,   464,   465,   466,
     467,   468,   469,   470,   471,   188,   189,   190,   191,   192,
     193,   194,   195,   472,   473,   474,   475,   476,   477,   478,
     479,   480,   481,   482,   483,   484,   485,   486,   487,   488,
     489,   490,   491,   196,   492,   197,   202,   418,   493,   494,
     495,   496,   497,   498,   499,   500,   203,   501,   502,   503,
     504,   505,   506,   507,   508,   509,   510,  1004,  1005,  1006,
    1007,  1008,  1009,  1010,  1011,  1012,  1013,   204,   205,   206,
     417,   419,   446,   447,   511,   512,   513,   514,   515,   516,
     517,   518,   519,   459,   255,   520,   521,   522,   523,   524,
     686,   777,   778,   779,   780,   781,   782,   783,   784,   687,
     688,   689,   690,   691,   692,   693,   694,   695,   450,   451,
     460,   461,   462,   463,   550,   551,   558,   560,   565,   570,
     561,   571,   572,   713,   703,   711,   525,   589,   526,   590,
     591,   527,   600,   697,   603,  -461,   604,   605,   606,   607,
     634,   670,   671,   672,   528,   673,   674,   675,   676,   677,
     678,   679,   680,   681,   682,   683,   893,   894,   717,   873,
     704,   706,   707,   712,   719,   730,   718,   731,   720,   714,
     766,   769,   770,   771,   772,   874,   875,   876,   877,   878,
     879,   880,   881,   882,   883,   884,  1019,   900,  1020,   902,
     904,  1096,  1097,   896,   897,   898,   899,   969,   901,  1098,
     918,   923,   924,   925,   928,   929,   930,   931,   932,   933,
     934,   935,  1099,   938,   939,   940,   941,   942,   943,   944,
     945,   525,   946,   526,   947,   950,   527,   952,   951,   698,
     699,   464,   465,   466,   467,   468,   469,   470,   471,   528,
     953,   954,  1089,   955,   956,   957,   958,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     485,   486,   487,   488,   489,   490,   491,   959,   492,   960,
     961,   962,   493,   494,   495,   496,   497,   498,   499,   500,
     963,   501,   502,   503,   504,   505,   506,   507,   508,   509,
     510,   964,   965,  1030,  1031,  1032,  1033,  1034,  1035,  1036,
    1037,  1038,  1039,  1040,  1041,  1042,  1043,  1044,   511,   512,
     513,   514,   515,   516,   517,   518,   519,  1045,  1046,   520,
     521,   522,   523,   524,   698,  1047,   464,   465,   466,   467,
     468,   469,   470,   471,  1048,  1049,  1050,  1053,  1056,  1059,
    1060,  1061,   472,   473,   474,   475,   476,   477,   478,   479,
     480,   481,   482,   483,   484,   485,   486,   487,   488,   489,
     490,   491,  1062,   492,  1063,  1064,  1065,   493,   494,   495,
     496,   497,   498,   499,   500,  1066,   501,   502,   503,   504,
     505,   506,   507,   508,   509,   510,  1067,  1068,  1069,  1070,
    1071,  1072,  1091,  1078,  1073,  1079,  1080,  1081,  1095,  1100,
    1082,  1093,  1094,   511,   512,   513,   514,   515,   516,   517,
     518,   519,  1092,  1101,   520,   521,   522,   523,   524,  1104,
    1106,  1108,  1109,  1110,  1115,  1116,  1117,  1118,   977,  1139,
    1140,  1141,  1142,  1143,  1132,  1158,  1144,  1145,  1146,  1148,
    1149,  1151,  1160,  1161,  1200,  1187,  1228,  1229,  1189,  1190,
    1230,  1231,  1191,  1210,  1194,   525,  1195,   526,  1196,  1204,
     527,  1232,  1205,  1206,   705,  1207,  1208,  1209,  1211,  1212,
    1233,  1214,  1213,   528,  1215,  1218,  1223,  1224,  1234,  1239,
    1249,  1258,  1245,  1256,  1281,   209,  1107,  1259,  1260,  1306,
    1282,   449,  1279,  1283,  1186,  1286,  1287,  1288,  1289,  1307,
    1290,  1291,  1247,  1236,  1292,  1293,  1294,  1295,  1296,  1298,
    1310,  1308,  1309,  1313,  1311,     0,  1312,  1317,   458,     0,
       0,  1315,     0,  1318,  1319,  1320,  1321,  1322,  1323,  1324,
    1330,  1325,  1326,  1328,  1327,     0,  1329,  1332,     0,     0,
     454,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     525,     0,   526,     0,     0,   527,     0,     0,   698,   708,
     464,   465,   466,   467,   468,   469,   470,   471,   528,     0,
       0,     0,     0,     0,     0,     0,   472,   473,   474,   475,
     476,   477,   478,   479,   480,   481,   482,   483,   484,   485,
     486,   487,   488,   489,   490,   491,     0,   492,     0,     0,
       0,   493,   494,   495,   496,   497,   498,   499,   500,     0,
     501,   502,   503,   504,   505,   506,   507,   508,   509,   510,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   511,   512,   513,
     514,   515,   516,   517,   518,   519,     0,     0,   520,   521,
     522,   523,   524,   698,     0,   464,   465,   466,   467,   468,
     469,   470,   471,     0,     0,     0,     0,     0,     0,     0,
       0,   472,   473,   474,   475,   476,   477,   478,   479,   480,
     481,   482,   483,   484,   485,   486,   487,   488,   489,   490,
     491,     0,   492,     0,     0,     0,   493,   494,   495,   496,
     497,   498,   499,   500,     0,   501,   502,   503,   504,   505,
     506,   507,   508,   509,   510,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   511,   512,   513,   514,   515,   516,   517,   518,
     519,     0,     0,   520,   521,   522,   523,   524,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   525,     0,   526,     0,     0,   527,
       0,     0,     0,   709,     0,     0,     0,     0,     0,     0,
       0,     0,   528,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   525,
       0,   526,     0,     0,   527,     0,     0,   698,   710,   464,
     465,   466,   467,   468,   469,   470,   471,   528,     0,     0,
       0,     0,     0,     0,     0,   472,   473,   474,   475,   476,
     477,   478,   479,   480,   481,   482,   483,   484,   485,   486,
     487,   488,   489,   490,   491,     0,   492,     0,     0,     0,
     493,   494,   495,   496,   497,   498,   499,   500,     0,   501,
     502,   503,   504,   505,   506,   507,   508,   509,   510,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   511,   512,   513,   514,
     515,   516,   517,   518,   519,     0,     0,   520,   521,   522,
     523,   524,   698,     0,   464,   465,   466,   467,   468,   469,
     470,   471,     0,     0,     0,     0,     0,     0,     0,     0,
     472,   473,   474,   475,   476,   477,   478,   479,   480,   481,
     482,   483,   484,   485,   486,   487,   488,   489,   490,   491,
       0,   492,     0,     0,     0,   493,   494,   495,   496,   497,
     498,   499,   500,     0,   501,   502,   503,   504,   505,   506,
     507,   508,   509,   510,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   511,   512,   513,   514,   515,   516,   517,   518,   519,
       0,     0,   520,   521,   522,   523,   524,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   525,     0,   526,     0,     0,   527,     0,
       0,     0,   996,     0,     0,     0,     0,     0,     0,     0,
       0,   528,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   525,     0,
     526,     0,     0,   527,     0,     0,   698,  1130,   464,   465,
     466,   467,   468,   469,   470,   471,   528,     0,     0,     0,
       0,     0,     0,     0,   472,   473,   474,   475,   476,   477,
     478,   479,   480,   481,   482,   483,   484,   485,   486,   487,
     488,   489,   490,   491,     0,   492,     0,     0,     0,   493,
     494,   495,   496,   497,   498,   499,   500,     0,   501,   502,
     503,   504,   505,   506,   507,   508,   509,   510,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   511,   512,   513,   514,   515,
     516,   517,   518,   519,     0,     0,   520,   521,   522,   523,
     524,   698,     0,   464,   465,   466,   467,   468,   469,   470,
     471,     0,     0,     0,     0,     0,     0,     0,     0,   472,
     473,   474,   475,   476,   477,   478,   479,   480,   481,   482,
     483,   484,   485,   486,   487,   488,   489,   490,   491,     0,
     492,     0,     0,     0,   493,   494,   495,   496,   497,   498,
     499,   500,     0,   501,   502,   503,   504,   505,   506,   507,
     508,   509,   510,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     511,   512,   513,   514,   515,   516,   517,   518,   519,     0,
       0,   520,   521,   522,   523,   524,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   525,     0,   526,     0,     0,   527,     0,     0,
       0,  1154,     0,     0,     0,     0,     0,     0,     0,     0,
     528,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   525,     0,   526,
       0,     0,   527,     0,     0,   698,  1155,   464,   465,   466,
     467,   468,   469,   470,   471,   528,     0,     0,     0,     0,
       0,     0,     0,   472,   473,   474,   475,   476,   477,   478,
     479,   480,   481,   482,   483,   484,   485,   486,   487,   488,
     489,   490,   491,     0,   492,     0,     0,     0,   493,   494,
     495,   496,   497,   498,   499,   500,     0,   501,   502,   503,
     504,   505,   506,   507,   508,   509,   510,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   511,   512,   513,   514,   515,   516,
     517,   518,   519,     0,     0,   520,   521,   522,   523,   524,
     698,     0,   464,   465,   466,   467,   468,   469,   470,   471,
       0,     0,     0,     0,     0,     0,     0,     0,   472,   473,
     474,   475,   476,   477,   478,   479,   480,   481,   482,   483,
     484,   485,   486,   487,   488,   489,   490,   491,     0,   492,
       0,     0,     0,   493,   494,   495,   496,   497,   498,   499,
     500,     0,   501,   502,   503,   504,   505,   506,   507,   508,
     509,   510,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   511,
     512,   513,   514,   515,   516,   517,   518,   519,     0,     0,
     520,   521,   522,   523,   524,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   525,     0,   526,     0,     0,   527,     0,     0,     0,
    1156,     0,     0,     0,     0,     0,     0,     0,     0,   528,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   525,     0,   526,     0,
       0,   527,     0,     0,   698,  1157,   464,   465,   466,   467,
     468,   469,   470,   471,   528,     0,     0,     0,     0,     0,
       0,     0,   472,   473,   474,   475,   476,   477,   478,   479,
     480,   481,   482,   483,   484,   485,   486,   487,   488,   489,
     490,   491,     0,   492,     0,     0,     0,   493,   494,   495,
     496,   497,   498,   499,   500,     0,   501,   502,   503,   504,
     505,   506,   507,   508,   509,   510,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   511,   512,   513,   514,   515,   516,   517,
     518,   519,     0,     0,   520,   521,   522,   523,   524,   698,
       0,   464,   465,   466,   467,   468,   469,   470,   471,     0,
       0,     0,     0,     0,     0,     0,     0,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     485,   486,   487,   488,   489,   490,   491,     0,   492,     0,
       0,     0,   493,   494,   495,   496,   497,   498,   499,   500,
       0,   501,   502,   503,   504,   505,   506,   507,   508,   509,
     510,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   511,   512,
     513,   514,   515,   516,   517,   518,   519,     0,     0,   520,
     521,   522,   523,   524,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     525,     0,   526,     0,     0,   527,     0,     0,     0,  1159,
       0,     0,     0,     0,     0,     0,     0,     0,   528,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   525,     0,   526,     0,     0,
     527,     0,     0,   698,  1261,   464,   465,   466,   467,   468,
     469,   470,   471,   528,     0,     0,     0,     0,     0,     0,
       0,   472,   473,   474,   475,   476,   477,   478,   479,   480,
     481,   482,   483,   484,   485,   486,   487,   488,   489,   490,
     491,     0,   492,     0,     0,     0,   493,   494,   495,   496,
     497,   498,   499,   500,     0,   501,   502,   503,   504,   505,
     506,   507,   508,   509,   510,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   511,   512,   513,   514,   515,   516,   517,   518,
     519,     0,     0,   520,   521,   522,   523,   524,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    -2,   208,     0,     0,     0,     0,     0,     0,
       0,     0,    -8,   -10,   -12,   -14,   -16,   -18,   -20,   -22,
     -24,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   525,
       0,   526,     0,     0,   527,     0,     0,     0,  -467,     0,
       0,     2,     3,     0,     0,     0,     0,   528,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,     0,     0,
       0,     0,     0,     0,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
       0,     0,     0,     0,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,   464,   465,   466,   467,   468,
     469,   470,   471,     0,     0,     0,     0,     0,     0,     0,
       0,   472,   473,   474,   475,   476,   477,   478,   479,   480,
     481,   482,   483,   484,   485,   486,   487,   488,   489,   490,
     491,     0,     0,     0,     0,     0,     0,   494,   495,   496,
     497,   498,   499,   500,    91,   501,   502,   503,   504,   505,
     506,   507,   508,   509,   510,   608,   609,   610,   611,   612,
     613,   614,   615,   616,   617,   618,   619,     0,     0,     0,
       0,     0,   511,   512,   513,   514,   515,   516,   517,   518,
     519,     0,     0,   520,   521,   522,   523,   524,   464,   465,
     466,   467,   468,   469,   470,   471,     0,     0,     0,     0,
       0,     0,     0,     0,   472,   473,   474,   475,   476,   477,
     478,   479,   480,   481,   482,   483,   484,   485,   486,   487,
     488,   489,   490,     0,     0,     0,     0,     0,     0,     0,
     494,   495,   496,   497,   498,   499,   500,     0,   501,   502,
     503,   504,   505,   506,   507,   508,   509,   510,   608,   609,
     610,   611,   813,   613,   814,   615,   616,   617,   618,   619,
       0,     0,     0,     0,     0,   511,   512,   513,   514,   515,
     516,   517,   518,   519,     0,     0,   520,   521,   522,   523,
     524,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   233,   234,     0,   620,   235,     0,   525,
       0,   526,     0,     0,     0,     0,   621,   622,     0,   623,
       0,     0,     0,     0,     0,     0,     0,   528,     0,     0,
       0,     0,     0,   464,   465,   466,   467,   468,   469,   470,
     471,     0,     0,     0,     0,     0,     0,     0,     0,   472,
     473,   474,   475,   476,   477,   478,   479,   480,   481,   482,
     483,   484,   485,   486,   487,   488,   489,   490,   491,     0,
     492,     0,     0,     0,   493,   494,   495,   496,   497,   498,
     499,   500,     0,   501,   502,   503,   504,   505,   506,   507,
     508,   509,   510,     0,     0,     0,   233,   234,   815,     0,
     235,     0,   816,   817,   526,     0,     0,     0,     0,   818,
     511,   512,   513,   514,   515,   516,   517,   518,   519,     0,
     528,   520,   521,   522,   523,   524,   464,   465,   466,   467,
     468,   469,   470,   471,     0,     0,     0,     0,     0,     0,
       0,     0,   472,   473,   474,   475,   476,   477,   478,   479,
     480,   481,   482,   483,   484,   485,   486,   487,   488,   489,
     490,   491,     0,   492,     0,     0,     0,   493,   494,   495,
     496,   497,   498,   499,   500,     0,   501,   502,   503,   504,
     505,   506,   507,   508,   509,   510,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   511,   512,   513,   514,   515,   516,   517,
     518,   519,     0,     0,   520,   521,   522,   523,   524,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   825,   826,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   525,     0,   526,
       0,     0,   527,     0,     0,   827,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   528,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     525,     0,   526,     0,     0,   527,     0,     0,     0,   811,
     464,   465,   466,   467,   468,   469,   470,   471,   528,     0,
       0,     0,     0,     0,     0,     0,   472,   473,   474,   475,
     476,   477,   478,   479,   480,   481,   482,   483,   484,   485,
     486,   487,   488,   489,   490,   491,     0,   492,     0,     0,
       0,   493,   494,   495,   496,   497,   498,   499,   500,     0,
     501,   502,   503,   504,   505,   506,   507,   508,   509,   510,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   511,   512,   513,
     514,   515,   516,   517,   518,   519,     0,     0,   520,   521,
     522,   523,   524,   464,   465,   466,   467,   468,   469,   470,
     471,     0,     0,     0,     0,     0,     0,     0,     0,   472,
     473,   474,   475,   476,   477,   478,   479,   480,   481,   482,
     483,   484,   485,   486,   487,   488,   489,   490,   491,     0,
     492,     0,     0,     0,   493,   494,   495,   496,   497,   498,
     499,   500,     0,   501,   502,   503,   504,   505,   506,   507,
     508,   509,   510,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     511,   512,   513,   514,   515,   516,   517,   518,   519,     0,
       0,   520,   521,   522,   523,   524,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   525,     0,   526,     0,     0,   527,
       0,     0,     0,  1017,     0,     0,     0,     0,     0,     0,
       0,     0,   528,     0,     0,     0,     0,     0,     0,   464,
     465,   466,   467,   468,   469,   470,   471,     0,     0,     0,
       0,     0,     0,     0,     0,   472,   473,   474,   475,   476,
     477,   478,   479,   480,   481,   482,   483,   484,   485,   486,
     487,   488,   489,   490,   491,     0,   492,     0,     0,  1299,
     493,   494,   495,   496,   497,   498,   499,   500,     0,   501,
     502,   503,   504,   505,   506,   507,   508,   509,   510,     0,
       0,     0,     0,     0,     0,     0,     0,   525,     0,   526,
       0,     0,   527,     0,     0,   827,   511,   512,   513,   514,
     515,   516,   517,   518,   519,   528,     0,   520,   521,   522,
     523,   524,   464,   465,   466,   467,   468,   469,   470,   471,
       0,     0,     0,     0,     0,     0,     0,     0,   472,   473,
     474,   475,   476,   477,   478,   479,   480,   481,   482,   483,
     484,   485,   486,   487,   488,   489,   490,   491,     0,   492,
       0,     0,  1301,   493,   494,   495,   496,   497,   498,   499,
     500,     0,   501,   502,   503,   504,   505,   506,   507,   508,
     509,   510,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   511,
     512,   513,   514,   515,   516,   517,   518,   519,     0,     0,
     520,   521,   522,   523,   524,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   525,     0,   526,     0,     0,   527,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   528,     0,     0,     0,     0,     0,   464,   465,   466,
     467,   468,   469,   470,   471,     0,     0,     0,     0,     0,
       0,     0,     0,   472,   473,   474,   475,   476,   477,   478,
     479,   480,   481,   482,   483,   484,   485,   486,   487,   488,
     489,   490,   491,     0,   492,     0,     0,     0,   493,   494,
     495,   496,   497,   498,   499,   500,     0,   501,   502,   503,
     504,   505,   506,   507,   508,   509,   510,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   525,     0,   526,     0,
       0,   527,     0,     0,   511,   512,   513,   514,   515,   516,
     517,   518,   519,     0,   528,   520,   521,   522,   523,   524,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     1,     0,     0,     0,     0,
       0,     0,     0,     0,    -8,   -10,   -12,   -14,   -16,   -18,
     -20,   -22,   -24,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   525,     0,   526,     0,     0,   527,     0,     0,     0,
       0,     0,     0,     2,     3,     0,     0,     0,     0,   528,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
       0,     0,     0,     0,     0,     0,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,     0,     0,     0,     0,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    91
};

static const yytype_int16 yycheck[] =
{
     111,   181,   182,   432,   460,   531,   462,   491,   437,   493,
     439,   118,   441,   191,   797,   635,   542,   493,   915,   545,
     546,   547,     1,   491,     1,   493,   491,     1,   493,   491,
       1,   493,     1,     1,   491,     1,   493,   491,     1,   493,
       1,   225,   221,     1,   613,     1,   615,   616,   617,     1,
     619,     1,     1,     1,   229,     1,     1,     1,   627,   224,
     244,   193,   241,     1,     1,   193,     1,     1,   225,   234,
     245,     1,     1,     1,     1,   696,   233,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,   572,     1,
       1,     1,     1,     1,     1,     1,     1,     1,   193,   625,
       1,    75,    76,    77,    78,   193,   590,   591,     1,   635,
       1,     1,     1,     1,    75,    76,    77,    78,     1,    75,
      76,    77,    78,     1,     1,    75,    76,    77,    78,     1,
       1,   791,     1,     1,     1,     1,   620,   621,   798,   623,
       1,     1,     1,     1,   620,   621,     1,   227,   228,   229,
     634,     1,   620,   621,     1,   620,   621,   240,   620,   621,
     243,   623,   269,   620,   621,   245,   620,   621,     1,     1,
       1,   193,   832,   228,   229,    52,     1,   228,   239,   240,
       1,     1,   233,     1,   225,     1,   227,     1,   193,     1,
     245,     1,     1,   622,   815,     1,     1,   818,   682,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,   696,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,   237,     1,     1,     1,     1,
       1,     1,   225,     1,   696,     1,   194,    41,    42,     1,
       1,   199,   193,   237,   193,   193,   225,     1,   193,   193,
       1,   225,   821,   227,   228,     1,   230,   234,   714,   227,
     716,     1,   233,   237,   225,   244,   227,   228,   237,   230,
     244,   237,   235,   451,   452,   225,   237,   227,   228,   225,
     230,   227,   228,   244,   230,   237,   812,   237,   244,  1186,
     225,   237,   227,   228,   244,   230,   225,   235,   235,   237,
     237,   230,   237,   237,   231,   235,     1,   235,   237,   236,
     234,   234,   234,   234,   234,   234,   234,   234,   234,   234,
     234,   232,   234,  1106,   234,   234,   234,   234,   234,   234,
     234,   815,   225,   234,   818,   228,     1,   193,   806,     1,
     233,   825,   826,   234,   234,   234,   234,   225,   225,   825,
     826,   234,   836,   815,   225,   233,   818,   825,   826,   225,
     825,   826,   234,   825,   826,   234,   234,   234,   825,   826,
     225,   825,   826,   234,   234,   234,   234,   227,   228,     1,
     491,   228,   493,  1004,  1005,  1006,  1007,  1008,  1009,  1010,
    1011,  1012,  1013,   225,   225,   228,   227,   228,   827,  1019,
     233,   221,   222,   228,  1187,   225,   227,   228,   228,   227,
     228,   227,   228,   227,   228,   227,   228,   227,   228,   228,
       1,   227,   228,   228,     1,   227,   228,   228,   228,   228,
     228,   228,   228,   228,   228,   228,   228,   228,   228,     1,
     228,   228,   228,   228,   228,   228,   228,   228,   228,   228,
     228,   228,   936,   228,   228,   228,   228,   228,   228,   637,
     228,   572,   228,   574,   225,   227,   227,   896,   897,   898,
     899,   225,   901,   227,   225,   221,   222,     1,     1,   225,
       1,     1,     1,     1,     1,   225,     1,     1,     1,     1,
       1,     1,  1018,  1019,     1,     1,     1,     1,     1,     1,
       1,     1,     1,   168,   169,   170,   171,   722,     1,   620,
     621,   193,     1,     1,     1,     1,     1,     1,     1,     1,
    1004,  1005,  1006,  1007,  1008,  1009,  1010,  1011,  1012,  1013,
     225,     1,     1,     1,   641,     1,     1,     1,     1,     1,
     651,     1,  1004,  1005,  1006,  1007,  1008,  1009,  1010,  1011,
    1012,  1013,     1,   193,     1,     1,     1,     1,     1,  1085,
    1086,  1087,  1088,   225,  1090,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,   162,   225,   211,   212,   228,
     225,     1,   193,     1,   229,   193,   173,   802,   175,   176,
     177,   178,  1076,     1,   193,   225,  1080,   227,   608,   233,
     245,   608,   612,   225,   614,   612,   717,   614,   193,   225,
     790,   618,   228,   229,   221,   222,   626,   797,   225,   626,
     627,   225,     1,    10,   228,   229,   233,   193,   225,   245,
     227,     1,   193,    75,    76,    77,    78,     1,   221,   222,
       0,   245,   225,     1,   225,   225,   229,   227,   225,   236,
     233,   168,   169,   170,   171,   225,   193,   227,   168,   169,
     170,   171,   245,   225,   193,   218,   219,   220,   221,   222,
     194,   195,   196,   197,   198,   199,   200,   201,   221,   222,
      11,    13,   225,   194,   195,   196,   197,   198,   199,   200,
     201,    73,    73,   194,   195,   196,   197,   198,   199,   200,
     201,  1227,   225,   918,   225,   225,   225,   225,  1192,    12,
     225,   225,   225,   225,   825,   826,   193,   193,   225,   225,
     225,   225,   225,   225,   835,   225,   225,  1211,  1212,  1158,
    1214,  1215,   225,    14,   193,  1219,   225,   225,   225,   225,
     225,   225,   225,   225,    16,   194,   195,   196,   197,   198,
     199,   200,   201,   193,   193,   225,   225,   225,    15,   225,
     225,   225,   225,   225,   225,   225,   227,   194,   195,   196,
     197,   198,   199,   193,  1300,   193,  1302,  1303,   225,   225,
     225,   225,   225,  1239,   225,   193,   227,   228,   193,   225,
     225,   225,   225,   225,   225,   225,   225,   225,   193,   193,
    1284,   225,   244,   813,   814,   229,   813,   814,   193,     1,
     820,    17,   225,   820,   821,   194,   195,   196,   197,   198,
     199,   245,   193,  1279,   194,   195,   196,   197,   198,   199,
     194,   195,   196,   197,   198,   199,   194,   195,   196,   197,
     198,   199,   193,   225,   225,   225,  1330,   193,   230,   230,
     230,   193,  1281,  1282,  1283,   237,   237,   237,   193,   225,
       1,   227,     3,     4,     5,     6,     7,     8,     9,    10,
      73,   193,    64,    65,    66,    67,    79,    69,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,   225,    40,
     227,   193,   193,    44,    45,    46,    47,    48,    49,    50,
      51,   193,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,   193,   221,   222,   193,  1106,   225,   213,   214,
     215,   216,   217,   218,   219,   220,   221,   222,  1118,    80,
      81,    82,    83,    84,    85,    86,    87,    88,   233,   193,
      91,    92,    93,    94,    95,   225,     1,   227,     3,     4,
       5,     6,     7,     8,     9,    10,    75,    76,    77,    78,
     231,   231,   233,   233,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    18,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,  1187,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,   221,   222,
     225,   231,   225,   233,   225,   225,   221,   222,   229,   229,
     225,   193,   231,   228,   233,    80,    81,    82,    83,    84,
      85,    86,    87,    88,   245,   245,    91,    92,    93,    94,
      95,   193,   225,   430,   227,   228,   433,   230,   435,   613,
     193,   615,   616,   617,   237,   619,   443,   231,   445,   233,
     211,   212,   213,   214,   215,   216,   217,   218,   219,   220,
     221,   222,   225,   221,   222,   162,   227,   225,   229,  1200,
     228,   232,   233,   234,   235,   162,   173,   238,   175,   176,
     177,   178,   193,   193,   245,   172,   193,   174,   175,   176,
     177,   178,   225,   193,   193,   228,   225,   230,   227,   228,
     231,   230,   233,   231,   237,   233,   225,   231,   237,   233,
     231,   225,   233,   227,   193,   244,   162,   213,   214,   215,
     216,   217,   218,   219,   220,   221,   222,   173,   241,   175,
     176,   177,   178,   225,   225,   227,   227,   193,   231,   236,
     233,   193,   238,   231,   228,   233,   231,   225,   233,   236,
     202,   203,   204,   205,   206,   207,   208,   209,   210,   231,
     193,   233,   227,   231,   229,   233,   193,   232,   193,   193,
       1,   236,     3,     4,     5,     6,     7,     8,     9,    10,
     245,   578,   231,   193,   233,   193,   193,   193,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,   193,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,   193,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,   162,   194,   195,   196,   197,   198,   199,   200,
     201,   193,   172,   193,   174,   175,   176,   177,   178,    80,
      81,    82,    83,    84,    85,    86,    87,    88,   193,   193,
      91,    92,    93,    94,    95,     1,   193,     3,     4,     5,
       6,     7,     8,     9,    10,   193,   193,   193,   193,   193,
     193,   193,   193,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,   193,    40,   193,   193,   227,    44,    45,
      46,    47,    48,    49,    50,    51,   193,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,   213,   214,   215,
     216,   217,   218,   219,   220,   221,   222,   193,   193,   193,
     225,   225,   225,   225,    80,    81,    82,    83,    84,    85,
      86,    87,    88,   231,   230,    91,    92,    93,    94,    95,
     193,   194,   195,   196,   197,   198,   199,   200,   201,   202,
     203,   204,   205,   206,   207,   208,   209,   210,   243,   243,
     243,   238,   243,   243,   225,   238,   225,   227,   235,   234,
     228,   234,   234,   241,   238,   231,   227,   234,   229,   234,
     234,   232,   234,   232,   234,   236,   234,   234,   234,   234,
     234,   234,   234,   234,   245,   234,   234,   234,   234,   234,
     234,   234,   234,   234,   234,   234,    79,    79,   231,   228,
     238,   238,   238,   238,   235,   233,   238,   233,   238,   243,
     233,   233,   233,   233,   233,   228,   228,   228,   228,   228,
     228,   228,   228,   228,   228,   228,    39,   225,    73,   225,
     225,   193,   193,   235,   235,   235,   235,    73,   235,   193,
     234,   233,   233,   233,   233,   233,   233,   233,   231,   233,
     231,   233,   193,   233,   233,   233,   233,   233,   233,   233,
     233,   227,   233,   229,   233,   233,   232,   231,   233,     1,
     236,     3,     4,     5,     6,     7,     8,     9,    10,   245,
     231,   233,   238,   233,   233,   233,   233,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,   233,    40,   233,
     233,   233,    44,    45,    46,    47,    48,    49,    50,    51,
     233,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,   233,   233,   233,   233,   233,   233,   233,   233,   233,
     233,   233,   233,   233,   233,   233,   233,   233,    80,    81,
      82,    83,    84,    85,    86,    87,    88,   233,   233,    91,
      92,    93,    94,    95,     1,   233,     3,     4,     5,     6,
       7,     8,     9,    10,   233,   233,   233,   233,   233,   233,
     233,   233,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,   233,    40,   233,   233,   233,    44,    45,    46,
      47,    48,    49,    50,    51,   231,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,   231,   231,   231,   231,
     231,   231,   241,   231,   233,   231,   231,   231,   235,   193,
     233,   233,   233,    80,    81,    82,    83,    84,    85,    86,
      87,    88,   240,   193,    91,    92,    93,    94,    95,   235,
     231,   228,   228,   228,   228,   228,   228,   220,    73,   228,
     228,   228,   228,   228,   235,   235,   228,   228,   228,   228,
     228,   228,   225,   225,    41,   231,   193,   193,   233,   233,
     193,   193,   233,   231,   233,   227,   233,   229,   233,   233,
     232,   193,   233,   233,   236,   233,   233,   233,   231,   231,
     193,   231,   233,   245,   231,   233,   231,   233,   193,   231,
     228,   225,   236,   228,   243,    93,   921,   228,   228,   225,
     243,   256,   231,   243,  1104,   233,   233,   231,   231,   225,
     231,   231,  1202,  1169,   233,   233,   233,   231,   233,   231,
     228,   225,   225,   232,   231,    -1,   228,   233,   269,    -1,
      -1,   232,    -1,   233,   233,   233,   233,   233,   231,   228,
     231,   233,   232,   228,   232,    -1,   233,   233,    -1,    -1,
     261,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     227,    -1,   229,    -1,    -1,   232,    -1,    -1,     1,   236,
       3,     4,     5,     6,     7,     8,     9,    10,   245,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    -1,    40,    -1,    -1,
      -1,    44,    45,    46,    47,    48,    49,    50,    51,    -1,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    -1,    -1,    91,    92,
      93,    94,    95,     1,    -1,     3,     4,     5,     6,     7,
       8,     9,    10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    -1,    40,    -1,    -1,    -1,    44,    45,    46,    47,
      48,    49,    50,    51,    -1,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    -1,    -1,    91,    92,    93,    94,    95,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   227,    -1,   229,    -1,    -1,   232,
      -1,    -1,    -1,   236,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   245,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   227,
      -1,   229,    -1,    -1,   232,    -1,    -1,     1,   236,     3,
       4,     5,     6,     7,     8,     9,    10,   245,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    -1,    40,    -1,    -1,    -1,
      44,    45,    46,    47,    48,    49,    50,    51,    -1,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    -1,    -1,    91,    92,    93,
      94,    95,     1,    -1,     3,     4,     5,     6,     7,     8,
       9,    10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      -1,    40,    -1,    -1,    -1,    44,    45,    46,    47,    48,
      49,    50,    51,    -1,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      -1,    -1,    91,    92,    93,    94,    95,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   227,    -1,   229,    -1,    -1,   232,    -1,
      -1,    -1,   236,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   245,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   227,    -1,
     229,    -1,    -1,   232,    -1,    -1,     1,   236,     3,     4,
       5,     6,     7,     8,     9,    10,   245,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    -1,    40,    -1,    -1,    -1,    44,
      45,    46,    47,    48,    49,    50,    51,    -1,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    -1,    -1,    91,    92,    93,    94,
      95,     1,    -1,     3,     4,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    -1,
      40,    -1,    -1,    -1,    44,    45,    46,    47,    48,    49,
      50,    51,    -1,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      80,    81,    82,    83,    84,    85,    86,    87,    88,    -1,
      -1,    91,    92,    93,    94,    95,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   227,    -1,   229,    -1,    -1,   232,    -1,    -1,
      -1,   236,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     245,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   227,    -1,   229,
      -1,    -1,   232,    -1,    -1,     1,   236,     3,     4,     5,
       6,     7,     8,     9,    10,   245,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    -1,    40,    -1,    -1,    -1,    44,    45,
      46,    47,    48,    49,    50,    51,    -1,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    -1,    -1,    91,    92,    93,    94,    95,
       1,    -1,     3,     4,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    -1,    40,
      -1,    -1,    -1,    44,    45,    46,    47,    48,    49,    50,
      51,    -1,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    -1,    -1,
      91,    92,    93,    94,    95,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   227,    -1,   229,    -1,    -1,   232,    -1,    -1,    -1,
     236,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   245,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   227,    -1,   229,    -1,
      -1,   232,    -1,    -1,     1,   236,     3,     4,     5,     6,
       7,     8,     9,    10,   245,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    -1,    40,    -1,    -1,    -1,    44,    45,    46,
      47,    48,    49,    50,    51,    -1,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    -1,    -1,    91,    92,    93,    94,    95,     1,
      -1,     3,     4,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    -1,    40,    -1,
      -1,    -1,    44,    45,    46,    47,    48,    49,    50,    51,
      -1,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    80,    81,
      82,    83,    84,    85,    86,    87,    88,    -1,    -1,    91,
      92,    93,    94,    95,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     227,    -1,   229,    -1,    -1,   232,    -1,    -1,    -1,   236,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   245,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   227,    -1,   229,    -1,    -1,
     232,    -1,    -1,     1,   236,     3,     4,     5,     6,     7,
       8,     9,    10,   245,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    -1,    40,    -1,    -1,    -1,    44,    45,    46,    47,
      48,    49,    50,    51,    -1,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    -1,    -1,    91,    92,    93,    94,    95,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     0,     1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   227,
      -1,   229,    -1,    -1,   232,    -1,    -1,    -1,   236,    -1,
      -1,    89,    90,    -1,    -1,    -1,    -1,   245,    96,    97,
      98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   124,   125,    -1,    -1,
      -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,
     138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
     148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
      -1,    -1,    -1,    -1,   172,   173,   174,   175,   176,   177,
     178,   179,   180,   181,   182,   183,   184,   185,   186,   187,
     188,   189,   190,   191,   192,     3,     4,     5,     6,     7,
       8,     9,    10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    -1,    -1,    -1,    -1,    -1,    -1,    45,    46,    47,
      48,    49,    50,    51,   242,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    -1,    -1,    -1,
      -1,    -1,    80,    81,    82,    83,    84,    85,    86,    87,
      88,    -1,    -1,    91,    92,    93,    94,    95,     3,     4,
       5,     6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      45,    46,    47,    48,    49,    50,    51,    -1,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      -1,    -1,    -1,    -1,    -1,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    -1,    -1,    91,    92,    93,    94,
      95,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   221,   222,    -1,   224,   225,    -1,   227,
      -1,   229,    -1,    -1,    -1,    -1,   234,   235,    -1,   237,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   245,    -1,    -1,
      -1,    -1,    -1,     3,     4,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    -1,
      40,    -1,    -1,    -1,    44,    45,    46,    47,    48,    49,
      50,    51,    -1,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    -1,    -1,    -1,   221,   222,   223,    -1,
     225,    -1,   227,   228,   229,    -1,    -1,    -1,    -1,   234,
      80,    81,    82,    83,    84,    85,    86,    87,    88,    -1,
     245,    91,    92,    93,    94,    95,     3,     4,     5,     6,
       7,     8,     9,    10,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    -1,    40,    -1,    -1,    -1,    44,    45,    46,
      47,    48,    49,    50,    51,    -1,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    -1,    -1,    91,    92,    93,    94,    95,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   211,   212,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   227,    -1,   229,
      -1,    -1,   232,    -1,    -1,   235,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   245,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     227,    -1,   229,    -1,    -1,   232,    -1,    -1,    -1,   236,
       3,     4,     5,     6,     7,     8,     9,    10,   245,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    -1,    40,    -1,    -1,
      -1,    44,    45,    46,    47,    48,    49,    50,    51,    -1,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    -1,    -1,    91,    92,
      93,    94,    95,     3,     4,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    -1,
      40,    -1,    -1,    -1,    44,    45,    46,    47,    48,    49,
      50,    51,    -1,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      80,    81,    82,    83,    84,    85,    86,    87,    88,    -1,
      -1,    91,    92,    93,    94,    95,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   227,    -1,   229,    -1,    -1,   232,
      -1,    -1,    -1,   236,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   245,    -1,    -1,    -1,    -1,    -1,    -1,     3,
       4,     5,     6,     7,     8,     9,    10,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    -1,    40,    -1,    -1,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    -1,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   227,    -1,   229,
      -1,    -1,   232,    -1,    -1,   235,    80,    81,    82,    83,
      84,    85,    86,    87,    88,   245,    -1,    91,    92,    93,
      94,    95,     3,     4,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    -1,    40,
      -1,    -1,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    -1,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    -1,    -1,
      91,    92,    93,    94,    95,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   227,    -1,   229,    -1,    -1,   232,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   245,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,
       6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    -1,    40,    -1,    -1,    -1,    44,    45,
      46,    47,    48,    49,    50,    51,    -1,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   227,    -1,   229,    -1,
      -1,   232,    -1,    -1,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    -1,   245,    91,    92,    93,    94,    95,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   227,    -1,   229,    -1,    -1,   232,    -1,    -1,    -1,
      -1,    -1,    -1,    89,    90,    -1,    -1,    -1,    -1,   245,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
      -1,    -1,    -1,    -1,    -1,    -1,   132,   133,   134,   135,
     136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     166,   167,    -1,    -1,    -1,    -1,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
     186,   187,   188,   189,   190,   191,   192,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   242
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,     1,    89,    90,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,   120,   121,
     122,   123,   124,   125,   132,   133,   134,   135,   136,   137,
     138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
     148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
     172,   173,   174,   175,   176,   177,   178,   179,   180,   181,
     182,   183,   184,   185,   186,   187,   188,   189,   190,   191,
     192,   242,   247,   248,   249,   250,   251,   252,   253,   254,
     255,   256,   257,   258,   269,   270,   275,   277,   193,   193,
     193,   193,   193,   193,   193,   193,   193,   193,   193,   193,
     193,   193,     1,   193,     1,   193,     1,   193,     1,   193,
       1,   193,   193,   193,   193,   193,   193,   193,   193,   193,
     193,   193,   193,   193,   193,   193,   193,   193,   193,     1,
     228,   193,     1,   234,   193,   193,   193,   193,   193,   193,
     193,   193,   193,   193,   193,   193,   193,   193,   193,   193,
     193,   193,   193,   193,   193,   193,   193,   193,   193,   193,
     193,   237,   237,   193,   193,   193,   193,   193,   193,   193,
     193,   193,   193,   193,   193,   193,   193,   193,     1,   193,
       1,   193,   193,   193,   193,   193,   193,     0,     1,   249,
      10,   285,    11,   286,    12,   287,    13,   288,    14,   289,
      15,   290,    16,   291,    17,   292,    18,   293,     1,   225,
       1,   225,     1,   221,   222,   225,   262,     1,   225,     1,
     225,     1,   227,     1,   228,     1,   228,     1,    75,    76,
      77,    78,   225,   227,   228,   230,   237,   244,   259,   260,
     263,   265,   266,   271,   272,   273,   274,   306,     1,   263,
     264,     1,   225,     1,   225,     1,   225,   225,   225,   225,
     225,   225,     1,   225,     1,   225,     1,   225,     1,   225,
       1,   225,     1,   225,     1,   225,     1,   225,     1,   225,
       1,   225,     1,   225,     1,   225,     1,   225,     1,   225,
       1,   225,     1,   228,     1,   228,     1,   228,   228,     1,
     225,     1,   227,   228,     1,   227,   228,     1,   227,   228,
       1,   227,   228,     1,   225,     1,   225,     1,   225,     1,
     225,     1,   225,     1,   225,     1,   225,     1,   225,     1,
     227,   228,     1,   225,     1,   225,     1,   225,   227,     1,
     225,     1,   225,     1,   225,     1,   225,     1,   225,     1,
     225,     1,   225,     1,   168,   169,   170,   171,     1,   225,
       1,   225,   271,   228,   271,     1,   228,     1,   225,     1,
     225,     1,   225,     1,   228,     1,   228,     1,   228,     1,
     228,     1,   259,     1,   225,     1,   225,     1,   225,     1,
     225,     1,   225,     1,   225,   227,   225,   225,   227,   225,
       1,   228,     1,   228,     1,   225,     1,   235,   237,     1,
     237,     1,   235,   237,     1,   237,     1,   235,     1,   235,
       1,   235,     1,   237,     1,   237,   225,   225,   241,   273,
     243,   243,   239,   240,   266,   221,   241,   305,   264,   231,
     243,   238,   243,   243,     3,     4,     5,     6,     7,     8,
       9,    10,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    40,    44,    45,    46,    47,    48,    49,    50,
      51,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      91,    92,    93,    94,    95,   227,   229,   232,   245,   301,
     309,   312,   313,   314,   315,   316,   323,   225,   227,   228,
     284,   284,   312,   284,   284,   312,   312,   312,   284,   284,
     225,   238,     1,   225,   244,   261,   259,   259,   225,     1,
     227,   228,   261,   279,   261,   235,     1,   234,     1,   234,
     234,   234,   234,     1,   234,     1,   234,     1,   234,     1,
     234,     1,   234,     1,   234,     1,   234,     1,   234,   234,
     234,   234,     1,   234,     1,   234,     1,   234,     1,   234,
     234,     1,   234,   234,   234,   234,   234,   234,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
     224,   234,   235,   237,   262,   294,   300,   301,   302,   303,
     309,   310,   314,   323,   234,   294,     1,   234,     1,   234,
       1,   234,     1,   234,     1,   234,     1,   234,     1,   234,
       1,   234,     1,   234,     1,   234,     1,   234,     1,   234,
       1,   234,     1,   234,     1,   234,     1,   234,     1,   234,
     234,   234,   234,   234,   234,   234,   234,   234,   234,   234,
     234,   234,   234,   234,     1,   234,   193,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   307,   232,     1,   236,
     313,     1,   232,   238,   238,   236,   238,   238,   236,   236,
     236,   231,   238,   241,   243,   240,   243,   231,   238,   235,
     238,   224,   234,   267,   268,     1,   228,   233,     1,   228,
     233,   233,   233,   262,   301,     1,   228,   262,     1,   228,
       1,   284,     1,   228,     1,   228,     1,   228,     1,   225,
       1,   225,   228,   233,   225,   301,   228,   301,     1,   228,
       1,   228,     1,   228,     1,   228,   233,     1,   228,   233,
     233,   233,   233,     1,   225,   233,     1,   194,   195,   196,
     197,   198,   199,   200,   201,   295,   296,   297,   299,     1,
     295,   299,     1,   295,   296,   298,     1,   295,   299,     1,
     298,     1,   298,     1,   298,     1,   295,     1,   298,   294,
     294,   236,   312,    67,    69,   223,   227,   228,   234,   262,
     300,   301,   303,   308,   323,   211,   212,   235,   311,   313,
       1,   295,   299,   295,   296,   298,   299,   301,   311,     1,
     259,     1,   225,     1,   263,     1,   225,     1,   233,     1,
     228,     1,   228,   233,   262,   225,   227,   225,   227,   225,
     227,   225,   227,   225,   227,   225,   227,   225,   227,   225,
     227,   225,   227,   228,   228,   228,   228,   228,   228,   228,
     228,   228,   228,   228,   228,   301,   225,   233,     1,   225,
     228,   233,   321,    79,    79,   308,   235,   235,   235,   235,
     225,   235,   225,   261,   225,   261,   228,   262,   276,   162,
     173,   175,   176,   177,   178,   281,   283,   278,   234,   260,
       1,   231,   236,   233,   233,   233,   231,   233,   233,   233,
     233,   233,   231,   233,   231,   233,   231,   233,   233,   233,
     233,   233,   233,   233,   233,   233,   233,   233,   231,   233,
     233,   233,   231,   231,   233,   233,   233,   233,   233,   233,
     233,   233,   233,   233,   233,   233,     1,   227,   228,    73,
     271,   304,     1,   228,   306,     1,   225,    73,   304,     1,
     228,   306,     1,   225,     1,   260,     1,   225,     1,    67,
      69,   300,     1,    52,   225,   233,   236,   295,   299,   295,
     299,   308,   308,   299,   213,   214,   215,   216,   217,   218,
     219,   220,   221,   222,   238,   294,   294,   236,   312,    39,
      73,     1,   228,   306,    73,    79,   262,   227,   228,   301,
     233,   233,   233,   233,   233,   233,   233,   233,   233,   233,
     233,   233,   233,   233,   233,   233,   233,   233,   233,   233,
     233,   231,   233,   233,   231,   233,   233,   231,   233,   233,
     233,   233,   233,   233,   233,   233,   231,   231,   231,   231,
     231,   231,   231,   233,   231,   233,   231,   233,   231,   231,
     231,   231,   233,   231,   233,   312,   312,   312,   312,   238,
     312,   241,   240,   233,   233,   235,   193,   193,   193,   193,
     193,   193,   236,   283,   235,   260,   231,   267,   228,   228,
     228,   225,   228,   301,   322,   228,   228,   228,   220,   233,
     308,   308,   308,   308,   308,   308,   308,   308,   308,   308,
     236,   311,   235,   225,   227,   225,   227,   225,   227,   228,
     228,   228,   228,   228,   228,   228,   228,   301,   228,   228,
     301,   228,   225,   228,   236,   236,   236,   236,   235,   236,
     225,   225,   162,   172,   174,   175,   176,   177,   178,   280,
     282,     1,   168,   169,   170,   171,     1,   225,     1,   228,
       1,   228,     1,   228,     1,   228,   281,   231,   304,   233,
     233,   233,   231,   233,   233,   233,   233,     1,   225,   271,
      41,   317,   318,   319,   233,   233,   233,   233,   233,   233,
     231,   231,   231,   233,   231,   231,   231,   233,   233,   231,
     233,   231,   233,   231,   233,   231,   233,   312,   193,   193,
     193,   193,   193,   193,   193,   236,   282,   236,   304,   231,
     225,   228,   301,   228,   262,   236,    42,   319,   320,   228,
     301,   301,   225,   301,   225,   301,   228,   301,   225,   228,
     228,   236,     1,   168,   169,   170,   171,     1,   225,     1,
     225,     1,   228,     1,   228,     1,   228,     1,   228,   231,
     261,   243,   243,   243,   231,   233,   233,   233,   231,   231,
     231,   231,   233,   233,   233,   231,   233,   261,   231,    43,
     312,    43,   312,   312,   225,   301,   225,   225,   225,   225,
     228,   231,   228,   232,    43,   232,    43,   233,   233,   233,
     233,   233,   233,   231,   228,   233,   232,   232,   228,   233,
     231,   301,   233
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 3:
#line 484 "cfg.y"
    {;}
    break;

  case 4:
#line 485 "cfg.y"
    {;}
    break;

  case 5:
#line 486 "cfg.y"
    { yyerror(""); YYABORT;;}
    break;

  case 8:
#line 491 "cfg.y"
    {rt=REQUEST_ROUTE;;}
    break;

  case 10:
#line 492 "cfg.y"
    {rt=FAILURE_ROUTE;;}
    break;

  case 12:
#line 493 "cfg.y"
    {rt=ONREPLY_ROUTE;;}
    break;

  case 14:
#line 494 "cfg.y"
    {rt=BRANCH_ROUTE;;}
    break;

  case 16:
#line 495 "cfg.y"
    {rt=ERROR_ROUTE;;}
    break;

  case 18:
#line 496 "cfg.y"
    {rt=LOCAL_ROUTE;;}
    break;

  case 20:
#line 497 "cfg.y"
    {rt=STARTUP_ROUTE;;}
    break;

  case 22:
#line 498 "cfg.y"
    {rt=TIMER_ROUTE;;}
    break;

  case 24:
#line 499 "cfg.y"
    {rt=EVENT_ROUTE;;}
    break;

  case 27:
#line 504 "cfg.y"
    {	tmp=ip_addr2a((yyvsp[(1) - (1)].ipaddr));
							if(tmp==0){
								LM_CRIT("cfg. parser: bad ip address.\n");
								(yyval.strval)=0;
							}else{
								(yyval.strval)=pkg_malloc(strlen(tmp)+1);
								if ((yyval.strval)==0){
									LM_CRIT("cfg. parser: out of memory.\n");
								}else{
									strncpy((yyval.strval), tmp, strlen(tmp)+1);
								}
							}
						;}
    break;

  case 28:
#line 517 "cfg.y"
    {	(yyval.strval)=pkg_malloc(strlen((yyvsp[(1) - (1)].strval))+1);
							if ((yyval.strval)==0){
									LM_CRIT("cfg. parser: out of memory.\n");
							}else{
									strncpy((yyval.strval), (yyvsp[(1) - (1)].strval), strlen((yyvsp[(1) - (1)].strval))+1);
							}
						;}
    break;

  case 29:
#line 524 "cfg.y"
    {	if ((yyvsp[(1) - (1)].strval)==0) {
								(yyval.strval) = 0;
							} else {
								(yyval.strval)=pkg_malloc(strlen((yyvsp[(1) - (1)].strval))+1);
								if ((yyval.strval)==0){
									LM_CRIT("cfg. parser: out of memory.\n");
								}else{
									strncpy((yyval.strval), (yyvsp[(1) - (1)].strval), strlen((yyvsp[(1) - (1)].strval))+1);
								}
							}
						;}
    break;

  case 30:
#line 537 "cfg.y"
    { (yyval.intval)=PROTO_UDP; ;}
    break;

  case 31:
#line 538 "cfg.y"
    { (yyval.intval)=PROTO_TCP; ;}
    break;

  case 32:
#line 539 "cfg.y"
    {
			#ifdef USE_TLS
				(yyval.intval)=PROTO_TLS;
			#else
				(yyval.intval)=PROTO_TCP;
				warn("tls support not compiled in");
			#endif
			;}
    break;

  case 33:
#line 547 "cfg.y"
    { 
			#ifdef USE_SCTP
				(yyval.intval)=PROTO_SCTP;
			#else
				yyerror("sctp support not compiled in\n");YYABORT;
			#endif
			;}
    break;

  case 34:
#line 554 "cfg.y"
    { (yyval.intval)=0; ;}
    break;

  case 35:
#line 557 "cfg.y"
    { (yyval.intval)=(yyvsp[(1) - (1)].intval); ;}
    break;

  case 36:
#line 558 "cfg.y"
    { (yyval.intval)=0; ;}
    break;

  case 37:
#line 561 "cfg.y"
    { (yyval.intval)=(yyvsp[(1) - (1)].intval); ;}
    break;

  case 38:
#line 562 "cfg.y"
    { (yyval.intval)=(yyvsp[(2) - (2)].intval); ;}
    break;

  case 39:
#line 563 "cfg.y"
    { (yyval.intval)=-(yyvsp[(2) - (2)].intval); ;}
    break;

  case 40:
#line 567 "cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(1) - (1)].strval), 0, 0); ;}
    break;

  case 41:
#line 568 "cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(1) - (3)].strval), 0, (yyvsp[(3) - (3)].intval)); ;}
    break;

  case 42:
#line 569 "cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(3) - (3)].strval), (yyvsp[(1) - (3)].intval), 0); ;}
    break;

  case 43:
#line 570 "cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(3) - (5)].strval), (yyvsp[(1) - (5)].intval), (yyvsp[(5) - (5)].intval));;}
    break;

  case 44:
#line 571 "cfg.y"
    { (yyval.sockid)=0; yyerror(" port number expected"); ;}
    break;

  case 45:
#line 574 "cfg.y"
    {  (yyval.sockid)=(yyvsp[(1) - (1)].sockid) ; ;}
    break;

  case 46:
#line 575 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (2)].sockid); (yyval.sockid)->next=(yyvsp[(2) - (2)].sockid); ;}
    break;

  case 47:
#line 579 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (1)].sockid); ;}
    break;

  case 48:
#line 580 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (3)].sockid); (yyval.sockid)->children=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 49:
#line 581 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (3)].sockid); set_listen_id_adv((struct socket_id *)(yyvsp[(1) - (3)].sockid), (yyvsp[(3) - (3)].strval), 5060); ;}
    break;

  case 50:
#line 582 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (5)].sockid); set_listen_id_adv((struct socket_id *)(yyvsp[(1) - (5)].sockid), (yyvsp[(3) - (5)].strval), 5060); (yyvsp[(1) - (5)].sockid)->children=(yyvsp[(5) - (5)].intval); ;}
    break;

  case 51:
#line 583 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (5)].sockid); set_listen_id_adv((struct socket_id *)(yyvsp[(1) - (5)].sockid), (yyvsp[(3) - (5)].strval), (yyvsp[(5) - (5)].intval)); ;}
    break;

  case 52:
#line 584 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (7)].sockid); set_listen_id_adv((struct socket_id *)(yyvsp[(1) - (7)].sockid), (yyvsp[(3) - (7)].strval), (yyvsp[(5) - (7)].intval)); (yyvsp[(1) - (7)].sockid)->children=(yyvsp[(7) - (7)].intval); ;}
    break;

  case 53:
#line 587 "cfg.y"
    {  (yyval.sockid)=(yyvsp[(1) - (1)].sockid) ; ;}
    break;

  case 54:
#line 588 "cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (2)].sockid); (yyval.sockid)->next=(yyvsp[(2) - (2)].sockid); ;}
    break;

  case 55:
#line 592 "cfg.y"
    {
				s_tmp.s=(yyvsp[(8) - (9)].strval);
				s_tmp.len=strlen((yyvsp[(8) - (9)].strval));
				if (add_rule_to_list(&bl_head,&bl_tail,(yyvsp[(4) - (9)].ipnet),&s_tmp,(yyvsp[(6) - (9)].intval),(yyvsp[(2) - (9)].intval),0)) {
					yyerror("failed to add backlist element\n");YYABORT;
				}
			;}
    break;

  case 56:
#line 599 "cfg.y"
    {
				s_tmp.s=(yyvsp[(9) - (10)].strval);
				s_tmp.len=strlen((yyvsp[(9) - (10)].strval));
				if (add_rule_to_list(&bl_head,&bl_tail,(yyvsp[(5) - (10)].ipnet),&s_tmp,
				(yyvsp[(7) - (10)].intval),(yyvsp[(3) - (10)].intval),BLR_APPLY_CONTRARY)) {
					yyerror("failed to add backlist element\n");YYABORT;
				}
			;}
    break;

  case 57:
#line 609 "cfg.y"
    {;}
    break;

  case 58:
#line 610 "cfg.y"
    {;}
    break;

  case 59:
#line 611 "cfg.y"
    { yyerror("bad black list element");;}
    break;

  case 60:
#line 615 "cfg.y"
    { 
#ifdef CHANGEABLE_DEBUG_LEVEL
					*debug=(yyvsp[(3) - (3)].intval);
#else
					debug=(yyvsp[(3) - (3)].intval);
#endif
			;}
    break;

  case 61:
#line 622 "cfg.y"
    { yyerror("number  expected"); ;}
    break;

  case 62:
#line 623 "cfg.y"
    { dont_fork= !dont_fork ? ! (yyvsp[(3) - (3)].intval):1; ;}
    break;

  case 63:
#line 624 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 64:
#line 625 "cfg.y"
    { if (!config_check) log_stderr=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 65:
#line 626 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 66:
#line 627 "cfg.y"
    {
					if ( (i_tmp=str2facility((yyvsp[(3) - (3)].strval)))==-1)
						yyerror("bad facility (see syslog(3) man page)");
					if (!config_check)
						log_facility=i_tmp;
									;}
    break;

  case 67:
#line 633 "cfg.y"
    { yyerror("ID expected"); ;}
    break;

  case 68:
#line 634 "cfg.y"
    { log_name=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 69:
#line 635 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 70:
#line 636 "cfg.y"
    { 
				yyerror("AVP_ALIASES shouldn't be used anymore\n");
			;}
    break;

  case 71:
#line 639 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 72:
#line 640 "cfg.y"
    { received_dns|= ((yyvsp[(3) - (3)].intval))?DO_DNS:0; ;}
    break;

  case 73:
#line 641 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 74:
#line 642 "cfg.y"
    { received_dns|= ((yyvsp[(3) - (3)].intval))?DO_REV_DNS:0; ;}
    break;

  case 75:
#line 643 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 76:
#line 644 "cfg.y"
    { dns_try_ipv6=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 77:
#line 645 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 78:
#line 646 "cfg.y"
    { dns_retr_time=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 79:
#line 647 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 80:
#line 648 "cfg.y"
    { dns_retr_no=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 81:
#line 649 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 82:
#line 650 "cfg.y"
    { dns_servers_no=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 83:
#line 651 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 84:
#line 652 "cfg.y"
    { dns_search_list=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 85:
#line 653 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 86:
#line 654 "cfg.y"
    { port_no=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 87:
#line 655 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 88:
#line 656 "cfg.y"
    { max_while_loops=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 89:
#line 657 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 90:
#line 658 "cfg.y"
    { maxbuffer=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 91:
#line 659 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 92:
#line 660 "cfg.y"
    { children_no=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 93:
#line 661 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 94:
#line 662 "cfg.y"
    { check_via=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 95:
#line 663 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 96:
#line 664 "cfg.y"
    { memlog=(yyvsp[(3) - (3)].intval); memdump=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 97:
#line 665 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 98:
#line 666 "cfg.y"
    { memdump=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 99:
#line 667 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 100:
#line 668 "cfg.y"
    { execmsgthreshold=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 101:
#line 669 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 102:
#line 670 "cfg.y"
    { execdnsthreshold=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 103:
#line 671 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 104:
#line 672 "cfg.y"
    { tcpthreshold=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 105:
#line 673 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 106:
#line 674 "cfg.y"
    {
			#ifdef SHM_MEM
				#ifdef STATISTICS
					if ((yyvsp[(3) - (3)].intval) < 0 || (yyvsp[(3) - (3)].intval) > 100)
						yyerror("SHM threshold has to be a percentage between 0 and 100");
					event_shm_threshold=(yyvsp[(3) - (3)].intval);
				#else
					yyerror("statistics support not compiled in");
				#endif /* STATISTICS */
			#else /* SHM_MEM */
				yyerror("shm support not compiled in");
			#endif
			;}
    break;

  case 107:
#line 687 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 108:
#line 688 "cfg.y"
    {
			#ifdef STATISTICS
				if ((yyvsp[(3) - (3)].intval) < 0 || (yyvsp[(3) - (3)].intval) > 100)
					yyerror("PKG threshold has to be a percentage between 0 and 100");
				event_pkg_threshold=(yyvsp[(3) - (3)].intval);
			#else
				yyerror("statistics support not compiled in");
			#endif
			;}
    break;

  case 109:
#line 697 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 110:
#line 698 "cfg.y"
    { query_buffer_size=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 111:
#line 699 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 112:
#line 700 "cfg.y"
    { query_flush_time=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 113:
#line 701 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 114:
#line 702 "cfg.y"
    { sip_warning=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 115:
#line 703 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 116:
#line 704 "cfg.y"
    { user=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 117:
#line 705 "cfg.y"
    { user=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 118:
#line 706 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 119:
#line 707 "cfg.y"
    { group=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 120:
#line 708 "cfg.y"
    { group=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 121:
#line 709 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 122:
#line 710 "cfg.y"
    { chroot_dir=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 123:
#line 711 "cfg.y"
    { chroot_dir=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 124:
#line 712 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 125:
#line 713 "cfg.y"
    { working_dir=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 126:
#line 714 "cfg.y"
    { working_dir=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 127:
#line 715 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 128:
#line 716 "cfg.y"
    { mhomed=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 129:
#line 717 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 130:
#line 718 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_disable=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 131:
#line 725 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 132:
#line 726 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_accept_aliases=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 133:
#line 733 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 134:
#line 734 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_children_no=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 135:
#line 741 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 136:
#line 742 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_connect_timeout=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 137:
#line 749 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 138:
#line 750 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_send_timeout=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 139:
#line 757 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 140:
#line 758 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_con_lifetime=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 141:
#line 765 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 142:
#line 766 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_listen_backlog=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 143:
#line 773 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 144:
#line 774 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_poll_method=get_poll_type((yyvsp[(3) - (3)].strval));
										if (tcp_poll_method==POLL_NONE){
											LM_CRIT("bad poll method name:"
												" %s\n, try one of %s.\n",
												(yyvsp[(3) - (3)].strval), poll_support);
											yyerror("bad tcp_poll_method "
												"value");
										}
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 145:
#line 788 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_poll_method=get_poll_type((yyvsp[(3) - (3)].strval));
										if (tcp_poll_method==POLL_NONE){
											LM_CRIT("bad poll method name:"
												" %s\n, try one of %s.\n",
												(yyvsp[(3) - (3)].strval), poll_support);
											yyerror("bad tcp_poll_method "
												"value");
										}
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 146:
#line 802 "cfg.y"
    { yyerror("poll method name expected"); ;}
    break;

  case 147:
#line 803 "cfg.y"
    {
									#ifdef USE_TCP
										tcp_max_connections=(yyvsp[(3) - (3)].intval);
									#else
										warn("tcp support not compiled in");
									#endif
									;}
    break;

  case 148:
#line 810 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 149:
#line 811 "cfg.y"
    {
			#ifdef USE_TCP
				tcp_crlf_pingpong=(yyvsp[(3) - (3)].intval);
			#else
				warn("tcp support not compiled in");
			#endif
		;}
    break;

  case 150:
#line 818 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 151:
#line 819 "cfg.y"
    {
			#ifdef USE_TCP
				fix_flag_name(&tmp, (yyvsp[(3) - (3)].intval));
				tcp_no_new_conn_bflag = get_flag_id_by_name(FLAG_TYPE_BRANCH, tmp);
				if (!flag_in_range( (flag_t)tcp_no_new_conn_bflag ) )
					yyerror("invalid TCP no_new_conn Branch Flag");
				flag_idx2mask( &tcp_no_new_conn_bflag );
			#else
				warn("tcp support not compiled in");
			#endif
		;}
    break;

  case 152:
#line 830 "cfg.y"
    {
			#ifdef USE_TCP
				tcp_no_new_conn_bflag = get_flag_id_by_name(FLAG_TYPE_BRANCH, (yyvsp[(3) - (3)].strval));
				if (!flag_in_range( (flag_t)tcp_no_new_conn_bflag ) )
					yyerror("invalid TCP no_new_conn Branch Flag");
				flag_idx2mask( &tcp_no_new_conn_bflag );
			#else
				warn("tcp support not compiled in");
			#endif
		;}
    break;

  case 153:
#line 840 "cfg.y"
    { yyerror("number value expected"); ;}
    break;

  case 154:
#line 841 "cfg.y"
    {
			#ifdef USE_TCP
			        tcp_keepalive=(yyvsp[(3) - (3)].intval);
			#else
				warn("tcp support not compiled in");
			#endif
		;}
    break;

  case 155:
#line 848 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 156:
#line 849 "cfg.y"
    { 
			#ifdef USE_TCP
			    #ifndef HAVE_TCP_KEEPCNT
				warn("cannot be enabled (no OS support)");
			    #else
			        tcp_keepcount=(yyvsp[(3) - (3)].intval);
			    #endif
		        #else
				warn("tcp support not compiled in");
			#endif
		;}
    break;

  case 157:
#line 860 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 158:
#line 861 "cfg.y"
    { 
			#ifdef USE_TCP
			    #ifndef HAVE_TCP_KEEPIDLE
				warn("cannot be enabled (no OS support)");
			    #else
			        tcp_keepidle=(yyvsp[(3) - (3)].intval);
			    #endif
		        #else
				warn("tcp support not compiled in");
			#endif
		;}
    break;

  case 159:
#line 872 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 160:
#line 873 "cfg.y"
    { 
			#ifdef USE_TCP
			    #ifndef HAVE_TCP_KEEPINTVL
				warn("cannot be enabled (no OS support)");
			    #else
			        tcp_keepinterval=(yyvsp[(3) - (3)].intval);
			    #endif
		        #else
				warn("tcp support not compiled in");
			#endif
		;}
    break;

  case 161:
#line 884 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 162:
#line 885 "cfg.y"
    {
									#ifdef USE_TLS
										tls_disable=(yyvsp[(3) - (3)].intval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 163:
#line 892 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 164:
#line 893 "cfg.y"
    { 
									#ifdef USE_TLS
										tls_log=(yyvsp[(3) - (3)].intval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 165:
#line 900 "cfg.y"
    { yyerror("int value expected"); ;}
    break;

  case 166:
#line 901 "cfg.y"
    {
									#ifdef USE_TLS
										tls_port_no=(yyvsp[(3) - (3)].intval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 167:
#line 908 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 168:
#line 909 "cfg.y"
    {
									#ifdef USE_TLS
										tls_default_server_domain->method =
											TLS_USE_SSLv23;
										tls_default_client_domain->method =
											TLS_USE_SSLv23;
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 169:
#line 919 "cfg.y"
    {
									#ifdef USE_TLS
										tls_default_server_domain->method =
											TLS_USE_SSLv2;
										tls_default_client_domain->method =
											TLS_USE_SSLv2;
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 170:
#line 929 "cfg.y"
    {
									#ifdef USE_TLS
										tls_default_server_domain->method =
											TLS_USE_SSLv3;
										tls_default_client_domain->method =
											TLS_USE_SSLv3;
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 171:
#line 939 "cfg.y"
    {
									#ifdef USE_TLS
										tls_default_server_domain->method =
											TLS_USE_TLSv1;
										tls_default_client_domain->method =
											TLS_USE_TLSv1;
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 172:
#line 949 "cfg.y"
    {
									#ifdef USE_TLS
										yyerror("SSLv23, SSLv2, SSLv3 or TLSv1"
													" expected");
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 173:
#line 958 "cfg.y"
    {
									#ifdef USE_TLS
										tls_default_server_domain->verify_cert
											= (yyvsp[(3) - (3)].intval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 174:
#line 966 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 175:
#line 967 "cfg.y"
    {
									#ifdef USE_TLS
										tls_default_client_domain->verify_cert
											=(yyvsp[(3) - (3)].intval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 176:
#line 975 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 177:
#line 976 "cfg.y"
    {
									#ifdef USE_TLS
										tls_default_server_domain->require_client_cert=(yyvsp[(3) - (3)].intval);
									#else
										warn( "tls support not compiled in");
									#endif
									;}
    break;

  case 178:
#line 983 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 179:
#line 984 "cfg.y"
    { 
									#ifdef USE_TLS
										tls_default_server_domain->cert_file=
											(yyvsp[(3) - (3)].strval);
										tls_default_client_domain->cert_file=
											(yyvsp[(3) - (3)].strval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 180:
#line 994 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 181:
#line 995 "cfg.y"
    { 
									#ifdef USE_TLS
										tls_default_server_domain->pkey_file=
											(yyvsp[(3) - (3)].strval);
										tls_default_client_domain->pkey_file=
											(yyvsp[(3) - (3)].strval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 182:
#line 1005 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 183:
#line 1006 "cfg.y"
    { 
									#ifdef USE_TLS
										tls_default_server_domain->ca_file =
											(yyvsp[(3) - (3)].strval);
										tls_default_client_domain->ca_file =
											(yyvsp[(3) - (3)].strval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 184:
#line 1016 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 185:
#line 1017 "cfg.y"
    { 
									#ifdef USE_TLS
										tls_default_server_domain->ciphers_list
											= (yyvsp[(3) - (3)].strval);
										tls_default_client_domain->ciphers_list
											= (yyvsp[(3) - (3)].strval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 186:
#line 1027 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 187:
#line 1028 "cfg.y"
    {
									#ifdef USE_TLS
										tls_handshake_timeout=(yyvsp[(3) - (3)].intval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 188:
#line 1035 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 189:
#line 1036 "cfg.y"
    {
									#ifdef USE_TLS
										tls_send_timeout=(yyvsp[(3) - (3)].intval);
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 190:
#line 1043 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 191:
#line 1044 "cfg.y"
    {
									#ifdef USE_TLS
										tstr.s = (yyvsp[(3) - (3)].strval);
										tstr.len = strlen(tstr.s);
										if (parse_avp_spec(&tstr, &tls_client_domain_avp)) {
											yyerror("cannot parse tls_client_avp");
										}
									#else
										warn("tls support not compiled in");
									#endif
									;}
    break;

  case 192:
#line 1055 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 195:
#line 1058 "cfg.y"
    { server_signature=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 196:
#line 1059 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 197:
#line 1060 "cfg.y"
    { server_header.s=(yyvsp[(3) - (3)].strval);
									server_header.len=strlen((yyvsp[(3) - (3)].strval));
									;}
    break;

  case 198:
#line 1063 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 199:
#line 1064 "cfg.y"
    { user_agent_header.s=(yyvsp[(3) - (3)].strval);
									user_agent_header.len=strlen((yyvsp[(3) - (3)].strval));
									;}
    break;

  case 200:
#line 1067 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 201:
#line 1068 "cfg.y"
    { xlog_buf_size = (yyvsp[(3) - (3)].intval); ;}
    break;

  case 202:
#line 1069 "cfg.y"
    { xlog_force_color = (yyvsp[(3) - (3)].intval); ;}
    break;

  case 203:
#line 1070 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 204:
#line 1071 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 205:
#line 1073 "cfg.y"
    {
							for(lst_tmp=(yyvsp[(3) - (3)].sockid); lst_tmp; lst_tmp=lst_tmp->next){
								if (add_listen_iface(	lst_tmp->name,
														lst_tmp->port,
														lst_tmp->proto,
														lst_tmp->adv_name,
														lst_tmp->adv_port,
														lst_tmp->children,
														0
													)!=0){
									LM_CRIT("cfg. parser: failed"
											" to add listen address\n");
									break;
								}
							}
							 ;}
    break;

  case 206:
#line 1089 "cfg.y"
    { yyerror("ip address or hostname "
						"expected (use quotes if the hostname includes"
						" config keywords)"); ;}
    break;

  case 207:
#line 1092 "cfg.y"
    { 
							for(lst_tmp=(yyvsp[(3) - (3)].sockid); lst_tmp; lst_tmp=lst_tmp->next)
								add_alias(lst_tmp->name, strlen(lst_tmp->name),
											lst_tmp->port, lst_tmp->proto);
							  ;}
    break;

  case 208:
#line 1097 "cfg.y"
    { yyerror("hostname expected (use quotes"
							" if the hostname includes config keywords)"); ;}
    break;

  case 209:
#line 1099 "cfg.y"
    { auto_aliases=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 210:
#line 1100 "cfg.y"
    { yyerror("number  expected"); ;}
    break;

  case 211:
#line 1101 "cfg.y"
    {
								if ((yyvsp[(3) - (3)].strval)) {
									default_global_address.s=(yyvsp[(3) - (3)].strval);
									default_global_address.len=strlen((yyvsp[(3) - (3)].strval));
								}
								;}
    break;

  case 212:
#line 1107 "cfg.y"
    {yyerror("ip address or hostname "
												"expected"); ;}
    break;

  case 213:
#line 1109 "cfg.y"
    {
								tmp=int2str((yyvsp[(3) - (3)].intval), &i_tmp);
								if ((default_global_port.s=pkg_malloc(i_tmp))
										==0){
										LM_CRIT("cfg. parser: out of memory.\n");
										default_global_port.len=0;
								}else{
									default_global_port.len=i_tmp;
									memcpy(default_global_port.s, tmp,
											default_global_port.len);
								};
								;}
    break;

  case 214:
#line 1121 "cfg.y"
    {yyerror("ip address or hostname "
												"expected"); ;}
    break;

  case 215:
#line 1123 "cfg.y"
    {
										disable_core_dump=(yyvsp[(3) - (3)].intval);
									;}
    break;

  case 216:
#line 1126 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 217:
#line 1127 "cfg.y"
    {
										open_files_limit=(yyvsp[(3) - (3)].intval);
									;}
    break;

  case 218:
#line 1130 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 219:
#line 1131 "cfg.y"
    {
								#ifdef USE_MCAST
										mcast_loopback=(yyvsp[(3) - (3)].intval);
								#else
									warn("no multicast support compiled in");
								#endif
		  ;}
    break;

  case 220:
#line 1138 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 221:
#line 1139 "cfg.y"
    {
								#ifdef USE_MCAST
										mcast_ttl=(yyvsp[(3) - (3)].intval);
								#else
									warn("no multicast support compiled in");
								#endif
		  ;}
    break;

  case 222:
#line 1146 "cfg.y"
    { yyerror("number expected as tos"); ;}
    break;

  case 223:
#line 1147 "cfg.y"
    { tos = (yyvsp[(3) - (3)].intval);
							if (tos<=0)
								yyerror("invalid tos value");
		 ;}
    break;

  case 224:
#line 1151 "cfg.y"
    { if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_LOWDELAY")) {
								tos=IPTOS_LOWDELAY;
							} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_THROUGHPUT")) {
								tos=IPTOS_THROUGHPUT;
							} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_RELIABILITY")) {
								tos=IPTOS_RELIABILITY;
#if defined(IPTOS_MINCOST)
							} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_MINCOST")) {
								tos=IPTOS_MINCOST;
#endif
#if defined(IPTOS_LOWCOST)
							} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_LOWCOST")) {
								tos=IPTOS_LOWCOST;
#endif
							} else {
								yyerror("invalid tos value - allowed: "
									"IPTOS_LOWDELAY,IPTOS_THROUGHPUT,"
									"IPTOS_RELIABILITY"
#if defined(IPTOS_LOWCOST)
									",IPTOS_LOWCOST"
#endif
#if defined(IPTOS_MINCOST)
									",IPTOS_MINCOST"
#endif
									"\n");
							}
		 ;}
    break;

  case 225:
#line 1178 "cfg.y"
    { yyerror("number expected"); ;}
    break;

  case 226:
#line 1179 "cfg.y"
    { mpath=(yyvsp[(3) - (3)].strval); strcpy(mpath_buf, (yyvsp[(3) - (3)].strval));
								mpath_len=strlen((yyvsp[(3) - (3)].strval)); 
								if(mpath_buf[mpath_len-1]!='/') {
									mpath_buf[mpath_len]='/';
									mpath_len++;
									mpath_buf[mpath_len]='\0';
								}
							;}
    break;

  case 227:
#line 1187 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 228:
#line 1188 "cfg.y"
    {
										disable_dns_failover=(yyvsp[(3) - (3)].intval);
									;}
    break;

  case 229:
#line 1191 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 230:
#line 1192 "cfg.y"
    {
										disable_dns_blacklist=(yyvsp[(3) - (3)].intval);
									;}
    break;

  case 231:
#line 1195 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 232:
#line 1196 "cfg.y"
    {
				s_tmp.s = (yyvsp[(3) - (7)].strval);
				s_tmp.len = strlen((yyvsp[(3) - (7)].strval));
				if ( create_bl_head( BL_CORE_ID, BL_READONLY_LIST,
				bl_head, bl_tail, &s_tmp)==0) {
					yyerror("failed to create blacklist\n");
					YYABORT;
				}
				bl_head = bl_tail = 0;
				;}
    break;

  case 233:
#line 1206 "cfg.y"
    {
				sl_fwd_disabled=(yyvsp[(3) - (3)].intval);
				;}
    break;

  case 234:
#line 1209 "cfg.y"
    { db_version_table=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 235:
#line 1210 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 236:
#line 1211 "cfg.y"
    { db_default_url=(yyvsp[(3) - (3)].strval); ;}
    break;

  case 237:
#line 1212 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 238:
#line 1213 "cfg.y"
    { disable_503_translation=(yyvsp[(3) - (3)].intval); ;}
    break;

  case 239:
#line 1214 "cfg.y"
    {
				yyerror("string value expected");
				;}
    break;

  case 240:
#line 1217 "cfg.y"
    { yyerror("unknown config variable"); ;}
    break;

  case 241:
#line 1220 "cfg.y"
    {
			if(*(yyvsp[(2) - (2)].strval)!='/' && mpath!=NULL
					&& strlen((yyvsp[(2) - (2)].strval))+mpath_len<255)
			{
				strcpy(mpath_buf+mpath_len, (yyvsp[(2) - (2)].strval));
				if (stat(mpath_buf, &statf) == -1) {
					i_tmp = strlen(mpath_buf);
					if(strchr((yyvsp[(2) - (2)].strval), '/')==NULL &&
							strncmp(mpath_buf+i_tmp-3, ".so", 3)==0)
					{
						if(i_tmp+strlen((yyvsp[(2) - (2)].strval))<255)
						{
							strcpy(mpath_buf+i_tmp-3, "/");
							strcpy(mpath_buf+i_tmp-2, (yyvsp[(2) - (2)].strval));
							if (stat(mpath_buf, &statf) == -1) {
								mpath_buf[mpath_len]='\0';
								LM_ERR("module '%s' not found in '%s'\n",
									(yyvsp[(2) - (2)].strval), mpath_buf);
								yyerror("failed to load module");
							}
						} else {
							yyerror("failed to load module - path too long");
						}
					} else {
						yyerror("failed to load module - not found");
					}
				}
				LM_DBG("loading module %s\n", mpath_buf);
				if (sr_load_module(mpath_buf)!=0){
					yyerror("failed to load module");
				}
				mpath_buf[mpath_len]='\0';
			} else {
				LM_DBG("loading module %s\n", (yyvsp[(2) - (2)].strval));
				if (sr_load_module((yyvsp[(2) - (2)].strval))!=0){
					yyerror("failed to load module");
				}
			}
		;}
    break;

  case 242:
#line 1259 "cfg.y"
    { yyerror("string expected");  ;}
    break;

  case 243:
#line 1260 "cfg.y"
    {
				if (set_mod_param_regex((yyvsp[(3) - (8)].strval), (yyvsp[(5) - (8)].strval), STR_PARAM, (yyvsp[(7) - (8)].strval)) != 0) {
					yyerrorf("Parameter <%s> not found in module <%s> - can't set",
						(yyvsp[(5) - (8)].strval), (yyvsp[(3) - (8)].strval));
				}
			;}
    break;

  case 244:
#line 1266 "cfg.y"
    {
				if (set_mod_param_regex((yyvsp[(3) - (8)].strval), (yyvsp[(5) - (8)].strval), INT_PARAM, (void*)(yyvsp[(7) - (8)].intval)) != 0) {
					yyerrorf("Parameter <%s> not found in module <%s> - can't set",
						(yyvsp[(5) - (8)].strval), (yyvsp[(3) - (8)].strval));
				}
			;}
    break;

  case 245:
#line 1272 "cfg.y"
    { yyerror("Invalid arguments"); ;}
    break;

  case 246:
#line 1276 "cfg.y"
    { (yyval.ipaddr)=(yyvsp[(1) - (1)].ipaddr); ;}
    break;

  case 247:
#line 1277 "cfg.y"
    { (yyval.ipaddr)=(yyvsp[(1) - (1)].ipaddr); ;}
    break;

  case 248:
#line 1280 "cfg.y"
    { 
											(yyval.ipaddr)=pkg_malloc(
													sizeof(struct ip_addr));
											if ((yyval.ipaddr)==0){
												LM_CRIT("cfg. "
													"parser: out of memory.\n"
													);
											}else{
												memset((yyval.ipaddr), 0, 
													sizeof(struct ip_addr));
												(yyval.ipaddr)->af=AF_INET;
												(yyval.ipaddr)->len=4;
												if (((yyvsp[(1) - (7)].intval)>255) || ((yyvsp[(1) - (7)].intval)<0) ||
													((yyvsp[(3) - (7)].intval)>255) || ((yyvsp[(3) - (7)].intval)<0) ||
													((yyvsp[(5) - (7)].intval)>255) || ((yyvsp[(5) - (7)].intval)<0) ||
													((yyvsp[(7) - (7)].intval)>255) || ((yyvsp[(7) - (7)].intval)<0)){
													yyerror("invalid ipv4"
															"address");
													(yyval.ipaddr)->u.addr32[0]=0;
													/* $$=0; */
												}else{
													(yyval.ipaddr)->u.addr[0]=(yyvsp[(1) - (7)].intval);
													(yyval.ipaddr)->u.addr[1]=(yyvsp[(3) - (7)].intval);
													(yyval.ipaddr)->u.addr[2]=(yyvsp[(5) - (7)].intval);
													(yyval.ipaddr)->u.addr[3]=(yyvsp[(7) - (7)].intval);
													/*
													$$=htonl( ($1<<24)|
													($3<<16)| ($5<<8)|$7 );
													*/
												}
											}
												;}
    break;

  case 249:
#line 1314 "cfg.y"
    {
					(yyval.ipaddr)=pkg_malloc(sizeof(struct ip_addr));
					if ((yyval.ipaddr)==0){
						LM_CRIT("ERROR: cfg. parser: out of memory.\n");
					}else{
						memset((yyval.ipaddr), 0, sizeof(struct ip_addr));
						(yyval.ipaddr)->af=AF_INET6;
						(yyval.ipaddr)->len=16;
					#ifdef USE_IPV6
						if (inet_pton(AF_INET6, (yyvsp[(1) - (1)].strval), (yyval.ipaddr)->u.addr)<=0){
							yyerror("bad ipv6 address");
						}
					#else
						yyerror("ipv6 address & no ipv6 support compiled in");
						YYABORT;
					#endif
					}
				;}
    break;

  case 250:
#line 1334 "cfg.y"
    { (yyval.ipaddr)=(yyvsp[(1) - (1)].ipaddr); ;}
    break;

  case 251:
#line 1335 "cfg.y"
    {(yyval.ipaddr)=(yyvsp[(2) - (3)].ipaddr); ;}
    break;

  case 252:
#line 1338 "cfg.y"
    { 
						#ifdef USE_TLS
							if (tls_new_server_domain((yyvsp[(3) - (6)].ipaddr), (yyvsp[(5) - (6)].intval))) 
								yyerror("tls_new_server_domain failed");
						#else	
							warn("tls support not compiled in");
						#endif
							;}
    break;

  case 254:
#line 1349 "cfg.y"
    { 
						#ifdef USE_TLS
							if (tls_new_client_domain((yyvsp[(3) - (6)].ipaddr), (yyvsp[(5) - (6)].intval)))
								yyerror("tls_new_client_domain failed");
						#else	
							warn("tls support not compiled in");
						#endif
							;}
    break;

  case 256:
#line 1360 "cfg.y"
    { 
						#ifdef USE_TLS
							if (tls_new_client_domain_name((yyvsp[(3) - (4)].strval), strlen((yyvsp[(3) - (4)].strval))))
								yyerror("tls_new_client_domain_name failed");
						#else	
							warn("tls support not compiled in");
						#endif
							;}
    break;

  case 262:
#line 1379 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->method=TLS_USE_SSLv23;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 263:
#line 1386 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->method=TLS_USE_SSLv2;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 264:
#line 1393 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->method=TLS_USE_SSLv3;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 265:
#line 1400 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->method=TLS_USE_TLSv1;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 266:
#line 1407 "cfg.y"
    { yyerror("SSLv23, SSLv2, SSLv3 or TLSv1 expected"); ;}
    break;

  case 267:
#line 1408 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->cert_file=(yyvsp[(3) - (3)].strval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 268:
#line 1415 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 269:
#line 1417 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->pkey_file=(yyvsp[(3) - (3)].strval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 270:
#line 1424 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 271:
#line 1426 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->ca_file=(yyvsp[(3) - (3)].strval); 
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 272:
#line 1433 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 273:
#line 1434 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_server_domains->ciphers_list=(yyvsp[(3) - (3)].strval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 274:
#line 1441 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 275:
#line 1442 "cfg.y"
    {
						#ifdef USE_TLS
									tls_server_domains->verify_cert=(yyvsp[(3) - (3)].intval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 276:
#line 1449 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 277:
#line 1450 "cfg.y"
    {
						#ifdef USE_TLS
									tls_server_domains->require_client_cert=(yyvsp[(3) - (3)].intval);
						#else
									warn( "tls support not compiled in");
						#endif
								;}
    break;

  case 278:
#line 1457 "cfg.y"
    { 
						yyerror("boolean value expected"); ;}
    break;

  case 279:
#line 1461 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->method=TLS_USE_SSLv23;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 280:
#line 1468 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->method=TLS_USE_SSLv2;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 281:
#line 1475 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->method=TLS_USE_SSLv3;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 282:
#line 1482 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->method=TLS_USE_TLSv1;
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 283:
#line 1489 "cfg.y"
    {
						yyerror("SSLv23, SSLv2, SSLv3 or TLSv1 expected"); ;}
    break;

  case 284:
#line 1491 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->cert_file=(yyvsp[(3) - (3)].strval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 285:
#line 1498 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 286:
#line 1500 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->pkey_file=(yyvsp[(3) - (3)].strval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 287:
#line 1507 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 288:
#line 1509 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->ca_file=(yyvsp[(3) - (3)].strval); 
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 289:
#line 1516 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 290:
#line 1517 "cfg.y"
    { 
						#ifdef USE_TLS
									tls_client_domains->ciphers_list=(yyvsp[(3) - (3)].strval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 291:
#line 1524 "cfg.y"
    { yyerror("string value expected"); ;}
    break;

  case 292:
#line 1525 "cfg.y"
    {
						#ifdef USE_TLS
									tls_client_domains->verify_cert=(yyvsp[(3) - (3)].intval);
						#else
									warn("tls support not compiled in");
						#endif
								;}
    break;

  case 293:
#line 1532 "cfg.y"
    { yyerror("boolean value expected"); ;}
    break;

  case 294:
#line 1535 "cfg.y"
    {
				(yyval.strval) = (yyvsp[(1) - (1)].strval);
				;}
    break;

  case 295:
#line 1538 "cfg.y"
    {
				tmp=int2str((yyvsp[(1) - (1)].intval), &i_tmp);
				if (((yyval.strval)=pkg_malloc(i_tmp+1))==0)
					yyerror("cfg. parser: out of memory.\n");
				memcpy( (yyval.strval), tmp, i_tmp);
				(yyval.strval)[i_tmp] = 0;
				;}
    break;

  case 296:
#line 1545 "cfg.y"
    {
				(yyval.strval) = (yyvsp[(1) - (1)].strval);
		;}
    break;

  case 297:
#line 1550 "cfg.y"
    {
						if (rlist[DEFAULT_RT].a!=0) {
							yyerror("overwritting default "
								"request routing table");
							YYABORT;
						}
						push((yyvsp[(3) - (4)].action), &rlist[DEFAULT_RT].a);
					;}
    break;

  case 298:
#line 1558 "cfg.y"
    { 
						if ( strtol((yyvsp[(3) - (7)].strval),&tmp,10)==0 && *tmp==0) {
							/* route[0] detected */
							if (rlist[DEFAULT_RT].a!=0) {
								yyerror("overwritting(2) default "
									"request routing table");
								YYABORT;
							}
							push((yyvsp[(6) - (7)].action), &rlist[DEFAULT_RT].a);
						} else {
							i_tmp = get_script_route_idx((yyvsp[(3) - (7)].strval),rlist,RT_NO,1);
							if (i_tmp==-1) YYABORT;
							push((yyvsp[(6) - (7)].action), &rlist[i_tmp].a);
						}
					;}
    break;

  case 299:
#line 1573 "cfg.y"
    { yyerror("invalid  route  statement"); ;}
    break;

  case 300:
#line 1576 "cfg.y"
    {
						i_tmp = get_script_route_idx((yyvsp[(3) - (7)].strval),failure_rlist,
								FAILURE_RT_NO,1);
						if (i_tmp==-1) YYABORT;
						push((yyvsp[(6) - (7)].action), &failure_rlist[i_tmp].a);
					;}
    break;

  case 301:
#line 1582 "cfg.y"
    { yyerror("invalid failure_route statement"); ;}
    break;

  case 302:
#line 1585 "cfg.y"
    {
						if (onreply_rlist[DEFAULT_RT].a!=0) {
							yyerror("overwritting default "
								"onreply routing table");
							YYABORT;
						}
						push((yyvsp[(3) - (4)].action), &onreply_rlist[DEFAULT_RT].a);
					;}
    break;

  case 303:
#line 1593 "cfg.y"
    {
						i_tmp = get_script_route_idx((yyvsp[(3) - (7)].strval),onreply_rlist,
								ONREPLY_RT_NO,1);
						if (i_tmp==-1) YYABORT;
						push((yyvsp[(6) - (7)].action), &onreply_rlist[i_tmp].a);
					;}
    break;

  case 304:
#line 1599 "cfg.y"
    { yyerror("invalid onreply_route statement"); ;}
    break;

  case 305:
#line 1602 "cfg.y"
    {
						i_tmp = get_script_route_idx((yyvsp[(3) - (7)].strval),branch_rlist,
								BRANCH_RT_NO,1);
						if (i_tmp==-1) YYABORT;
						push((yyvsp[(6) - (7)].action), &branch_rlist[i_tmp].a);
					;}
    break;

  case 306:
#line 1608 "cfg.y"
    { yyerror("invalid branch_route statement"); ;}
    break;

  case 307:
#line 1611 "cfg.y"
    {
						if (error_rlist.a!=0) {
							yyerror("overwritting default "
								"error routing table");
							YYABORT;
						}
						push((yyvsp[(3) - (4)].action), &error_rlist.a);
					;}
    break;

  case 308:
#line 1619 "cfg.y"
    { yyerror("invalid error_route statement"); ;}
    break;

  case 309:
#line 1622 "cfg.y"
    {
						if (local_rlist.a!=0) {
							yyerror("re-definition of local "
								"route detected");
							YYABORT;
						}
						push((yyvsp[(3) - (4)].action), &local_rlist.a);
					;}
    break;

  case 310:
#line 1630 "cfg.y"
    { yyerror("invalid local_route statement"); ;}
    break;

  case 311:
#line 1633 "cfg.y"
    {
						if (startup_rlist.a!=0) {
							yyerror("re-definition of startup "
								"route detected");
							YYABORT;
						}
						push((yyvsp[(3) - (4)].action), &startup_rlist.a);
					;}
    break;

  case 312:
#line 1641 "cfg.y"
    { yyerror("invalid startup_route statement"); ;}
    break;

  case 313:
#line 1644 "cfg.y"
    {
						i_tmp = 0;
						while (timer_rlist[i_tmp].a!=0 && i_tmp < TIMER_RT_NO) {
							i_tmp++;
						}
						if(i_tmp == TIMER_RT_NO) {
							yyerror("Too many timer routes defined\n");
							YYABORT;
						}
						timer_rlist[i_tmp].interval = (yyvsp[(5) - (9)].intval);
						push((yyvsp[(8) - (9)].action), &timer_rlist[i_tmp].a);
					;}
    break;

  case 314:
#line 1656 "cfg.y"
    { yyerror("invalid timer_route statement"); ;}
    break;

  case 315:
#line 1659 "cfg.y"
    {
						i_tmp = get_script_route_idx((yyvsp[(3) - (7)].strval),event_rlist,
								EVENT_RT_NO,1);
						if (i_tmp==-1) YYABORT;
						push((yyvsp[(6) - (7)].action), &event_rlist[i_tmp].a);
					;}
    break;

  case 316:
#line 1665 "cfg.y"
    { yyerror("invalid timer_route statement"); ;}
    break;

  case 317:
#line 1670 "cfg.y"
    { (yyval.expr)=mk_exp(AND_OP, (yyvsp[(1) - (3)].expr), (yyvsp[(3) - (3)].expr)); ;}
    break;

  case 318:
#line 1671 "cfg.y"
    { (yyval.expr)=mk_exp(OR_OP, (yyvsp[(1) - (3)].expr), (yyvsp[(3) - (3)].expr));  ;}
    break;

  case 319:
#line 1672 "cfg.y"
    { (yyval.expr)=mk_exp(NOT_OP, (yyvsp[(2) - (2)].expr), 0);  ;}
    break;

  case 320:
#line 1673 "cfg.y"
    { (yyval.expr)=mk_exp(EVAL_OP, (yyvsp[(2) - (3)].expr), 0); ;}
    break;

  case 321:
#line 1674 "cfg.y"
    { (yyval.expr)=(yyvsp[(2) - (3)].expr); ;}
    break;

  case 322:
#line 1675 "cfg.y"
    { (yyval.expr)=(yyvsp[(1) - (1)].expr); ;}
    break;

  case 323:
#line 1678 "cfg.y"
    {(yyval.intval)=EQUAL_OP; ;}
    break;

  case 324:
#line 1679 "cfg.y"
    {(yyval.intval)=DIFF_OP; ;}
    break;

  case 325:
#line 1682 "cfg.y"
    {(yyval.intval)=GT_OP; ;}
    break;

  case 326:
#line 1683 "cfg.y"
    {(yyval.intval)=LT_OP; ;}
    break;

  case 327:
#line 1684 "cfg.y"
    {(yyval.intval)=GTE_OP; ;}
    break;

  case 328:
#line 1685 "cfg.y"
    {(yyval.intval)=LTE_OP; ;}
    break;

  case 329:
#line 1687 "cfg.y"
    {(yyval.intval)=MATCH_OP; ;}
    break;

  case 330:
#line 1688 "cfg.y"
    {(yyval.intval)=NOTMATCH_OP; ;}
    break;

  case 331:
#line 1691 "cfg.y"
    {(yyval.intval)=(yyvsp[(1) - (1)].intval); ;}
    break;

  case 332:
#line 1692 "cfg.y"
    {(yyval.intval)=(yyvsp[(1) - (1)].intval); ;}
    break;

  case 333:
#line 1695 "cfg.y"
    {(yyval.intval)=(yyvsp[(1) - (1)].intval); ;}
    break;

  case 334:
#line 1696 "cfg.y"
    {(yyval.intval)=(yyvsp[(1) - (1)].intval); ;}
    break;

  case 335:
#line 1697 "cfg.y"
    {(yyval.intval)=(yyvsp[(1) - (1)].intval); ;}
    break;

  case 336:
#line 1700 "cfg.y"
    {(yyval.intval)=URI_O;;}
    break;

  case 337:
#line 1701 "cfg.y"
    {(yyval.intval)=FROM_URI_O;;}
    break;

  case 338:
#line 1702 "cfg.y"
    {(yyval.intval)=TO_URI_O;;}
    break;

  case 339:
#line 1705 "cfg.y"
    { 
				spec = (pv_spec_t*)pkg_malloc(sizeof(pv_spec_t));
				if (spec==NULL){
					yyerror("no more pkg memory\n");
				}
				memset(spec, 0, sizeof(pv_spec_t));
				tstr.s = (yyvsp[(1) - (1)].strval);
				tstr.len = strlen(tstr.s);
				if(pv_parse_spec(&tstr, spec)==NULL)
				{
					yyerror("unknown script variable");
				}
				(yyval.specval) = spec;
			;}
    break;

  case 340:
#line 1719 "cfg.y"
    {
			(yyval.specval)=0; yyerror("invalid script variable name");
		;}
    break;

  case 341:
#line 1724 "cfg.y"
    {(yyval.expr)=(yyvsp[(1) - (1)].expr); ;}
    break;

  case 342:
#line 1725 "cfg.y"
    {(yyval.expr)=mk_elem( NO_OP, ACTION_O, 0, ACTIONS_ST, (yyvsp[(1) - (1)].action) ); ;}
    break;

  case 343:
#line 1726 "cfg.y"
    {(yyval.expr)=mk_elem( NO_OP, NUMBER_O, 0, NUMBER_ST, 
											(void*)(yyvsp[(1) - (1)].intval) ); ;}
    break;

  case 344:
#line 1728 "cfg.y"
    {
				(yyval.expr)=mk_elem(NO_OP, SCRIPTVAR_O,0,SCRIPTVAR_ST,(void*)(yyvsp[(1) - (1)].specval));
			;}
    break;

  case 345:
#line 1731 "cfg.y"
    {(yyval.expr) = mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, STR_ST, (yyvsp[(3) - (3)].strval)); 
				 			;}
    break;

  case 346:
#line 1733 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), DSTIP_O, 0, NET_ST, (yyvsp[(3) - (3)].ipnet));
								;}
    break;

  case 347:
#line 1735 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), DSTIP_O, 0, STR_ST, (yyvsp[(3) - (3)].strval));
								;}
    break;

  case 348:
#line 1737 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SRCIP_O, 0, NET_ST, (yyvsp[(3) - (3)].ipnet));
								;}
    break;

  case 349:
#line 1739 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SRCIP_O, 0, STR_ST, (yyvsp[(3) - (3)].strval));
								;}
    break;

  case 350:
#line 1743 "cfg.y"
    {(yyval.expr)= mk_elem((yyvsp[(2) - (3)].intval), METHOD_O, 0, STR_ST, (yyvsp[(3) - (3)].strval));
									;}
    break;

  case 351:
#line 1745 "cfg.y"
    {(yyval.expr) = mk_elem((yyvsp[(2) - (3)].intval), METHOD_O, 0, STR_ST, (yyvsp[(3) - (3)].strval)); 
				 			;}
    break;

  case 352:
#line 1747 "cfg.y"
    { (yyval.expr)=0; yyerror("string expected"); ;}
    break;

  case 353:
#line 1748 "cfg.y"
    { (yyval.expr)=0; yyerror("invalid operator,"
										"== , !=, or =~ expected");
						;}
    break;

  case 354:
#line 1751 "cfg.y"
    {
				(yyval.expr)=mk_elem( (yyvsp[(2) - (3)].intval), SCRIPTVAR_O,(void*)(yyvsp[(1) - (3)].specval),SCRIPTVAR_ST,(void*)(yyvsp[(3) - (3)].specval));
			;}
    break;

  case 355:
#line 1754 "cfg.y"
    {
				(yyval.expr)=mk_elem( (yyvsp[(2) - (3)].intval), SCRIPTVAR_O,(void*)(yyvsp[(1) - (3)].specval),STR_ST,(yyvsp[(3) - (3)].strval));
			;}
    break;

  case 356:
#line 1757 "cfg.y"
    {
				(yyval.expr)=mk_elem( (yyvsp[(2) - (3)].intval), SCRIPTVAR_O,(void*)(yyvsp[(1) - (3)].specval),STR_ST,(yyvsp[(3) - (3)].strval));
			;}
    break;

  case 357:
#line 1760 "cfg.y"
    {
				(yyval.expr)=mk_elem( (yyvsp[(2) - (3)].intval), SCRIPTVAR_O,(void*)(yyvsp[(1) - (3)].specval),NUMBER_ST,(void *)(yyvsp[(3) - (3)].intval));
			;}
    break;

  case 358:
#line 1763 "cfg.y"
    { 
				(yyval.expr)=mk_elem( (yyvsp[(2) - (3)].intval), SCRIPTVAR_O,(void*)(yyvsp[(1) - (3)].specval), MYSELF_ST, 0);
			;}
    break;

  case 359:
#line 1766 "cfg.y"
    { 
				(yyval.expr)=mk_elem( (yyvsp[(2) - (3)].intval), SCRIPTVAR_O,(void*)(yyvsp[(1) - (3)].specval), NULLV_ST, 0);
			;}
    break;

  case 360:
#line 1769 "cfg.y"
    {(yyval.expr) = mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, STR_ST, (yyvsp[(3) - (3)].strval)); 
				 				;}
    break;

  case 361:
#line 1771 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, MYSELF_ST, 0);
								;}
    break;

  case 362:
#line 1773 "cfg.y"
    { (yyval.expr)=0; yyerror("string or MYSELF expected"); ;}
    break;

  case 363:
#line 1774 "cfg.y"
    { (yyval.expr)=0; yyerror("invalid operator,"
									" == , != or =~ expected");
					;}
    break;

  case 364:
#line 1777 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SRCPORT_O, 0, NUMBER_ST,
												(void *) (yyvsp[(3) - (3)].intval) ); ;}
    break;

  case 365:
#line 1779 "cfg.y"
    { (yyval.expr)=0; yyerror("number expected"); ;}
    break;

  case 366:
#line 1780 "cfg.y"
    { (yyval.expr)=0; yyerror("==, !=, <,>, >= or <=  expected"); ;}
    break;

  case 367:
#line 1781 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), DSTPORT_O, 0, NUMBER_ST,
												(void *) (yyvsp[(3) - (3)].intval) ); ;}
    break;

  case 368:
#line 1783 "cfg.y"
    { (yyval.expr)=0; yyerror("number expected"); ;}
    break;

  case 369:
#line 1784 "cfg.y"
    { (yyval.expr)=0; yyerror("==, !=, <,>, >= or <=  expected"); ;}
    break;

  case 370:
#line 1785 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), PROTO_O, 0, NUMBER_ST,
												(void *) (yyvsp[(3) - (3)].intval) ); ;}
    break;

  case 371:
#line 1787 "cfg.y"
    { (yyval.expr)=0;
								yyerror("protocol expected (udp, tcp or tls)");
							;}
    break;

  case 372:
#line 1790 "cfg.y"
    { (yyval.expr)=0; yyerror("equal/!= operator expected"); ;}
    break;

  case 373:
#line 1791 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), AF_O, 0, NUMBER_ST,
												(void *) (yyvsp[(3) - (3)].intval) ); ;}
    break;

  case 374:
#line 1793 "cfg.y"
    { (yyval.expr)=0; yyerror("number expected"); ;}
    break;

  case 375:
#line 1794 "cfg.y"
    { (yyval.expr)=0; yyerror("equal/!= operator expected"); ;}
    break;

  case 376:
#line 1795 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), MSGLEN_O, 0, NUMBER_ST,
												(void *) (yyvsp[(3) - (3)].intval) ); ;}
    break;

  case 377:
#line 1797 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), MSGLEN_O, 0, NUMBER_ST,
												(void *) BUF_SIZE); ;}
    break;

  case 378:
#line 1799 "cfg.y"
    { (yyval.expr)=0; yyerror("number expected"); ;}
    break;

  case 379:
#line 1800 "cfg.y"
    { (yyval.expr)=0; yyerror("equal/!= operator expected"); ;}
    break;

  case 380:
#line 1801 "cfg.y"
    {	s_tmp.s=(yyvsp[(3) - (3)].strval);
									s_tmp.len=strlen((yyvsp[(3) - (3)].strval));
									ip_tmp=str2ip(&s_tmp);
									if (ip_tmp==0)
										ip_tmp=str2ip6(&s_tmp);
									if (ip_tmp){
										(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SRCIP_O, 0, NET_ST,
												mk_net_bitlen(ip_tmp, 
														ip_tmp->len*8) );
									}else{
										(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SRCIP_O, 0, STR_ST,
												(yyvsp[(3) - (3)].strval));
									}
								;}
    break;

  case 381:
#line 1815 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SRCIP_O, 0, MYSELF_ST, 0);
								;}
    break;

  case 382:
#line 1817 "cfg.y"
    { (yyval.expr)=0; yyerror( "ip address or hostname"
						 "expected" ); ;}
    break;

  case 383:
#line 1819 "cfg.y"
    { (yyval.expr)=0; 
						 yyerror("invalid operator, ==, != or =~ expected");;}
    break;

  case 384:
#line 1821 "cfg.y"
    {	s_tmp.s=(yyvsp[(3) - (3)].strval);
									s_tmp.len=strlen((yyvsp[(3) - (3)].strval));
									ip_tmp=str2ip(&s_tmp);
									if (ip_tmp==0)
										ip_tmp=str2ip6(&s_tmp);
									if (ip_tmp){
										(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), DSTIP_O, 0, NET_ST,
												mk_net_bitlen(ip_tmp, 
														ip_tmp->len*8) );
									}else{
										(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), DSTIP_O, 0, STR_ST,
												(yyvsp[(3) - (3)].strval));
									}
								;}
    break;

  case 385:
#line 1835 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), DSTIP_O, 0, MYSELF_ST, 0);
								;}
    break;

  case 386:
#line 1837 "cfg.y"
    { (yyval.expr)=0; yyerror( "ip address or hostname"
						 			"expected" ); ;}
    break;

  case 387:
#line 1839 "cfg.y"
    { (yyval.expr)=0; 
						yyerror("invalid operator, ==, != or =~ expected");;}
    break;

  case 388:
#line 1841 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(3) - (3)].intval), 0, MYSELF_ST, 0);
								;}
    break;

  case 389:
#line 1843 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SRCIP_O, 0, MYSELF_ST, 0);
								;}
    break;

  case 390:
#line 1845 "cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), DSTIP_O, 0, MYSELF_ST, 0);
								;}
    break;

  case 391:
#line 1847 "cfg.y"
    {	(yyval.expr)=0; 
									yyerror(" URI, SRCIP or DSTIP expected"); ;}
    break;

  case 392:
#line 1849 "cfg.y"
    { (yyval.expr)=0; 
							yyerror ("invalid operator, == or != expected");
						;}
    break;

  case 393:
#line 1854 "cfg.y"
    { (yyval.ipnet)=mk_net((yyvsp[(1) - (3)].ipaddr), (yyvsp[(3) - (3)].ipaddr)); ;}
    break;

  case 394:
#line 1855 "cfg.y"
    {	if (((yyvsp[(3) - (3)].intval)<0) || ((yyvsp[(3) - (3)].intval)>(long)(yyvsp[(1) - (3)].ipaddr)->len*8)){
								yyerror("invalid bit number in netmask");
								(yyval.ipnet)=0;
							}else{
								(yyval.ipnet)=mk_net_bitlen((yyvsp[(1) - (3)].ipaddr), (yyvsp[(3) - (3)].intval));
							/*
								$$=mk_net($1, 
										htonl( ($3)?~( (1<<(32-$3))-1 ):0 ) );
							*/
							}
						;}
    break;

  case 395:
#line 1866 "cfg.y"
    { (yyval.ipnet)=mk_net_bitlen((yyvsp[(1) - (1)].ipaddr), (yyvsp[(1) - (1)].ipaddr)->len*8); ;}
    break;

  case 396:
#line 1867 "cfg.y"
    { (yyval.ipnet)=0;
						 yyerror("netmask (eg:255.0.0.0 or 8) expected");
						;}
    break;

  case 397:
#line 1874 "cfg.y"
    {(yyval.strval)=".";;}
    break;

  case 398:
#line 1875 "cfg.y"
    {(yyval.strval)="-"; ;}
    break;

  case 399:
#line 1878 "cfg.y"
    { (yyval.strval)=(yyvsp[(1) - (1)].strval); ;}
    break;

  case 400:
#line 1879 "cfg.y"
    { (yyval.strval)=(char*)pkg_malloc(strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))+1);
						  if ((yyval.strval)==0){
							LM_CRIT("cfg. parser: memory allocation"
										" failure while parsing host\n");
						  }else{
							memcpy((yyval.strval), (yyvsp[(1) - (3)].strval), strlen((yyvsp[(1) - (3)].strval)));
							(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))]=*(yyvsp[(2) - (3)].strval);
							memcpy((yyval.strval)+strlen((yyvsp[(1) - (3)].strval))+1, (yyvsp[(3) - (3)].strval), strlen((yyvsp[(3) - (3)].strval)));
							(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))]=0;
						  }
						  pkg_free((yyvsp[(1) - (3)].strval)); pkg_free((yyvsp[(3) - (3)].strval));
						;}
    break;

  case 401:
#line 1891 "cfg.y"
    { (yyval.strval)=0; pkg_free((yyvsp[(1) - (3)].strval)); yyerror("invalid hostname (use quotes if hostname has config keywords)"); ;}
    break;

  case 402:
#line 1895 "cfg.y"
    { (yyval.intval) = EQ_T; ;}
    break;

  case 403:
#line 1896 "cfg.y"
    { (yyval.intval) = COLONEQ_T; ;}
    break;

  case 404:
#line 1897 "cfg.y"
    { (yyval.intval) = PLUSEQ_T; ;}
    break;

  case 405:
#line 1898 "cfg.y"
    { (yyval.intval) = MINUSEQ_T;;}
    break;

  case 406:
#line 1899 "cfg.y"
    { (yyval.intval) = DIVEQ_T; ;}
    break;

  case 407:
#line 1900 "cfg.y"
    { (yyval.intval) = MULTEQ_T; ;}
    break;

  case 408:
#line 1901 "cfg.y"
    { (yyval.intval) = MODULOEQ_T; ;}
    break;

  case 409:
#line 1902 "cfg.y"
    { (yyval.intval) = BANDEQ_T; ;}
    break;

  case 410:
#line 1903 "cfg.y"
    { (yyval.intval) = BOREQ_T; ;}
    break;

  case 411:
#line 1904 "cfg.y"
    { (yyval.intval) = BXOREQ_T; ;}
    break;

  case 412:
#line 1908 "cfg.y"
    { (yyval.expr) = mk_elem(VALUE_OP, NUMBERV_O, (void*)(yyvsp[(1) - (1)].intval), 0, 0); ;}
    break;

  case 413:
#line 1909 "cfg.y"
    { (yyval.expr) = mk_elem(VALUE_OP, STRINGV_O, (yyvsp[(1) - (1)].strval), 0, 0); ;}
    break;

  case 414:
#line 1910 "cfg.y"
    { (yyval.expr) = mk_elem(VALUE_OP, STRINGV_O, (yyvsp[(1) - (1)].strval), 0, 0); ;}
    break;

  case 415:
#line 1911 "cfg.y"
    { (yyval.expr) = mk_elem(VALUE_OP, SCRIPTVAR_O, (yyvsp[(1) - (1)].specval), 0, 0); ;}
    break;

  case 416:
#line 1912 "cfg.y"
    { (yyval.expr)= (yyvsp[(1) - (1)].expr); ;}
    break;

  case 417:
#line 1913 "cfg.y"
    { (yyval.expr)=mk_elem( NO_OP, ACTION_O, 0, ACTIONS_ST, (yyvsp[(1) - (1)].action) ); ;}
    break;

  case 418:
#line 1914 "cfg.y"
    { 
				(yyval.expr) = mk_elem(PLUS_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 419:
#line 1917 "cfg.y"
    { 
				(yyval.expr) = mk_elem(MINUS_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr)); 
			;}
    break;

  case 420:
#line 1920 "cfg.y"
    { 
				(yyval.expr) = mk_elem(MULT_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 421:
#line 1923 "cfg.y"
    { 
				(yyval.expr) = mk_elem(DIV_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 422:
#line 1926 "cfg.y"
    { 
				(yyval.expr) = mk_elem(MODULO_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 423:
#line 1929 "cfg.y"
    { 
				(yyval.expr) = mk_elem(BAND_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 424:
#line 1932 "cfg.y"
    { 
				(yyval.expr) = mk_elem(BOR_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 425:
#line 1935 "cfg.y"
    { 
				(yyval.expr) = mk_elem(BXOR_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 426:
#line 1938 "cfg.y"
    { 
				(yyval.expr) = mk_elem(BLSHIFT_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 427:
#line 1941 "cfg.y"
    { 
				(yyval.expr) = mk_elem(BRSHIFT_OP, EXPR_O, (yyvsp[(1) - (3)].expr), EXPR_ST, (yyvsp[(3) - (3)].expr));
			;}
    break;

  case 428:
#line 1944 "cfg.y"
    { 
				(yyval.expr) = mk_elem(BNOT_OP, EXPR_O, (yyvsp[(2) - (2)].expr), 0, 0);
			;}
    break;

  case 429:
#line 1947 "cfg.y"
    { (yyval.expr) = (yyvsp[(2) - (3)].expr); ;}
    break;

  case 430:
#line 1950 "cfg.y"
    {	
			if(!pv_is_w((yyvsp[(1) - (3)].specval)))
				yyerror("invalid left operand in assignment");
			if((yyvsp[(1) - (3)].specval)->trans!=0)
				yyerror(
					"transformations not accepted in right side of assignment");

			mk_action2( (yyval.action), (yyvsp[(2) - (3)].intval),
					SCRIPTVAR_ST,
					EXPR_ST,
					(yyvsp[(1) - (3)].specval),
					(yyvsp[(3) - (3)].expr));
		;}
    break;

  case 431:
#line 1963 "cfg.y"
    {
			if(!pv_is_w((yyvsp[(1) - (3)].specval)))
				yyerror("invalid left operand in assignment");
			if((yyvsp[(1) - (3)].specval)->trans!=0)
				yyerror(
					"transformations not accepted in right side of assignment");

			mk_action2( (yyval.action), EQ_T,
					SCRIPTVAR_ST,
					NULLV_ST,
					(yyvsp[(1) - (3)].specval),
					0);
		;}
    break;

  case 432:
#line 1976 "cfg.y"
    {
			if(!pv_is_w((yyvsp[(1) - (3)].specval)))
				yyerror("invalid left operand in assignment");
			/* not all can get NULL with := */
			switch((yyvsp[(1) - (3)].specval)->type) {
				case PVT_AVP:
				break;
				default:
					yyerror("invalid left operand in NULL assignment");
			}
			if((yyvsp[(1) - (3)].specval)->trans!=0)
				yyerror(
					"transformations not accepted in right side of assignment");

			mk_action2( (yyval.action), COLONEQ_T,
					SCRIPTVAR_ST,
					NULLV_ST,
					(yyvsp[(1) - (3)].specval),
					0);
		;}
    break;

  case 433:
#line 1998 "cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action); ;}
    break;

  case 434:
#line 1999 "cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action); ;}
    break;

  case 435:
#line 2000 "cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action); ;}
    break;

  case 436:
#line 2001 "cfg.y"
    { (yyval.action)=(yyvsp[(2) - (3)].action); ;}
    break;

  case 437:
#line 2002 "cfg.y"
    { (yyval.action)=0; ;}
    break;

  case 438:
#line 2005 "cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action); ;}
    break;

  case 439:
#line 2006 "cfg.y"
    { (yyval.action)=(yyvsp[(2) - (3)].action); ;}
    break;

  case 440:
#line 2007 "cfg.y"
    { (yyval.action)=0; ;}
    break;

  case 441:
#line 2010 "cfg.y"
    {(yyval.action)=append_action((yyvsp[(1) - (2)].action), (yyvsp[(2) - (2)].action)); ;}
    break;

  case 442:
#line 2011 "cfg.y"
    {(yyval.action)=(yyvsp[(1) - (1)].action);;}
    break;

  case 443:
#line 2012 "cfg.y"
    { (yyval.action)=0; yyerror("bad command!)"); ;}
    break;

  case 444:
#line 2015 "cfg.y"
    {(yyval.action)=(yyvsp[(1) - (2)].action);;}
    break;

  case 445:
#line 2016 "cfg.y"
    {(yyval.action)=(yyvsp[(1) - (1)].action);;}
    break;

  case 446:
#line 2017 "cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action);;}
    break;

  case 447:
#line 2018 "cfg.y"
    {(yyval.action)=(yyvsp[(1) - (1)].action);;}
    break;

  case 448:
#line 2019 "cfg.y"
    {(yyval.action)=(yyvsp[(1) - (2)].action);;}
    break;

  case 449:
#line 2020 "cfg.y"
    {(yyval.action)=0;;}
    break;

  case 450:
#line 2021 "cfg.y"
    { (yyval.action)=0; yyerror("bad command: missing ';'?"); ;}
    break;

  case 451:
#line 2024 "cfg.y"
    { mk_action3( (yyval.action), IF_T,
													 EXPR_ST,
													 ACTIONS_ST,
													 NOSUBTYPE,
													 (yyvsp[(2) - (3)].expr),
													 (yyvsp[(3) - (3)].action),
													 0);
									;}
    break;

  case 452:
#line 2032 "cfg.y"
    { mk_action3( (yyval.action), IF_T,
													 EXPR_ST,
													 ACTIONS_ST,
													 ACTIONS_ST,
													 (yyvsp[(2) - (5)].expr),
													 (yyvsp[(3) - (5)].action),
													 (yyvsp[(5) - (5)].action));
									;}
    break;

  case 453:
#line 2042 "cfg.y"
    { mk_action2( (yyval.action), WHILE_T,
													 EXPR_ST,
													 ACTIONS_ST,
													 (yyvsp[(2) - (3)].expr),
													 (yyvsp[(3) - (3)].action));
									;}
    break;

  case 454:
#line 2050 "cfg.y"
    {
											mk_action2( (yyval.action), SWITCH_T,
														SCRIPTVAR_ST,
														ACTIONS_ST,
														(yyvsp[(3) - (7)].specval),
														(yyvsp[(6) - (7)].action));
									;}
    break;

  case 455:
#line 2059 "cfg.y"
    { (yyval.action)=append_action((yyvsp[(1) - (2)].action), (yyvsp[(2) - (2)].action)); ;}
    break;

  case 456:
#line 2060 "cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action); ;}
    break;

  case 457:
#line 2062 "cfg.y"
    {(yyval.action)=append_action((yyvsp[(1) - (2)].action), (yyvsp[(2) - (2)].action)); ;}
    break;

  case 458:
#line 2063 "cfg.y"
    {(yyval.action)=(yyvsp[(1) - (1)].action);;}
    break;

  case 459:
#line 2067 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													NUMBER_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (6)].intval),
													(yyvsp[(4) - (6)].action),
													(void*)1);
											;}
    break;

  case 460:
#line 2076 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													NUMBER_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (5)].intval),
													0,
													(void*)1);
											;}
    break;

  case 461:
#line 2084 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													NUMBER_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (4)].intval),
													(yyvsp[(4) - (4)].action),
													(void*)0);
									;}
    break;

  case 462:
#line 2092 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													NUMBER_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (3)].intval),
													0,
													(void*)0);
							;}
    break;

  case 463:
#line 2101 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													STR_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (6)].strval),
													(yyvsp[(4) - (6)].action),
													(void*)1);
											;}
    break;

  case 464:
#line 2110 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													STR_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (5)].strval),
													0,
													(void*)1);
											;}
    break;

  case 465:
#line 2118 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													STR_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (4)].strval),
													(yyvsp[(4) - (4)].action),
													(void*)0);
									;}
    break;

  case 466:
#line 2126 "cfg.y"
    { mk_action3( (yyval.action), CASE_T,
													STR_ST,
													ACTIONS_ST,
													NUMBER_ST,
													(void*)(yyvsp[(2) - (3)].strval),
													0,
													(void*)0);
							;}
    break;

  case 467:
#line 2137 "cfg.y"
    { mk_action2( (yyval.action), DEFAULT_T,
													ACTIONS_ST,
													0,
													(yyvsp[(3) - (3)].action),
													0);
									;}
    break;

  case 468:
#line 2143 "cfg.y"
    { mk_action2( (yyval.action), DEFAULT_T,
													ACTIONS_ST,
													0,
													0,
													0);
									;}
    break;

  case 469:
#line 2151 "cfg.y"
    {
										elems[1].type = STRING_ST;
										elems[1].u.data = (yyvsp[(1) - (1)].strval);
										(yyval.intval)=1;
										;}
    break;

  case 470:
#line 2156 "cfg.y"
    {
										if ((yyvsp[(1) - (3)].intval)+1>=MAX_ACTION_ELEMS) {
											yyerror("too many arguments in function\n");
											(yyval.intval)=0;
										}
										elems[(yyvsp[(1) - (3)].intval)+1].type = STRING_ST;
										elems[(yyvsp[(1) - (3)].intval)+1].u.data = (yyvsp[(3) - (3)].strval);
										(yyval.intval)=(yyvsp[(1) - (3)].intval)+1;
										;}
    break;

  case 471:
#line 2165 "cfg.y"
    {
										(yyval.intval)=0;
										yyerror("numbers used as parameters - they should be quoted");
										;}
    break;

  case 472:
#line 2169 "cfg.y"
    {
										(yyval.intval)=0;
										yyerror("numbers used as parameters - they should be quoted");
										;}
    break;

  case 473:
#line 2175 "cfg.y"
    {
						route_elems[0].type = STRING_ST;
						route_elems[0].u.data = (yyvsp[(1) - (1)].strval);
						(yyval.intval)=1;
			;}
    break;

  case 474:
#line 2180 "cfg.y"
    {
						route_elems[0].type = NUMBER_ST;
						route_elems[0].u.data = (void*)(long)(yyvsp[(1) - (1)].intval);
						(yyval.intval)=1;
			;}
    break;

  case 475:
#line 2185 "cfg.y"
    {
						route_elems[0].type = SCRIPTVAR_ST;
						route_elems[0].u.data = (yyvsp[(1) - (1)].specval);
						(yyval.intval)=1;
			;}
    break;

  case 476:
#line 2190 "cfg.y"
    {
						if ((yyvsp[(1) - (3)].intval)>=MAX_ACTION_ELEMS) {
							yyerror("too many arguments in function\n");
							(yyval.intval)=-1;
						} else {
							route_elems[(yyvsp[(1) - (3)].intval)].type = STRING_ST;
							route_elems[(yyvsp[(1) - (3)].intval)].u.data = (yyvsp[(3) - (3)].strval);
							(yyval.intval)=(yyvsp[(1) - (3)].intval)+1;
						}
			;}
    break;

  case 477:
#line 2200 "cfg.y"
    {
						if ((yyvsp[(1) - (3)].intval)>=MAX_ACTION_ELEMS) {
							yyerror("too many arguments in function\n");
							(yyval.intval)=-1;
						} else {
							route_elems[(yyvsp[(1) - (3)].intval)].type = NUMBER_ST;
							route_elems[(yyvsp[(1) - (3)].intval)].u.data = (void*)(long)(yyvsp[(3) - (3)].intval);
							(yyval.intval)=(yyvsp[(1) - (3)].intval)+1;
						}
			;}
    break;

  case 478:
#line 2210 "cfg.y"
    {
						if ((yyvsp[(1) - (3)].intval)+1>=MAX_ACTION_ELEMS) {
							yyerror("too many arguments in function\n");
							(yyval.intval)=-1;
						} else {
							route_elems[(yyvsp[(1) - (3)].intval)].type = SCRIPTVAR_ST;
							route_elems[(yyvsp[(1) - (3)].intval)].u.data = (yyvsp[(3) - (3)].specval);
							(yyval.intval)=(yyvsp[(1) - (3)].intval)+1;
						}
			;}
    break;

  case 479:
#line 2222 "cfg.y"
    { mk_action2( (yyval.action), FORWARD_T,
											STRING_ST,
											0,
											(yyvsp[(3) - (4)].strval),
											0);
										;}
    break;

  case 480:
#line 2228 "cfg.y"
    {
										mk_action2( (yyval.action), FORWARD_T,
											0,
											0,
											0,
											0);
										;}
    break;

  case 481:
#line 2235 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 482:
#line 2236 "cfg.y"
    { (yyval.action)=0; yyerror("bad forward "
										"argument"); ;}
    break;

  case 483:
#line 2239 "cfg.y"
    { mk_action2( (yyval.action), SEND_T,
											STRING_ST,
											0,
											(yyvsp[(3) - (4)].strval),
											0);
										;}
    break;

  case 484:
#line 2245 "cfg.y"
    { mk_action2( (yyval.action), SEND_T,
											STRING_ST,
											STRING_ST,
											(yyvsp[(3) - (6)].strval),
											(yyvsp[(5) - (6)].strval));
										;}
    break;

  case 485:
#line 2251 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 486:
#line 2252 "cfg.y"
    { (yyval.action)=0; yyerror("bad send"
													"argument"); ;}
    break;

  case 487:
#line 2254 "cfg.y"
    {mk_action2( (yyval.action), DROP_T,0, 0, 0, 0); ;}
    break;

  case 488:
#line 2255 "cfg.y"
    {mk_action2( (yyval.action), DROP_T,0, 0, 0, 0); ;}
    break;

  case 489:
#line 2256 "cfg.y"
    {mk_action2( (yyval.action), EXIT_T,0, 0, 0, 0); ;}
    break;

  case 490:
#line 2257 "cfg.y"
    {mk_action2( (yyval.action), EXIT_T,0, 0, 0, 0); ;}
    break;

  case 491:
#line 2258 "cfg.y"
    {mk_action2( (yyval.action), RETURN_T,
																NUMBER_ST, 
																0,
																(void*)(yyvsp[(3) - (4)].intval),
																0);
												;}
    break;

  case 492:
#line 2264 "cfg.y"
    {mk_action2( (yyval.action), RETURN_T,
																SCRIPTVAR_ST, 
																0,
																(void*)(yyvsp[(3) - (4)].specval),
																0);
												;}
    break;

  case 493:
#line 2270 "cfg.y"
    {mk_action2( (yyval.action), RETURN_T,
																NUMBER_ST, 
																0,
																(void*)1,
																0);
												;}
    break;

  case 494:
#line 2276 "cfg.y"
    {mk_action2( (yyval.action), RETURN_T,
																NUMBER_ST, 
																0,
																(void*)1,
																0);
												;}
    break;

  case 495:
#line 2282 "cfg.y"
    {mk_action2( (yyval.action), LOG_T, NUMBER_ST, 
													STRING_ST,(void*)4,(yyvsp[(3) - (4)].strval));
									;}
    break;

  case 496:
#line 2285 "cfg.y"
    {mk_action2( (yyval.action), LOG_T,
																NUMBER_ST, 
																STRING_ST,
																(void*)(yyvsp[(3) - (6)].intval),
																(yyvsp[(5) - (6)].strval));
												;}
    break;

  case 497:
#line 2291 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 498:
#line 2292 "cfg.y"
    { (yyval.action)=0; yyerror("bad log"
									"argument"); ;}
    break;

  case 499:
#line 2294 "cfg.y"
    {mk_action2((yyval.action), SET_DEBUG_T, NUMBER_ST,
									0, (void *)(yyvsp[(3) - (4)].intval), 0 ); ;}
    break;

  case 500:
#line 2296 "cfg.y"
    {mk_action2( (yyval.action), SET_DEBUG_T, 0, 0, 0, 0 ); ;}
    break;

  case 501:
#line 2297 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 502:
#line 2298 "cfg.y"
    {mk_action2((yyval.action), SETFLAG_T, NUMBER_ST, 0,
													(void *)(yyvsp[(3) - (4)].intval), 0 ); ;}
    break;

  case 503:
#line 2300 "cfg.y"
    {mk_action2((yyval.action), SETFLAG_T, STR_ST, 0,
													(void *)(yyvsp[(3) - (4)].strval), 0 ); ;}
    break;

  case 504:
#line 2302 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 505:
#line 2303 "cfg.y"
    {mk_action2( (yyval.action), RESETFLAG_T,
										NUMBER_ST, 0, (void *)(yyvsp[(3) - (4)].intval), 0 ); ;}
    break;

  case 506:
#line 2305 "cfg.y"
    {mk_action2( (yyval.action), RESETFLAG_T,
										STR_ST, 0, (void *)(yyvsp[(3) - (4)].strval), 0 ); ;}
    break;

  case 507:
#line 2307 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 508:
#line 2308 "cfg.y"
    {mk_action2( (yyval.action), ISFLAGSET_T,
										NUMBER_ST, 0, (void *)(yyvsp[(3) - (4)].intval), 0 ); ;}
    break;

  case 509:
#line 2310 "cfg.y"
    {mk_action2( (yyval.action), ISFLAGSET_T,
										STR_ST, 0, (void *)(yyvsp[(3) - (4)].strval), 0 ); ;}
    break;

  case 510:
#line 2312 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 511:
#line 2313 "cfg.y"
    {mk_action2( (yyval.action), SETSFLAG_T, NUMBER_ST,
										0, (void *)(yyvsp[(3) - (4)].intval), 0 ); ;}
    break;

  case 512:
#line 2315 "cfg.y"
    {mk_action2( (yyval.action), SETSFLAG_T, STR_ST,
										0, (void *)(yyvsp[(3) - (4)].strval), 0 ); ;}
    break;

  case 513:
#line 2317 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 514:
#line 2318 "cfg.y"
    {mk_action2( (yyval.action), RESETSFLAG_T,
										NUMBER_ST, 0, (void *)(yyvsp[(3) - (4)].intval), 0 ); ;}
    break;

  case 515:
#line 2320 "cfg.y"
    {mk_action2( (yyval.action), RESETSFLAG_T,
										STR_ST, 0, (void *)(yyvsp[(3) - (4)].strval), 0 ); ;}
    break;

  case 516:
#line 2322 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 517:
#line 2323 "cfg.y"
    {mk_action2( (yyval.action), ISSFLAGSET_T,
										NUMBER_ST, 0, (void *)(yyvsp[(3) - (4)].intval), 0 ); ;}
    break;

  case 518:
#line 2325 "cfg.y"
    {mk_action2( (yyval.action), ISSFLAGSET_T,
										STR_ST, 0, (void *)(yyvsp[(3) - (4)].strval), 0 ); ;}
    break;

  case 519:
#line 2327 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 520:
#line 2328 "cfg.y"
    {mk_action2( (yyval.action),
													SETBFLAG_T,
													NUMBER_ST, NUMBER_ST,
													(void *)(yyvsp[(3) - (6)].intval), (void *)(yyvsp[(5) - (6)].intval) ); ;}
    break;

  case 521:
#line 2332 "cfg.y"
    {mk_action2( (yyval.action),
													SETBFLAG_T,
													NUMBER_ST, STR_ST,
													(void *)(yyvsp[(3) - (6)].intval), (void *)(yyvsp[(5) - (6)].strval) ); ;}
    break;

  case 522:
#line 2336 "cfg.y"
    {mk_action2( (yyval.action), SETBFLAG_T,
													NUMBER_ST, NUMBER_ST,
													0, (void *)(yyvsp[(3) - (4)].intval) ); ;}
    break;

  case 523:
#line 2339 "cfg.y"
    {mk_action2( (yyval.action), SETBFLAG_T,
													NUMBER_ST, STR_ST,
													0, (void *)(yyvsp[(3) - (4)].strval) ); ;}
    break;

  case 524:
#line 2342 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 525:
#line 2343 "cfg.y"
    {mk_action2( (yyval.action), 
													RESETBFLAG_T,
													NUMBER_ST, NUMBER_ST,
													(void *)(yyvsp[(3) - (6)].intval), (void *)(yyvsp[(5) - (6)].intval) ); ;}
    break;

  case 526:
#line 2347 "cfg.y"
    {mk_action2( (yyval.action), 
													RESETBFLAG_T,
													NUMBER_ST, STR_ST,
													(void *)(yyvsp[(3) - (6)].intval), (void *)(yyvsp[(5) - (6)].strval) ); ;}
    break;

  case 527:
#line 2351 "cfg.y"
    {mk_action2( (yyval.action), 
													RESETBFLAG_T,
													NUMBER_ST, NUMBER_ST,
													0, (void *)(yyvsp[(3) - (4)].intval) ); ;}
    break;

  case 528:
#line 2355 "cfg.y"
    {mk_action2( (yyval.action), 
													RESETBFLAG_T,
													NUMBER_ST, STR_ST,
													0, (void *)(yyvsp[(3) - (4)].strval) ); ;}
    break;

  case 529:
#line 2359 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 530:
#line 2360 "cfg.y"
    {mk_action2( (yyval.action), 
													ISBFLAGSET_T,
													NUMBER_ST, NUMBER_ST,
													(void *)(yyvsp[(3) - (6)].intval), (void *)(yyvsp[(5) - (6)].intval) ); ;}
    break;

  case 531:
#line 2364 "cfg.y"
    {mk_action2( (yyval.action), 
													ISBFLAGSET_T,
													NUMBER_ST, STR_ST,
													(void *)(yyvsp[(3) - (6)].intval), (void *)(yyvsp[(5) - (6)].strval) ); ;}
    break;

  case 532:
#line 2368 "cfg.y"
    {mk_action2( (yyval.action), 
													ISBFLAGSET_T,
													NUMBER_ST, NUMBER_ST,
													0, (void *)(yyvsp[(3) - (4)].intval) ); ;}
    break;

  case 533:
#line 2372 "cfg.y"
    {mk_action2( (yyval.action), 
													ISBFLAGSET_T,
													NUMBER_ST, STR_ST,
													0, (void *)(yyvsp[(3) - (4)].strval) ); ;}
    break;

  case 534:
#line 2376 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); ;}
    break;

  case 535:
#line 2377 "cfg.y"
    {mk_action2( (yyval.action), ERROR_T,
																STRING_ST, 
																STRING_ST,
																(yyvsp[(3) - (6)].strval),
																(yyvsp[(5) - (6)].strval));
												  ;}
    break;

  case 536:
#line 2383 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 537:
#line 2384 "cfg.y"
    { (yyval.action)=0; yyerror("bad error"
														"argument"); ;}
    break;

  case 538:
#line 2386 "cfg.y"
    { 
						i_tmp = get_script_route_idx( (yyvsp[(3) - (4)].strval), rlist, RT_NO, 0);
						if (i_tmp==-1) yyerror("too many script routes");
						mk_action2( (yyval.action), ROUTE_T, NUMBER_ST,
							0, (void*)(long)i_tmp, 0);
					;}
    break;

  case 539:
#line 2393 "cfg.y"
    { 
						i_tmp = get_script_route_idx( (yyvsp[(3) - (6)].strval), rlist, RT_NO, 0);
						if (i_tmp==-1) yyerror("too many script routes");
						if ((yyvsp[(5) - (6)].intval) <= 0) yyerror("too many route parameters");

						/* duplicate the list */
						a_tmp = pkg_malloc((yyvsp[(5) - (6)].intval) * sizeof(action_elem_t));
						if (!a_tmp) yyerror("no more pkg memory");
						memcpy(a_tmp, route_elems, (yyvsp[(5) - (6)].intval)*sizeof(action_elem_t));

						mk_action3( (yyval.action), ROUTE_T, NUMBER_ST,	/* route idx */
							NUMBER_ST,						/* number of params */
							SCRIPTVAR_ELEM_ST,				/* parameters */
							(void*)(long)i_tmp,
							(void*)(long)(yyvsp[(5) - (6)].intval),
							(void*)a_tmp);
					;}
    break;

  case 540:
#line 2411 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 541:
#line 2412 "cfg.y"
    { (yyval.action)=0; yyerror("bad route"
						"argument"); ;}
    break;

  case 542:
#line 2414 "cfg.y"
    { mk_action2( (yyval.action), SET_HOST_T, STR_ST,
														0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 543:
#line 2416 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 544:
#line 2417 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"string expected"); ;}
    break;

  case 545:
#line 2420 "cfg.y"
    { mk_action2( (yyval.action), PREFIX_T, STR_ST,
														0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 546:
#line 2422 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 547:
#line 2423 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"string expected"); ;}
    break;

  case 548:
#line 2425 "cfg.y"
    { mk_action2( (yyval.action), STRIP_TAIL_T, 
									NUMBER_ST, 0, (void *) (yyvsp[(3) - (4)].intval), 0); ;}
    break;

  case 549:
#line 2427 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 550:
#line 2428 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"number expected"); ;}
    break;

  case 551:
#line 2431 "cfg.y"
    { mk_action2( (yyval.action), STRIP_T, NUMBER_ST,
														0, (void *) (yyvsp[(3) - (4)].intval), 0); ;}
    break;

  case 552:
#line 2433 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 553:
#line 2434 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"number expected"); ;}
    break;

  case 554:
#line 2436 "cfg.y"
    { 
				{   qvalue_t q;
				if (str2q(&q, (yyvsp[(5) - (6)].strval), strlen((yyvsp[(5) - (6)].strval))) < 0) {
					yyerror("bad argument, q value expected");
				}
				mk_action2( (yyval.action), APPEND_BRANCH_T, STR_ST, NUMBER_ST, (yyvsp[(3) - (6)].strval),
						(void *)(long)q); } 
		;}
    break;

  case 555:
#line 2444 "cfg.y"
    { mk_action2( (yyval.action), APPEND_BRANCH_T,
						STR_ST, NUMBER_ST, (yyvsp[(3) - (4)].strval), (void *)Q_UNSPECIFIED) ; ;}
    break;

  case 556:
#line 2446 "cfg.y"
    { mk_action2( (yyval.action), APPEND_BRANCH_T,
						STR_ST, NUMBER_ST, 0, (void *)Q_UNSPECIFIED) ; ;}
    break;

  case 557:
#line 2448 "cfg.y"
    { mk_action2( (yyval.action), APPEND_BRANCH_T,
						STR_ST, NUMBER_ST, 0, (void *)Q_UNSPECIFIED ) ; ;}
    break;

  case 558:
#line 2450 "cfg.y"
    {
						mk_action1((yyval.action), REMOVE_BRANCH_T, NUMBER_ST, (void*)(yyvsp[(3) - (4)].intval));;}
    break;

  case 559:
#line 2452 "cfg.y"
    {
						mk_action1( (yyval.action), REMOVE_BRANCH_T, SCRIPTVAR_ST, (yyvsp[(3) - (4)].specval));;}
    break;

  case 560:
#line 2455 "cfg.y"
    {
				spec = (pv_spec_t*)pkg_malloc(sizeof(pv_spec_t));
				memset(spec, 0, sizeof(pv_spec_t));
				tstr.s = (yyvsp[(3) - (6)].strval);
				tstr.len = strlen(tstr.s);
				if(pv_parse_spec(&tstr, spec)==NULL)
				{
					yyerror("unknown script variable in first parameter");
				}
				if(!pv_is_w(spec))
					yyerror("read-only script variable in first parameter");

				pvmodel = 0;
				tstr.s = (yyvsp[(5) - (6)].strval);
				tstr.len = strlen(tstr.s);
				if(pv_parse_format(&tstr, &pvmodel)<0)
				{
					yyerror("error in second parameter");
				}

				mk_action2( (yyval.action), PV_PRINTF_T,
						SCRIPTVAR_ST, SCRIPTVAR_ELEM_ST, spec, pvmodel) ;
			;}
    break;

  case 561:
#line 2478 "cfg.y"
    {
				if(!pv_is_w((yyvsp[(3) - (6)].specval)))
					yyerror("read-only script variable in first parameter");
				pvmodel = 0;
				tstr.s = (yyvsp[(5) - (6)].strval);
				tstr.len = strlen(tstr.s);
				if(pv_parse_format(&tstr, &pvmodel)<0)
				{
					yyerror("error in second parameter");
				}

				mk_action2( (yyval.action), PV_PRINTF_T,
						SCRIPTVAR_ST, SCRIPTVAR_ELEM_ST, (yyvsp[(3) - (6)].specval), pvmodel) ;
			;}
    break;

  case 562:
#line 2493 "cfg.y"
    { mk_action2( (yyval.action), SET_HOSTPORT_T, 
														STR_ST, 0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 563:
#line 2495 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 564:
#line 2496 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument,"
												" string expected"); ;}
    break;

  case 565:
#line 2498 "cfg.y"
    { mk_action2( (yyval.action), SET_PORT_T, STR_ST,
														0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 566:
#line 2500 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 567:
#line 2501 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"string expected"); ;}
    break;

  case 568:
#line 2503 "cfg.y"
    { mk_action2( (yyval.action), SET_USER_T,
														STR_ST, 0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 569:
#line 2505 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 570:
#line 2506 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"string expected"); ;}
    break;

  case 571:
#line 2508 "cfg.y"
    { mk_action2( (yyval.action), SET_USERPASS_T, 
														STR_ST, 0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 572:
#line 2510 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 573:
#line 2511 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"string expected"); ;}
    break;

  case 574:
#line 2513 "cfg.y"
    { mk_action2( (yyval.action), SET_URI_T, STR_ST, 
														0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 575:
#line 2515 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 576:
#line 2516 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
										"string expected"); ;}
    break;

  case 577:
#line 2518 "cfg.y"
    { mk_action2( (yyval.action), REVERT_URI_T, 0,0,0,0); ;}
    break;

  case 578:
#line 2519 "cfg.y"
    { mk_action2( (yyval.action), REVERT_URI_T, 0,0,0,0); ;}
    break;

  case 579:
#line 2520 "cfg.y"
    { mk_action2( (yyval.action), SET_DSTURI_T,
													STR_ST, 0, (yyvsp[(3) - (4)].strval), 0); ;}
    break;

  case 580:
#line 2522 "cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 581:
#line 2523 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
										"string expected"); ;}
    break;

  case 582:
#line 2525 "cfg.y"
    { mk_action2( (yyval.action), RESET_DSTURI_T,
															0,0,0,0); ;}
    break;

  case 583:
#line 2527 "cfg.y"
    { mk_action2( (yyval.action), RESET_DSTURI_T, 0,0,0,0); ;}
    break;

  case 584:
#line 2528 "cfg.y"
    { mk_action2( (yyval.action), ISDSTURISET_T, 0,0,0,0); ;}
    break;

  case 585:
#line 2529 "cfg.y"
    { mk_action2( (yyval.action), ISDSTURISET_T, 0,0,0,0); ;}
    break;

  case 586:
#line 2530 "cfg.y"
    { mk_action2( (yyval.action), FORCE_RPORT_T,
															0, 0, 0, 0); ;}
    break;

  case 587:
#line 2532 "cfg.y"
    { mk_action2( (yyval.action), FORCE_RPORT_T,0, 0, 0, 0); ;}
    break;

  case 588:
#line 2533 "cfg.y"
    {
					mk_action2( (yyval.action), FORCE_LOCAL_RPORT_T,0, 0, 0, 0); ;}
    break;

  case 589:
#line 2535 "cfg.y"
    {
					mk_action2( (yyval.action), FORCE_LOCAL_RPORT_T,0, 0, 0, 0); ;}
    break;

  case 590:
#line 2537 "cfg.y"
    {
					#ifdef USE_TCP
						mk_action2( (yyval.action), FORCE_TCP_ALIAS_T,NUMBER_ST, 0,
										(void*)(yyvsp[(3) - (4)].intval), 0);
					#else
						yyerror("tcp support not compiled in");
					#endif
												;}
    break;

  case 591:
#line 2545 "cfg.y"
    {
					#ifdef USE_TCP
						mk_action2( (yyval.action), FORCE_TCP_ALIAS_T,0, 0, 0, 0); 
					#else
						yyerror("tcp support not compiled in");
					#endif
										;}
    break;

  case 592:
#line 2552 "cfg.y"
    {
					#ifdef USE_TCP
						mk_action2( (yyval.action), FORCE_TCP_ALIAS_T,0, 0, 0, 0);
					#else
						yyerror("tcp support not compiled in");
					#endif
										;}
    break;

  case 593:
#line 2559 "cfg.y"
    {(yyval.action)=0; 
					yyerror("bad argument, number expected");
					;}
    break;

  case 594:
#line 2562 "cfg.y"
    {
								mk_action2( (yyval.action), SET_ADV_ADDR_T, STR_ST,
											0, (yyvsp[(3) - (4)].strval), 0);
								;}
    break;

  case 595:
#line 2566 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
														"string expected"); ;}
    break;

  case 596:
#line 2568 "cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 597:
#line 2569 "cfg.y"
    {
								(yyval.action)=0;
								tmp=int2str((yyvsp[(3) - (4)].intval), &i_tmp);
								if ((str_tmp=pkg_malloc(sizeof(str)))==0){
										LM_CRIT("cfg. parser: out of memory.\n");
								}else{
									if ((str_tmp->s=pkg_malloc(i_tmp))==0){
										LM_CRIT("cfg. parser: out of memory.\n");
									}else{
										memcpy(str_tmp->s, tmp, i_tmp);
										str_tmp->len=i_tmp;
										mk_action2( (yyval.action), SET_ADV_PORT_T, STR_ST,
													0, str_tmp, 0);
									}
								}
								            ;}
    break;

  case 598:
#line 2585 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument, "
								"string expected"); ;}
    break;

  case 599:
#line 2587 "cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 600:
#line 2588 "cfg.y"
    {
								mk_action2( (yyval.action), FORCE_SEND_SOCKET_T,
									SOCKID_ST, 0, (yyvsp[(3) - (4)].sockid), 0);
								;}
    break;

  case 601:
#line 2592 "cfg.y"
    { (yyval.action)=0; yyerror("bad argument,"
								" [proto:]host[:port] expected");
								;}
    break;

  case 602:
#line 2595 "cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 603:
#line 2596 "cfg.y"
    {
								mk_action2( (yyval.action), SERIALIZE_BRANCHES_T,
									NUMBER_ST, 0, (void*)(long)(yyvsp[(3) - (4)].intval), 0);
								;}
    break;

  case 604:
#line 2600 "cfg.y"
    {(yyval.action)=0; yyerror("bad argument,"
								" number expected");
								;}
    break;

  case 605:
#line 2603 "cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 606:
#line 2604 "cfg.y"
    {
								mk_action2( (yyval.action), NEXT_BRANCHES_T, 0, 0, 0, 0);
								;}
    break;

  case 607:
#line 2607 "cfg.y"
    {(yyval.action)=0; yyerror("no argument is"
								" expected");
								;}
    break;

  case 608:
#line 2610 "cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 609:
#line 2611 "cfg.y"
    {
								mk_action2( (yyval.action), USE_BLACKLIST_T,
									STRING_ST, 0, (yyvsp[(3) - (4)].strval), 0);
								;}
    break;

  case 610:
#line 2615 "cfg.y"
    {(yyval.action)=0; yyerror("bad argument,"
								" string expected");
								;}
    break;

  case 611:
#line 2618 "cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 612:
#line 2619 "cfg.y"
    {
								mk_action2( (yyval.action), UNUSE_BLACKLIST_T,
									STRING_ST, 0, (yyvsp[(3) - (4)].strval), 0);
								;}
    break;

  case 613:
#line 2623 "cfg.y"
    {(yyval.action)=0; yyerror("bad argument,"
								" string expected");
								;}
    break;

  case 614:
#line 2626 "cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); ;}
    break;

  case 615:
#line 2627 "cfg.y"
    { 
									mk_action3( (yyval.action), CACHE_STORE_T,
													STR_ST,
													STR_ST,
													STR_ST,
													(yyvsp[(3) - (8)].strval),
													(yyvsp[(5) - (8)].strval),
													(yyvsp[(7) - (8)].strval));
							;}
    break;

  case 616:
#line 2637 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (10)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (10)].strval); 
								elems[2].type = STR_ST; 
								elems[2].u.data = (yyvsp[(7) - (10)].strval); 
								elems[3].type = NUMBER_ST; 
								elems[3].u.number = (yyvsp[(9) - (10)].intval);
								(yyval.action) = mk_action(CACHE_STORE_T, 4, elems, line); 
							;}
    break;

  case 617:
#line 2649 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (10)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (10)].strval); 
								elems[2].type = STR_ST; 
								elems[2].u.data = (yyvsp[(7) - (10)].strval); 
								elems[3].type = SCRIPTVAR_ST; 
								elems[3].u.data = (yyvsp[(9) - (10)].specval);
								(yyval.action) = mk_action(CACHE_STORE_T, 4, elems, line); 
							;}
    break;

  case 618:
#line 2661 "cfg.y"
    { 
									mk_action2( (yyval.action), CACHE_REMOVE_T,
													STR_ST,
													STR_ST,
													(yyvsp[(3) - (6)].strval),
													(yyvsp[(5) - (6)].strval));
							;}
    break;

  case 619:
#line 2668 "cfg.y"
    { 
									mk_action3( (yyval.action), CACHE_FETCH_T,
													STR_ST,
													STR_ST,
													SCRIPTVAR_ST,
													(yyvsp[(3) - (8)].strval),
													(yyvsp[(5) - (8)].strval),
													(yyvsp[(7) - (8)].specval));
							;}
    break;

  case 620:
#line 2677 "cfg.y"
    { 
									mk_action3( (yyval.action), CACHE_COUNTER_FETCH_T,
													STR_ST,
													STR_ST,
													SCRIPTVAR_ST,
													(yyvsp[(3) - (8)].strval),
													(yyvsp[(5) - (8)].strval),
													(yyvsp[(7) - (8)].specval));
							;}
    break;

  case 621:
#line 2686 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (10)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (10)].strval); 
								elems[2].type = NUMBER_ST; 
								elems[2].u.number = (yyvsp[(7) - (10)].intval);
								elems[3].type = NUMBER_ST;
								elems[3].u.number = (yyvsp[(9) - (10)].intval);
								(yyval.action) = mk_action(CACHE_ADD_T, 4, elems, line); 
							;}
    break;

  case 622:
#line 2697 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (10)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (10)].strval); 
								elems[2].type = SCRIPTVAR_ST; 
								elems[2].u.data = (yyvsp[(7) - (10)].specval);
								elems[3].type = NUMBER_ST;
								elems[3].u.number = (yyvsp[(9) - (10)].intval);
								(yyval.action) = mk_action(CACHE_ADD_T, 4, elems, line); 
							;}
    break;

  case 623:
#line 2708 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (10)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (10)].strval); 
								elems[2].type = NUMBER_ST; 
								elems[2].u.number = (yyvsp[(7) - (10)].intval);
								elems[3].type = NUMBER_ST;
								elems[3].u.number = (yyvsp[(9) - (10)].intval);
								(yyval.action) = mk_action(CACHE_SUB_T, 4, elems, line); 
							;}
    break;

  case 624:
#line 2719 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (10)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (10)].strval); 
								elems[2].type = SCRIPTVAR_ST; 
								elems[2].u.data = (yyvsp[(7) - (10)].specval);
								elems[3].type = NUMBER_ST;
								elems[3].u.number = (yyvsp[(9) - (10)].intval);
								(yyval.action) = mk_action(CACHE_SUB_T, 4, elems, line); 
							;}
    break;

  case 625:
#line 2730 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (8)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (8)].strval); 
								elems[2].type = STR_ST; 
								elems[2].u.data = (yyvsp[(7) - (8)].strval);
								(yyval.action) = mk_action(CACHE_RAW_QUERY_T, 3, elems, line); 
							;}
    break;

  case 626:
#line 2739 "cfg.y"
    { 
								elems[0].type = STR_ST; 
								elems[0].u.data = (yyvsp[(3) - (6)].strval); 
								elems[1].type = STR_ST; 
								elems[1].u.data = (yyvsp[(5) - (6)].strval); 
								(yyval.action) = mk_action(CACHE_RAW_QUERY_T, 2, elems, line); 
							;}
    break;

  case 627:
#line 2746 "cfg.y"
    {
						 			cmd_tmp=(void*)find_cmd_export_t((yyvsp[(1) - (3)].strval), 0, rt);
									if (cmd_tmp==0){
										if (find_cmd_export_t((yyvsp[(1) - (3)].strval), 0, 0)) {
											yyerror("Command cannot be "
												"used in the block\n");
										} else {
											yyerrorf("unknown command <%s>, "
												"missing loadmodule?", (yyvsp[(1) - (3)].strval));
										}
										(yyval.action)=0;
									}else{
										elems[0].type = CMD_ST;
										elems[0].u.data = cmd_tmp;
										(yyval.action) = mk_action(MODULE_T, 1, elems, line);
									}
								;}
    break;

  case 628:
#line 2763 "cfg.y"
    {
									cmd_tmp=(void*)find_cmd_export_t((yyvsp[(1) - (4)].strval), (yyvsp[(3) - (4)].intval), rt);
									if (cmd_tmp==0){
										if (find_cmd_export_t((yyvsp[(1) - (4)].strval), (yyvsp[(3) - (4)].intval), 0)) {
											yyerror("Command cannot be "
												"used in the block\n");
										} else {
											yyerrorf("unknown command <%s>, "
												"missing loadmodule?", (yyvsp[(1) - (4)].strval));
										}
										(yyval.action)=0;
									}else{
										elems[0].type = CMD_ST;
										elems[0].u.data = cmd_tmp;
										(yyval.action) = mk_action(MODULE_T, (yyvsp[(3) - (4)].intval)+1, elems, line);
									}
								;}
    break;

  case 629:
#line 2780 "cfg.y"
    { (yyval.action)=0; yyerrorf("bad arguments for "
												"command <%s>", (yyvsp[(1) - (4)].strval)); ;}
    break;

  case 630:
#line 2782 "cfg.y"
    { (yyval.action)=0; yyerrorf("bare word <%s> found, command calls need '()'", (yyvsp[(1) - (2)].strval)); ;}
    break;

  case 631:
#line 2784 "cfg.y"
    {
				mk_action1((yyval.action), XDBG_T, STR_ST, (yyvsp[(3) - (4)].strval));	;}
    break;

  case 632:
#line 2786 "cfg.y"
    {
				mk_action1((yyval.action), XLOG_T, STR_ST, (yyvsp[(3) - (4)].strval)); ;}
    break;

  case 633:
#line 2788 "cfg.y"
    {
				mk_action2((yyval.action), XLOG_T, STR_ST, STR_ST, (yyvsp[(3) - (6)].strval), (yyvsp[(5) - (6)].strval)); ;}
    break;

  case 634:
#line 2790 "cfg.y"
    {
				mk_action1((yyval.action), RAISE_EVENT_T, STR_ST, (yyvsp[(3) - (4)].strval)); ;}
    break;

  case 635:
#line 2792 "cfg.y"
    {
				mk_action2((yyval.action), RAISE_EVENT_T, STR_ST, SCRIPTVAR_ST, (yyvsp[(3) - (6)].strval), (yyvsp[(5) - (6)].specval)); ;}
    break;

  case 636:
#line 2794 "cfg.y"
    {
				mk_action3((yyval.action), RAISE_EVENT_T, STR_ST, SCRIPTVAR_ST, SCRIPTVAR_ST, (yyvsp[(3) - (8)].strval), (yyvsp[(5) - (8)].specval), (yyvsp[(7) - (8)].specval)); ;}
    break;

  case 637:
#line 2796 "cfg.y"
    {
				mk_action2((yyval.action), SUBSCRIBE_EVENT_T, STR_ST, STR_ST, (yyvsp[(3) - (6)].strval), (yyvsp[(5) - (6)].strval)); ;}
    break;

  case 638:
#line 2798 "cfg.y"
    {
				mk_action3((yyval.action), SUBSCRIBE_EVENT_T, STR_ST, STR_ST, NUMBER_ST, (yyvsp[(3) - (8)].strval), (yyvsp[(5) - (8)].strval), (void*)(long)(yyvsp[(7) - (8)].intval)); ;}
    break;

  case 639:
#line 2800 "cfg.y"
    {
				elems[0].type = STR_ST; 
				elems[0].u.data = (yyvsp[(3) - (14)].strval); 
				elems[1].type = STR_ST; 
				elems[1].u.data = (yyvsp[(5) - (14)].strval); 
				elems[2].type = STR_ST; 
				elems[2].u.data = (yyvsp[(7) - (14)].strval); 
				elems[3].type = STR_ST; 
				elems[3].u.data = (yyvsp[(9) - (14)].strval);
				elems[4].type = STR_ST; 
				elems[4].u.data = (yyvsp[(11) - (14)].strval);
				elems[5].type = SCRIPTVAR_ST; 
				elems[5].u.data = (yyvsp[(13) - (14)].specval);
				(yyval.action) = mk_action(CONSTRUCT_URI_T,6,elems,line); ;}
    break;

  case 640:
#line 2814 "cfg.y"
    {
				elems[0].type = SCRIPTVAR_ST;
				elems[0].u.data = (yyvsp[(3) - (6)].specval);
				elems[1].type = SCRIPTVAR_ST;
				elems[1].u.data = (yyvsp[(5) - (6)].specval); 
				(yyval.action) = mk_action(GET_TIMESTAMP_T,2,elems,line); ;}
    break;

  case 641:
#line 2820 "cfg.y"
    {
				mk_action2((yyval.action), SCRIPT_TRACE_T, 0, 0, 0, 0); ;}
    break;

  case 642:
#line 2822 "cfg.y"
    {
				pvmodel = 0;
				tstr.s = (yyvsp[(5) - (6)].strval);
				tstr.len = strlen(tstr.s);
				if(pv_parse_format(&tstr, &pvmodel)<0)
					yyerror("error in second parameter");
				mk_action2((yyval.action), SCRIPT_TRACE_T, NUMBER_ST,
						   SCRIPTVAR_ELEM_ST, (void *)(yyvsp[(3) - (6)].intval), pvmodel); ;}
    break;

  case 643:
#line 2830 "cfg.y"
    {
				pvmodel = 0;
				tstr.s = (yyvsp[(5) - (8)].strval);
				tstr.len = strlen(tstr.s);
				if(pv_parse_format(&tstr, &pvmodel)<0)
					yyerror("error in second parameter");
				mk_action3((yyval.action), SCRIPT_TRACE_T, NUMBER_ST,
						   SCRIPTVAR_ELEM_ST, STR_ST, (void *)(yyvsp[(3) - (8)].intval), pvmodel, (yyvsp[(7) - (8)].strval)); ;}
    break;


/* Line 1267 of yacc.c.  */
#line 8659 "cfg.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 2842 "cfg.y"


extern int column;
extern int startcolumn;
extern char *finame;

#define get_cfg_file_name \
	((finame) ? finame : cfg_file ? cfg_file : "default")

static inline void warn(char* s)
{
	LM_WARN("warning in config file %s, line %d, column %d-%d: %s\n",
			get_cfg_file_name, line, startcolumn, column, s);
}

static void yyerror(char* s)
{
	LM_CRIT("parse error in config file %s, line %d, column %d-%d: %s\n",
			get_cfg_file_name, line, startcolumn, column, s);
	cfg_errors++;
}

#define ERROR_MAXLEN 1024
static void yyerrorf(char *fmt, ...)
{
	char *tmp = pkg_malloc(ERROR_MAXLEN);
	va_list ap;
	va_start(ap, fmt);

	vsnprintf(tmp, ERROR_MAXLEN, fmt, ap);
	yyerror(tmp);

	pkg_free(tmp);
	va_end(ap);
}


static struct socket_id* mk_listen_id(char* host, int proto, int port)
{
	struct socket_id* l;
	l=pkg_malloc(sizeof(struct socket_id));
	if (l==0){
		LM_CRIT("cfg. parser: out of memory.\n");
	}else{
		l->name=host;
		l->port=port;
		l->proto=proto;
		l->adv_name=NULL;
		l->adv_port=0;
		l->next=0;
	}
	return l;
}

static struct socket_id* set_listen_id_adv(struct socket_id* sock,
											char *adv_name,
											int adv_port)
{
	sock->adv_name=adv_name;
	sock->adv_port=adv_port;
	return sock;
}

