/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     FORWARD = 258,
     SEND = 259,
     DROP = 260,
     EXIT = 261,
     RETURN = 262,
     LOG_TOK = 263,
     ERROR = 264,
     ROUTE = 265,
     ROUTE_FAILURE = 266,
     ROUTE_ONREPLY = 267,
     ROUTE_BRANCH = 268,
     ROUTE_ERROR = 269,
     ROUTE_LOCAL = 270,
     ROUTE_STARTUP = 271,
     ROUTE_TIMER = 272,
     ROUTE_EVENT = 273,
     SET_HOST = 274,
     SET_HOSTPORT = 275,
     PREFIX = 276,
     STRIP = 277,
     STRIP_TAIL = 278,
     APPEND_BRANCH = 279,
     REMOVE_BRANCH = 280,
     PV_PRINTF = 281,
     SET_USER = 282,
     SET_USERPASS = 283,
     SET_PORT = 284,
     SET_URI = 285,
     REVERT_URI = 286,
     SET_DSTURI = 287,
     RESET_DSTURI = 288,
     ISDSTURISET = 289,
     FORCE_RPORT = 290,
     FORCE_LOCAL_RPORT = 291,
     FORCE_TCP_ALIAS = 292,
     IF = 293,
     ELSE = 294,
     SWITCH = 295,
     CASE = 296,
     DEFAULT = 297,
     SBREAK = 298,
     WHILE = 299,
     SET_ADV_ADDRESS = 300,
     SET_ADV_PORT = 301,
     FORCE_SEND_SOCKET = 302,
     SERIALIZE_BRANCHES = 303,
     NEXT_BRANCHES = 304,
     USE_BLACKLIST = 305,
     UNUSE_BLACKLIST = 306,
     MAX_LEN = 307,
     SETDEBUG = 308,
     SETFLAG = 309,
     RESETFLAG = 310,
     ISFLAGSET = 311,
     SETBFLAG = 312,
     RESETBFLAG = 313,
     ISBFLAGSET = 314,
     SETSFLAG = 315,
     RESETSFLAG = 316,
     ISSFLAGSET = 317,
     METHOD = 318,
     URI = 319,
     FROM_URI = 320,
     TO_URI = 321,
     SRCIP = 322,
     SRCPORT = 323,
     DSTIP = 324,
     DSTPORT = 325,
     PROTO = 326,
     AF = 327,
     MYSELF = 328,
     MSGLEN = 329,
     UDP = 330,
     TCP = 331,
     TLS = 332,
     SCTP = 333,
     NULLV = 334,
     CACHE_STORE = 335,
     CACHE_FETCH = 336,
     CACHE_COUNTER_FETCH = 337,
     CACHE_REMOVE = 338,
     CACHE_ADD = 339,
     CACHE_SUB = 340,
     CACHE_RAW_QUERY = 341,
     XDBG = 342,
     XLOG = 343,
     XLOG_BUF_SIZE = 344,
     XLOG_FORCE_COLOR = 345,
     RAISE_EVENT = 346,
     SUBSCRIBE_EVENT = 347,
     CONSTRUCT_URI = 348,
     GET_TIMESTAMP = 349,
     SCRIPT_TRACE = 350,
     DEBUG = 351,
     FORK = 352,
     LOGSTDERROR = 353,
     LOGFACILITY = 354,
     LOGNAME = 355,
     AVP_ALIASES = 356,
     LISTEN = 357,
     ALIAS = 358,
     AUTO_ALIASES = 359,
     DNS = 360,
     REV_DNS = 361,
     DNS_TRY_IPV6 = 362,
     DNS_RETR_TIME = 363,
     DNS_RETR_NO = 364,
     DNS_SERVERS_NO = 365,
     DNS_USE_SEARCH = 366,
     MAX_WHILE_LOOPS = 367,
     PORT = 368,
     CHILDREN = 369,
     CHECK_VIA = 370,
     MEMLOG = 371,
     MEMDUMP = 372,
     EXECMSGTHRESHOLD = 373,
     EXECDNSTHRESHOLD = 374,
     TCPTHRESHOLD = 375,
     EVENT_SHM_THRESHOLD = 376,
     EVENT_PKG_THRESHOLD = 377,
     QUERYBUFFERSIZE = 378,
     QUERYFLUSHTIME = 379,
     SIP_WARNING = 380,
     SOCK_MODE = 381,
     SOCK_USER = 382,
     SOCK_GROUP = 383,
     UNIX_SOCK = 384,
     UNIX_SOCK_CHILDREN = 385,
     UNIX_TX_TIMEOUT = 386,
     SERVER_SIGNATURE = 387,
     SERVER_HEADER = 388,
     USER_AGENT_HEADER = 389,
     LOADMODULE = 390,
     MPATH = 391,
     MODPARAM = 392,
     MAXBUFFER = 393,
     USER = 394,
     GROUP = 395,
     CHROOT = 396,
     WDIR = 397,
     MHOMED = 398,
     DISABLE_TCP = 399,
     TCP_ACCEPT_ALIASES = 400,
     TCP_CHILDREN = 401,
     TCP_CONNECT_TIMEOUT = 402,
     TCP_SEND_TIMEOUT = 403,
     TCP_CON_LIFETIME = 404,
     TCP_LISTEN_BACKLOG = 405,
     TCP_POLL_METHOD = 406,
     TCP_MAX_CONNECTIONS = 407,
     TCP_OPT_CRLF_PINGPONG = 408,
     TCP_NO_NEW_CONN_BFLAG = 409,
     TCP_KEEPALIVE = 410,
     TCP_KEEPCOUNT = 411,
     TCP_KEEPIDLE = 412,
     TCP_KEEPINTERVAL = 413,
     DISABLE_TLS = 414,
     TLSLOG = 415,
     TLS_PORT_NO = 416,
     TLS_METHOD = 417,
     TLS_HANDSHAKE_TIMEOUT = 418,
     TLS_SEND_TIMEOUT = 419,
     TLS_SERVER_DOMAIN = 420,
     TLS_CLIENT_DOMAIN = 421,
     TLS_CLIENT_DOMAIN_AVP = 422,
     SSLv23 = 423,
     SSLv2 = 424,
     SSLv3 = 425,
     TLSv1 = 426,
     TLS_VERIFY_CLIENT = 427,
     TLS_VERIFY_SERVER = 428,
     TLS_REQUIRE_CLIENT_CERTIFICATE = 429,
     TLS_CERTIFICATE = 430,
     TLS_PRIVATE_KEY = 431,
     TLS_CA_LIST = 432,
     TLS_CIPHERS_LIST = 433,
     ADVERTISED_ADDRESS = 434,
     ADVERTISED_PORT = 435,
     DISABLE_CORE = 436,
     OPEN_FD_LIMIT = 437,
     MCAST_LOOPBACK = 438,
     MCAST_TTL = 439,
     TOS = 440,
     DISABLE_DNS_FAILOVER = 441,
     DISABLE_DNS_BLACKLIST = 442,
     DST_BLACKLIST = 443,
     DISABLE_STATELESS_FWD = 444,
     DB_VERSION_TABLE = 445,
     DB_DEFAULT_URL = 446,
     DISABLE_503_TRANSLATION = 447,
     EQUAL = 448,
     EQUAL_T = 449,
     GT = 450,
     LT = 451,
     GTE = 452,
     LTE = 453,
     DIFF = 454,
     MATCH = 455,
     NOTMATCH = 456,
     COLONEQ = 457,
     PLUSEQ = 458,
     MINUSEQ = 459,
     SLASHEQ = 460,
     MULTEQ = 461,
     MODULOEQ = 462,
     BANDEQ = 463,
     BOREQ = 464,
     BXOREQ = 465,
     AND = 466,
     OR = 467,
     BRSHIFT = 468,
     BLSHIFT = 469,
     BXOR = 470,
     BAND = 471,
     BOR = 472,
     MODULO = 473,
     MULT = 474,
     SLASH = 475,
     MINUS = 476,
     PLUS = 477,
     BNOT = 478,
     NOT = 479,
     NUMBER = 480,
     ZERO = 481,
     ID = 482,
     STRING = 483,
     SCRIPTVAR = 484,
     IPV6ADDR = 485,
     COMMA = 486,
     SEMICOLON = 487,
     RPAREN = 488,
     LPAREN = 489,
     LBRACE = 490,
     RBRACE = 491,
     LBRACK = 492,
     RBRACK = 493,
     AS = 494,
     USE_CHILDREN = 495,
     DOT = 496,
     CR = 497,
     COLON = 498,
     ANY = 499,
     SCRIPTVARERR = 500
   };
#endif
/* Tokens.  */
#define FORWARD 258
#define SEND 259
#define DROP 260
#define EXIT 261
#define RETURN 262
#define LOG_TOK 263
#define ERROR 264
#define ROUTE 265
#define ROUTE_FAILURE 266
#define ROUTE_ONREPLY 267
#define ROUTE_BRANCH 268
#define ROUTE_ERROR 269
#define ROUTE_LOCAL 270
#define ROUTE_STARTUP 271
#define ROUTE_TIMER 272
#define ROUTE_EVENT 273
#define SET_HOST 274
#define SET_HOSTPORT 275
#define PREFIX 276
#define STRIP 277
#define STRIP_TAIL 278
#define APPEND_BRANCH 279
#define REMOVE_BRANCH 280
#define PV_PRINTF 281
#define SET_USER 282
#define SET_USERPASS 283
#define SET_PORT 284
#define SET_URI 285
#define REVERT_URI 286
#define SET_DSTURI 287
#define RESET_DSTURI 288
#define ISDSTURISET 289
#define FORCE_RPORT 290
#define FORCE_LOCAL_RPORT 291
#define FORCE_TCP_ALIAS 292
#define IF 293
#define ELSE 294
#define SWITCH 295
#define CASE 296
#define DEFAULT 297
#define SBREAK 298
#define WHILE 299
#define SET_ADV_ADDRESS 300
#define SET_ADV_PORT 301
#define FORCE_SEND_SOCKET 302
#define SERIALIZE_BRANCHES 303
#define NEXT_BRANCHES 304
#define USE_BLACKLIST 305
#define UNUSE_BLACKLIST 306
#define MAX_LEN 307
#define SETDEBUG 308
#define SETFLAG 309
#define RESETFLAG 310
#define ISFLAGSET 311
#define SETBFLAG 312
#define RESETBFLAG 313
#define ISBFLAGSET 314
#define SETSFLAG 315
#define RESETSFLAG 316
#define ISSFLAGSET 317
#define METHOD 318
#define URI 319
#define FROM_URI 320
#define TO_URI 321
#define SRCIP 322
#define SRCPORT 323
#define DSTIP 324
#define DSTPORT 325
#define PROTO 326
#define AF 327
#define MYSELF 328
#define MSGLEN 329
#define UDP 330
#define TCP 331
#define TLS 332
#define SCTP 333
#define NULLV 334
#define CACHE_STORE 335
#define CACHE_FETCH 336
#define CACHE_COUNTER_FETCH 337
#define CACHE_REMOVE 338
#define CACHE_ADD 339
#define CACHE_SUB 340
#define CACHE_RAW_QUERY 341
#define XDBG 342
#define XLOG 343
#define XLOG_BUF_SIZE 344
#define XLOG_FORCE_COLOR 345
#define RAISE_EVENT 346
#define SUBSCRIBE_EVENT 347
#define CONSTRUCT_URI 348
#define GET_TIMESTAMP 349
#define SCRIPT_TRACE 350
#define DEBUG 351
#define FORK 352
#define LOGSTDERROR 353
#define LOGFACILITY 354
#define LOGNAME 355
#define AVP_ALIASES 356
#define LISTEN 357
#define ALIAS 358
#define AUTO_ALIASES 359
#define DNS 360
#define REV_DNS 361
#define DNS_TRY_IPV6 362
#define DNS_RETR_TIME 363
#define DNS_RETR_NO 364
#define DNS_SERVERS_NO 365
#define DNS_USE_SEARCH 366
#define MAX_WHILE_LOOPS 367
#define PORT 368
#define CHILDREN 369
#define CHECK_VIA 370
#define MEMLOG 371
#define MEMDUMP 372
#define EXECMSGTHRESHOLD 373
#define EXECDNSTHRESHOLD 374
#define TCPTHRESHOLD 375
#define EVENT_SHM_THRESHOLD 376
#define EVENT_PKG_THRESHOLD 377
#define QUERYBUFFERSIZE 378
#define QUERYFLUSHTIME 379
#define SIP_WARNING 380
#define SOCK_MODE 381
#define SOCK_USER 382
#define SOCK_GROUP 383
#define UNIX_SOCK 384
#define UNIX_SOCK_CHILDREN 385
#define UNIX_TX_TIMEOUT 386
#define SERVER_SIGNATURE 387
#define SERVER_HEADER 388
#define USER_AGENT_HEADER 389
#define LOADMODULE 390
#define MPATH 391
#define MODPARAM 392
#define MAXBUFFER 393
#define USER 394
#define GROUP 395
#define CHROOT 396
#define WDIR 397
#define MHOMED 398
#define DISABLE_TCP 399
#define TCP_ACCEPT_ALIASES 400
#define TCP_CHILDREN 401
#define TCP_CONNECT_TIMEOUT 402
#define TCP_SEND_TIMEOUT 403
#define TCP_CON_LIFETIME 404
#define TCP_LISTEN_BACKLOG 405
#define TCP_POLL_METHOD 406
#define TCP_MAX_CONNECTIONS 407
#define TCP_OPT_CRLF_PINGPONG 408
#define TCP_NO_NEW_CONN_BFLAG 409
#define TCP_KEEPALIVE 410
#define TCP_KEEPCOUNT 411
#define TCP_KEEPIDLE 412
#define TCP_KEEPINTERVAL 413
#define DISABLE_TLS 414
#define TLSLOG 415
#define TLS_PORT_NO 416
#define TLS_METHOD 417
#define TLS_HANDSHAKE_TIMEOUT 418
#define TLS_SEND_TIMEOUT 419
#define TLS_SERVER_DOMAIN 420
#define TLS_CLIENT_DOMAIN 421
#define TLS_CLIENT_DOMAIN_AVP 422
#define SSLv23 423
#define SSLv2 424
#define SSLv3 425
#define TLSv1 426
#define TLS_VERIFY_CLIENT 427
#define TLS_VERIFY_SERVER 428
#define TLS_REQUIRE_CLIENT_CERTIFICATE 429
#define TLS_CERTIFICATE 430
#define TLS_PRIVATE_KEY 431
#define TLS_CA_LIST 432
#define TLS_CIPHERS_LIST 433
#define ADVERTISED_ADDRESS 434
#define ADVERTISED_PORT 435
#define DISABLE_CORE 436
#define OPEN_FD_LIMIT 437
#define MCAST_LOOPBACK 438
#define MCAST_TTL 439
#define TOS 440
#define DISABLE_DNS_FAILOVER 441
#define DISABLE_DNS_BLACKLIST 442
#define DST_BLACKLIST 443
#define DISABLE_STATELESS_FWD 444
#define DB_VERSION_TABLE 445
#define DB_DEFAULT_URL 446
#define DISABLE_503_TRANSLATION 447
#define EQUAL 448
#define EQUAL_T 449
#define GT 450
#define LT 451
#define GTE 452
#define LTE 453
#define DIFF 454
#define MATCH 455
#define NOTMATCH 456
#define COLONEQ 457
#define PLUSEQ 458
#define MINUSEQ 459
#define SLASHEQ 460
#define MULTEQ 461
#define MODULOEQ 462
#define BANDEQ 463
#define BOREQ 464
#define BXOREQ 465
#define AND 466
#define OR 467
#define BRSHIFT 468
#define BLSHIFT 469
#define BXOR 470
#define BAND 471
#define BOR 472
#define MODULO 473
#define MULT 474
#define SLASH 475
#define MINUS 476
#define PLUS 477
#define BNOT 478
#define NOT 479
#define NUMBER 480
#define ZERO 481
#define ID 482
#define STRING 483
#define SCRIPTVAR 484
#define IPV6ADDR 485
#define COMMA 486
#define SEMICOLON 487
#define RPAREN 488
#define LPAREN 489
#define LBRACE 490
#define RBRACE 491
#define LBRACK 492
#define RBRACK 493
#define AS 494
#define USE_CHILDREN 495
#define DOT 496
#define CR 497
#define COLON 498
#define ANY 499
#define SCRIPTVARERR 500




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 189 "cfg.y"
{
	long intval;
	unsigned long uval;
	char* strval;
	struct expr* expr;
	struct action* action;
	struct net* ipnet;
	struct ip_addr* ipaddr;
	struct socket_id* sockid;
	struct _pv_spec *specval;
}
/* Line 1489 of yacc.c.  */
#line 551 "cfg.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

